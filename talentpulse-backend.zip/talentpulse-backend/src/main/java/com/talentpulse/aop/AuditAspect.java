package com.talentpulse.aop;

import com.talentpulse.entity.AuditLog;
import com.talentpulse.entity.User;
import com.talentpulse.repository.AuditLogRepository;
import com.talentpulse.repository.UserRepository;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * AOP aspect that writes an AuditLog row whenever a service create/update/delete
 * operation completes successfully.
 */
@Aspect
@Component
public class AuditAspect {

    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;

    public AuditAspect(AuditLogRepository auditLogRepository, UserRepository userRepository) {
        this.auditLogRepository = auditLogRepository;
        this.userRepository = userRepository;
    }

    @Pointcut("execution(* com.talentpulse.serviceimpl.*.create(..)) "
            + "|| execution(* com.talentpulse.serviceimpl.*.update(..)) "
            + "|| execution(* com.talentpulse.serviceimpl.*.delete(..))")
    public void serviceWriteMethods() {
    }

    @AfterReturning("serviceWriteMethods()")
    public void recordAudit(JoinPoint joinPoint) {
        String simpleClassName = joinPoint.getTarget().getClass().getSimpleName();
        // Avoid auditing the audit log service itself.
        if (simpleClassName.startsWith("AuditLog")) {
            return;
        }

        String action = joinPoint.getSignature().getName().toUpperCase();
        String module = simpleClassName.replace("ServiceImpl", "");

        AuditLog log = new AuditLog();
        log.setAction(action);
        log.setModule(module);
        log.setTimestamp(LocalDateTime.now());
        log.setUser(currentUser());

        auditLogRepository.save(log);
    }

    private User currentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getPrincipal())) {
            return userRepository.findByEmail(auth.getName())
                    .orElse(null);
        }
        return null;
    }
}
