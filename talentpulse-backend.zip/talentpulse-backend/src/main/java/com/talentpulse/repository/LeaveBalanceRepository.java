package com.talentpulse.repository;

import com.talentpulse.entity.LeaveBalance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LeaveBalanceRepository extends JpaRepository<LeaveBalance, Long> {
    List<LeaveBalance> findByEmployee_EmployeeId(Long employeeId);
    List<LeaveBalance> findByEmployee_EmployeeIdAndYear(Long employeeId, Integer year);
}
