package com.talentpulse.repository;

import com.talentpulse.entity.JobRequisition;
import com.talentpulse.enums.RequisitionStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobRequisitionRepository extends JpaRepository<JobRequisition, Long> {
    List<JobRequisition> findByStatus(RequisitionStatus status);
    List<JobRequisition> findByDepartment_DepartmentId(Long departmentId);
}
