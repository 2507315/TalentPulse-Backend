package com.talentpulse.repository;

import com.talentpulse.entity.GoalSheet;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface GoalSheetRepository extends JpaRepository<GoalSheet, Long> {
    List<GoalSheet> findByEmployee_EmployeeId(Long employeeId);
    List<GoalSheet> findByCycle_CycleId(Long cycleId);
}
