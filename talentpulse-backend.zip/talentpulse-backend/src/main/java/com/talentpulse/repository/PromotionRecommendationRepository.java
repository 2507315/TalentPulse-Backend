package com.talentpulse.repository;

import com.talentpulse.entity.PromotionRecommendation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PromotionRecommendationRepository extends JpaRepository<PromotionRecommendation, Long> {
    List<PromotionRecommendation> findByEmployee_EmployeeId(Long employeeId);
}
