package com.talentpulse.repository;

import com.talentpulse.entity.Notification;
import com.talentpulse.enums.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUser_UserId(Long userId);
    List<Notification> findByUser_UserIdAndStatus(Long userId, NotificationStatus status);
}
