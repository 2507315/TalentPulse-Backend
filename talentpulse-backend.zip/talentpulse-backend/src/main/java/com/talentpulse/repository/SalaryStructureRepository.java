package com.talentpulse.repository;

import com.talentpulse.entity.SalaryStructure;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SalaryStructureRepository extends JpaRepository<SalaryStructure, Long> {
    List<SalaryStructure> findByGrade_GradeId(Long gradeId);
}
