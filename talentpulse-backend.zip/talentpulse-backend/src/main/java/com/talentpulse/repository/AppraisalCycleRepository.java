package com.talentpulse.repository;

import com.talentpulse.entity.AppraisalCycle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppraisalCycleRepository extends JpaRepository<AppraisalCycle, Long> {
}
