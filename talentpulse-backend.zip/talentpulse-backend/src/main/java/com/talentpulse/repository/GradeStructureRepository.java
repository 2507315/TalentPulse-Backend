package com.talentpulse.repository;

import com.talentpulse.entity.GradeStructure;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GradeStructureRepository extends JpaRepository<GradeStructure, Long> {
}
