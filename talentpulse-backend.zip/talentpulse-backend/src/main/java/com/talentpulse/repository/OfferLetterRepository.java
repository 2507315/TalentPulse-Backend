package com.talentpulse.repository;

import com.talentpulse.entity.OfferLetter;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OfferLetterRepository extends JpaRepository<OfferLetter, Long> {
    List<OfferLetter> findByCandidate_CandidateId(Long candidateId);
}
