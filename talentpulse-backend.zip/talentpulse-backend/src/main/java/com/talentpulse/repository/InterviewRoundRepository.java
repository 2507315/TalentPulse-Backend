package com.talentpulse.repository;

import com.talentpulse.entity.InterviewRound;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InterviewRoundRepository extends JpaRepository<InterviewRound, Long> {
    List<InterviewRound> findByCandidate_CandidateId(Long candidateId);
    List<InterviewRound> findByRequisition_RequisitionId(Long requisitionId);
}
