package com.talentpulse.repository;

import com.talentpulse.entity.Payslip;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PayslipRepository extends JpaRepository<Payslip, Long> {
    List<Payslip> findByEmployee_EmployeeId(Long employeeId);
    List<Payslip> findByPayrollRun_PayrollRunId(Long payrollRunId);
}
