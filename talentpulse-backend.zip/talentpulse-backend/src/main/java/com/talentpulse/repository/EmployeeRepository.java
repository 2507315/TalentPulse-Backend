package com.talentpulse.repository;

import com.talentpulse.entity.Employee;
import com.talentpulse.enums.EmployeeStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByDepartment_DepartmentId(Long departmentId);
    List<Employee> findByReportingManager_EmployeeId(Long reportingManagerId);
    List<Employee> findByStatus(EmployeeStatus status);
}
