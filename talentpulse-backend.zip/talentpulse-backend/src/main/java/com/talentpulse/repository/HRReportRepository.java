package com.talentpulse.repository;

import com.talentpulse.entity.HRReport;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HRReportRepository extends JpaRepository<HRReport, Long> {
}
