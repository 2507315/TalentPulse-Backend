package com.talentpulse.repository;

import com.talentpulse.entity.LeaveApplication;
import com.talentpulse.enums.LeaveStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LeaveApplicationRepository extends JpaRepository<LeaveApplication, Long> {
    List<LeaveApplication> findByEmployee_EmployeeId(Long employeeId);
    List<LeaveApplication> findByApprover_EmployeeId(Long approverId);
    List<LeaveApplication> findByStatus(LeaveStatus status);
}
