package com.talentpulse.service;

import com.talentpulse.dto.SalaryStructureDTO;

import java.util.List;

/**
 * Service contract for the SalaryStructure (Payroll & Compensation Management) entity.
 */
public interface SalaryStructureService {

    List<SalaryStructureDTO> getAll();

    SalaryStructureDTO getById(Long id);

    SalaryStructureDTO create(SalaryStructureDTO dto);

    SalaryStructureDTO update(Long id, SalaryStructureDTO dto);

    void delete(Long id);
}
