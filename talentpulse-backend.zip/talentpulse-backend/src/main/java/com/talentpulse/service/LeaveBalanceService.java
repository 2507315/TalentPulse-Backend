package com.talentpulse.service;

import com.talentpulse.dto.LeaveBalanceDTO;

import java.util.List;

/**
 * Service contract for the LeaveBalance (Leave & Attendance Management) entity.
 */
public interface LeaveBalanceService {

    List<LeaveBalanceDTO> getAll();

    LeaveBalanceDTO getById(Long id);

    LeaveBalanceDTO create(LeaveBalanceDTO dto);

    LeaveBalanceDTO update(Long id, LeaveBalanceDTO dto);

    void delete(Long id);
}
