package com.talentpulse.service;

import com.talentpulse.dto.PayrollRunDTO;

import java.util.List;

/**
 * Service contract for the PayrollRun (Payroll & Compensation Management) entity.
 */
public interface PayrollRunService {

    List<PayrollRunDTO> getAll();

    PayrollRunDTO getById(Long id);

    PayrollRunDTO create(PayrollRunDTO dto);

    PayrollRunDTO update(Long id, PayrollRunDTO dto);

    void delete(Long id);

    /**
     * Auto-generates a payslip for every employee in this (DRAFT) run, computing each
     * payslip's gross/deductions/net from the employee's grade salary structure, then
     * rolls the run totals up. Returns the updated run.
     */
    PayrollRunDTO generatePayslips(Long id);
}
