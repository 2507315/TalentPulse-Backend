package com.talentpulse.service;

import com.talentpulse.dto.PayslipDTO;

import java.util.List;

/**
 * Service contract for the Payslip (Payroll & Compensation Management) entity.
 */
public interface PayslipService {

    List<PayslipDTO> getAll();

    PayslipDTO getById(Long id);

    PayslipDTO create(PayslipDTO dto);

    PayslipDTO update(Long id, PayslipDTO dto);

    void delete(Long id);
}
