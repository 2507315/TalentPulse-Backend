package com.talentpulse.service;

import com.talentpulse.dto.JobRequisitionDTO;

import java.util.List;

/**
 * Service contract for the JobRequisition (Recruitment & Applicant Tracking) entity.
 */
public interface JobRequisitionService {

    List<JobRequisitionDTO> getAll();

    JobRequisitionDTO getById(Long id);

    JobRequisitionDTO create(JobRequisitionDTO dto);

    JobRequisitionDTO update(Long id, JobRequisitionDTO dto);

    void delete(Long id);
}
