package com.talentpulse.service;

import com.talentpulse.dto.AppraisalCycleDTO;

import java.util.List;

/**
 * Service contract for the AppraisalCycle entity.
 */
public interface AppraisalCycleService {

    List<AppraisalCycleDTO> getAll();

    AppraisalCycleDTO getById(Long id);

    AppraisalCycleDTO create(AppraisalCycleDTO dto);

    AppraisalCycleDTO update(Long id, AppraisalCycleDTO dto);

    void delete(Long id);
}
