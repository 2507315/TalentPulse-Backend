package com.talentpulse.service;

import com.talentpulse.dto.GradeStructureDTO;

import java.util.List;

/**
 * Service contract for the GradeStructure (Employee Profile & Organisation Management) entity.
 */
public interface GradeStructureService {

    List<GradeStructureDTO> getAll();

    GradeStructureDTO getById(Long id);

    GradeStructureDTO create(GradeStructureDTO dto);

    GradeStructureDTO update(Long id, GradeStructureDTO dto);

    void delete(Long id);
}
