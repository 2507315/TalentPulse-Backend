package com.talentpulse.service;

import com.talentpulse.dto.EmployeeDTO;

import java.util.List;

/**
 * Service contract for the Employee (Employee Profile & Organisation Management) entity.
 */
public interface EmployeeService {

    List<EmployeeDTO> getAll();

    EmployeeDTO getById(Long id);

    EmployeeDTO create(EmployeeDTO dto);

    EmployeeDTO update(Long id, EmployeeDTO dto);

    void delete(Long id);
}
