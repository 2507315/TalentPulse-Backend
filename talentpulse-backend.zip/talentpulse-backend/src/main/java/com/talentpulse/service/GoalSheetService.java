package com.talentpulse.service;

import com.talentpulse.dto.GoalSheetDTO;

import java.util.List;

/**
 * Service contract for the GoalSheet entity.
 */
public interface GoalSheetService {

    List<GoalSheetDTO> getAll();

    GoalSheetDTO getById(Long id);

    GoalSheetDTO create(GoalSheetDTO dto);

    GoalSheetDTO update(Long id, GoalSheetDTO dto);

    void delete(Long id);
}
