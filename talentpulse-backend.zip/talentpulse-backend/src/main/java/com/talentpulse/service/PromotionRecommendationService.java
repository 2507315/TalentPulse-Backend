package com.talentpulse.service;

import com.talentpulse.dto.PromotionRecommendationDTO;

import java.util.List;

/**
 * Service contract for the PromotionRecommendation entity.
 */
public interface PromotionRecommendationService {

    List<PromotionRecommendationDTO> getAll();

    PromotionRecommendationDTO getById(Long id);

    PromotionRecommendationDTO create(PromotionRecommendationDTO dto);

    PromotionRecommendationDTO update(Long id, PromotionRecommendationDTO dto);

    void delete(Long id);
}
