package com.talentpulse.service;

import com.talentpulse.dto.AuditLogDTO;

import java.util.List;

/**
 * Service contract for the AuditLog (Identity & Access Management) entity.
 */
public interface AuditLogService {

    List<AuditLogDTO> getAll();

    AuditLogDTO getById(Long id);

    AuditLogDTO create(AuditLogDTO dto);

    AuditLogDTO update(Long id, AuditLogDTO dto);

    void delete(Long id);
}
