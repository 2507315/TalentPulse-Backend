package com.talentpulse.service;

import com.talentpulse.dto.LeaveApplicationDTO;

import java.util.List;

/**
 * Service contract for the LeaveApplication (Leave & Attendance Management) entity.
 */
public interface LeaveApplicationService {

    List<LeaveApplicationDTO> getAll();

    LeaveApplicationDTO getById(Long id);

    LeaveApplicationDTO create(LeaveApplicationDTO dto);

    LeaveApplicationDTO update(Long id, LeaveApplicationDTO dto);

    void delete(Long id);
}
