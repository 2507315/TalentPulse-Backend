package com.talentpulse.service;

import com.talentpulse.dto.UserDTO;

import java.util.List;

/**
 * Service contract for the User (Identity & Access Management) entity.
 */
public interface UserService {

    List<UserDTO> getAll();

    UserDTO getById(Long id);

    UserDTO create(UserDTO dto);

    UserDTO update(Long id, UserDTO dto);

    void delete(Long id);
}
