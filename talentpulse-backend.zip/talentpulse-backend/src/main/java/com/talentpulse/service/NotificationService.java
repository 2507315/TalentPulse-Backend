package com.talentpulse.service;

import com.talentpulse.dto.NotificationDTO;

import java.util.List;

/**
 * Service contract for the Notification (Notifications & Alerts) entity.
 */
public interface NotificationService {

    List<NotificationDTO> getAll();

    NotificationDTO getById(Long id);

    NotificationDTO create(NotificationDTO dto);

    NotificationDTO update(Long id, NotificationDTO dto);

    void delete(Long id);
}
