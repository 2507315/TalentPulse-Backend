package com.talentpulse.service;

import com.talentpulse.dto.HRReportDTO;
import com.talentpulse.enums.ReportScope;

import java.util.List;

/**
 * Service contract for the HRReport (HR Analytics & Reporting) entity.
 */
public interface HRReportService {

    List<HRReportDTO> getAll();

    HRReportDTO getById(Long id);

    HRReportDTO create(HRReportDTO dto);

    HRReportDTO update(Long id, HRReportDTO dto);

    void delete(Long id);

    /**
     * Builds an HR report whose metrics are computed live from the current data
     * (headcount, attrition, average tenure, payroll cost, leave utilisation,
     * performance distribution) for the requested scope, then persists and returns it.
     */
    HRReportDTO generate(ReportScope scope);
}
