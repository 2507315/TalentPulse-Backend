package com.talentpulse.service;

import com.talentpulse.dto.DepartmentDTO;

import java.util.List;

/**
 * Service contract for the Department (Employee Profile & Organisation Management) entity.
 */
public interface DepartmentService {

    List<DepartmentDTO> getAll();

    DepartmentDTO getById(Long id);

    DepartmentDTO create(DepartmentDTO dto);

    DepartmentDTO update(Long id, DepartmentDTO dto);

    void delete(Long id);
}
