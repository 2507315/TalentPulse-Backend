package com.talentpulse.service;

import com.talentpulse.dto.AttendanceRecordDTO;

import java.util.List;

/**
 * Service contract for the AttendanceRecord (Leave & Attendance Management) entity.
 */
public interface AttendanceRecordService {

    List<AttendanceRecordDTO> getAll();

    AttendanceRecordDTO getById(Long id);

    AttendanceRecordDTO create(AttendanceRecordDTO dto);

    AttendanceRecordDTO update(Long id, AttendanceRecordDTO dto);

    void delete(Long id);
}
