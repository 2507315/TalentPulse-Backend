package com.talentpulse.service;

import com.talentpulse.dto.OfferLetterDTO;

import java.util.List;

/**
 * Service contract for the OfferLetter (Recruitment & Applicant Tracking) entity.
 */
public interface OfferLetterService {

    List<OfferLetterDTO> getAll();

    OfferLetterDTO getById(Long id);

    OfferLetterDTO create(OfferLetterDTO dto);

    OfferLetterDTO update(Long id, OfferLetterDTO dto);

    void delete(Long id);
}
