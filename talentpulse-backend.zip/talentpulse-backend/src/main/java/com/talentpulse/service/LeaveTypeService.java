package com.talentpulse.service;

import com.talentpulse.dto.LeaveTypeDTO;

import java.util.List;

/**
 * Service contract for the LeaveType (Leave & Attendance Management) entity.
 */
public interface LeaveTypeService {

    List<LeaveTypeDTO> getAll();

    LeaveTypeDTO getById(Long id);

    LeaveTypeDTO create(LeaveTypeDTO dto);

    LeaveTypeDTO update(Long id, LeaveTypeDTO dto);

    void delete(Long id);
}
