package com.talentpulse.service;

import com.talentpulse.dto.InterviewRoundDTO;

import java.util.List;

/**
 * Service contract for the InterviewRound (Recruitment & Applicant Tracking) entity.
 */
public interface InterviewRoundService {

    List<InterviewRoundDTO> getAll();

    InterviewRoundDTO getById(Long id);

    InterviewRoundDTO create(InterviewRoundDTO dto);

    InterviewRoundDTO update(Long id, InterviewRoundDTO dto);

    void delete(Long id);
}
