package com.talentpulse.service;

import com.talentpulse.dto.CandidateDTO;

import java.util.List;

/**
 * Service contract for the Candidate (Recruitment & Applicant Tracking) entity.
 */
public interface CandidateService {

    List<CandidateDTO> getAll();

    CandidateDTO getById(Long id);

    CandidateDTO create(CandidateDTO dto);

    CandidateDTO update(Long id, CandidateDTO dto);

    void delete(Long id);
}
