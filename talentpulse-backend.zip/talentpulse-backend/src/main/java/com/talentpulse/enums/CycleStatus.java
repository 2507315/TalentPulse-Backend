package com.talentpulse.enums;

/** Appraisal cycle status. */
public enum CycleStatus {
    UPCOMING, ACTIVE, CLOSED
}
