package com.talentpulse.enums;

/** Promotion recommendation status. */
public enum RecommendationStatus {
    RECOMMENDED, APPROVED, DECLINED
}
