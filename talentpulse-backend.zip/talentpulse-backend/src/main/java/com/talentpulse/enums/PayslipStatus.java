package com.talentpulse.enums;

/** Payslip status. */
public enum PayslipStatus {
    GENERATED, ISSUED
}
