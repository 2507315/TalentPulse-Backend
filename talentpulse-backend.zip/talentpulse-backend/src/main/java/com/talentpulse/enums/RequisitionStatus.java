package com.talentpulse.enums;

/** Job requisition status. */
public enum RequisitionStatus {
    DRAFT, APPROVED, OPEN, FILLED, CANCELLED
}
