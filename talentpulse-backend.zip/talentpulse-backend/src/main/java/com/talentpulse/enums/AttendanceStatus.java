package com.talentpulse.enums;

/** Daily attendance status. */
public enum AttendanceStatus {
    PRESENT, ABSENT, HALF_DAY, ON_LEAVE, HOLIDAY
}
