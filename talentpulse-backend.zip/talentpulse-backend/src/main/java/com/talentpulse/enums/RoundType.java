package com.talentpulse.enums;

/** Interview round type. */
public enum RoundType {
    HR, TECHNICAL, MANAGERIAL, FINAL
}
