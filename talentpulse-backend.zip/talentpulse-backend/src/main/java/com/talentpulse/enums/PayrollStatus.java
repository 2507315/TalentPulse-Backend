package com.talentpulse.enums;

/** Payroll run status. */
public enum PayrollStatus {
    DRAFT, PROCESSED, APPROVED, DISBURSED
}
