package com.talentpulse.enums;

/** HR report scope. */
public enum ReportScope {
    DEPARTMENT, GRADE, PERIOD, COSTCENTRE
}
