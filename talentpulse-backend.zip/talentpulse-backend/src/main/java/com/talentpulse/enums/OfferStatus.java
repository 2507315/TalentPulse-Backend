package com.talentpulse.enums;

/** Offer letter status. */
public enum OfferStatus {
    ISSUED, ACCEPTED, DECLINED, REVOKED
}
