package com.talentpulse.enums;

/** Candidate sourcing channel. */
public enum SourceChannel {
    PORTAL, REFERRAL, AGENCY, CAMPUS
}
