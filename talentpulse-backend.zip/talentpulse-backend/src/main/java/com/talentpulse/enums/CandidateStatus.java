package com.talentpulse.enums;

/** Candidate pipeline status. */
public enum CandidateStatus {
    APPLIED, SHORTLISTED, INTERVIEW_SCHEDULED, OFFERED, JOINED, REJECTED
}
