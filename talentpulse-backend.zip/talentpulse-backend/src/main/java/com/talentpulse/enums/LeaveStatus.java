package com.talentpulse.enums;

/** Leave application status. */
public enum LeaveStatus {
    PENDING, APPROVED, REJECTED, CANCELLED
}
