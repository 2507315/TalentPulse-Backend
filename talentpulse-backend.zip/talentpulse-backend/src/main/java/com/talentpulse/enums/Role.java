package com.talentpulse.enums;

/** Application roles used for RBAC. */
public enum Role {
    EMPLOYEE, MANAGER, HRBP, PAYROLL, RECRUITER, ADMIN
}
