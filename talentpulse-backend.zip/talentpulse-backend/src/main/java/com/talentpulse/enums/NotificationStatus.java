package com.talentpulse.enums;

/** Notification read status. */
public enum NotificationStatus {
    UNREAD, READ, DISMISSED
}
