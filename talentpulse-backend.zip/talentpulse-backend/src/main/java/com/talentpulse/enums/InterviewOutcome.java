package com.talentpulse.enums;

/** Interview round outcome. */
public enum InterviewOutcome {
    PASS, FAIL, HOLD, PENDING
}
