package com.talentpulse.enums;

/** Goal sheet status. */
public enum GoalSheetStatus {
    DRAFT, SUBMITTED, REVIEWED, FINALISED
}
