package com.talentpulse.enums;

/** Employment type. */
public enum EmploymentType {
    PERMANENT, CONTRACT, INTERN
}
