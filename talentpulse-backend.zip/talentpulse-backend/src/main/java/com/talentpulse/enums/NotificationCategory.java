package com.talentpulse.enums;

/** Notification category. */
public enum NotificationCategory {
    LEAVE, PAYROLL, APPRAISAL, RECRUITMENT, COMPLIANCE
}
