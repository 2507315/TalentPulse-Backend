package com.talentpulse.enums;

/** Employee lifecycle status. */
public enum EmployeeStatus {
    ACTIVE, PROBATION, RESIGNED, EXITED
}
