package com.talentpulse.enums;

/** User account status. */
public enum UserStatus {
    ACTIVE, ON_LEAVE, INACTIVE, EXITED
}
