package com.talentpulse.enums;

/** Appraisal cycle type. */
public enum AppraisalType {
    MID_YEAR, ANNUAL
}
