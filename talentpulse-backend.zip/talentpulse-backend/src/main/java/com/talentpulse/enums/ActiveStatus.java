package com.talentpulse.enums;

/** Generic active / inactive status (e.g. Department). */
public enum ActiveStatus {
    ACTIVE, INACTIVE
}
