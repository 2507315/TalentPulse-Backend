package com.talentpulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * TalentPulse - HR & Workforce Management System.
 * Main entry point for the Spring Boot application.
 */
@SpringBootApplication
public class TalentPulseApplication {

    public static void main(String[] args) {
        SpringApplication.run(TalentPulseApplication.class, args);
        System.out.println("Successfull");
    }
}
