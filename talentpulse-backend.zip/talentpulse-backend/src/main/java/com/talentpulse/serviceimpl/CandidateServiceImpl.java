package com.talentpulse.serviceimpl;

import com.talentpulse.dto.CandidateDTO;
import com.talentpulse.entity.Candidate;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.CandidateRepository;
import com.talentpulse.service.CandidateService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CandidateServiceImpl implements CandidateService {

    private final CandidateRepository candidateRepository;

    public CandidateServiceImpl(CandidateRepository candidateRepository) {
        this.candidateRepository = candidateRepository;
    }

    @Override
    public List<CandidateDTO> getAll() {
        return candidateRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public CandidateDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public CandidateDTO create(CandidateDTO dto) {
        Candidate entity = toEntity(dto, new Candidate());
        return toDto(candidateRepository.save(entity));
    }

    @Override
    public CandidateDTO update(Long id, CandidateDTO dto) {
        Candidate entity = toEntity(dto, findEntity(id));
        return toDto(candidateRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        candidateRepository.delete(findEntity(id));
    }

    private Candidate findEntity(Long id) {
        return candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate", id));
    }

    // ---- mapping helpers ----

    private CandidateDTO toDto(Candidate e) {
        CandidateDTO dto = new CandidateDTO();
        dto.setCandidateId(e.getCandidateId());
        dto.setName(e.getName());
        dto.setEmail(e.getEmail());
        dto.setPhone(e.getPhone());
        dto.setResumeRef(e.getResumeRef());
        dto.setSourceChannel(e.getSourceChannel());
        dto.setStatus(e.getStatus());
        return dto;
    }

    private Candidate toEntity(CandidateDTO dto, Candidate e) {
        e.setName(dto.getName());
        e.setEmail(dto.getEmail());
        e.setPhone(dto.getPhone());
        e.setResumeRef(dto.getResumeRef());
        e.setSourceChannel(dto.getSourceChannel());
        e.setStatus(dto.getStatus());
        return e;
    }
}
