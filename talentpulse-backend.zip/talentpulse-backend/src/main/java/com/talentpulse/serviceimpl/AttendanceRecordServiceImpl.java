package com.talentpulse.serviceimpl;

import com.talentpulse.dto.AttendanceRecordDTO;
import com.talentpulse.entity.AttendanceRecord;
import com.talentpulse.entity.Employee;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AttendanceRecordRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.service.AttendanceRecordService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AttendanceRecordServiceImpl implements AttendanceRecordService {

    private final AttendanceRecordRepository attendanceRecordRepository;
    private final EmployeeRepository employeeRepository;

    public AttendanceRecordServiceImpl(AttendanceRecordRepository attendanceRecordRepository,
                                       EmployeeRepository employeeRepository) {
        this.attendanceRecordRepository = attendanceRecordRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    public List<AttendanceRecordDTO> getAll() {
        return attendanceRecordRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public AttendanceRecordDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public AttendanceRecordDTO create(AttendanceRecordDTO dto) {
        AttendanceRecord entity = toEntity(dto, new AttendanceRecord());
        return toDto(attendanceRecordRepository.save(entity));
    }

    @Override
    public AttendanceRecordDTO update(Long id, AttendanceRecordDTO dto) {
        AttendanceRecord entity = toEntity(dto, findEntity(id));
        return toDto(attendanceRecordRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        attendanceRecordRepository.delete(findEntity(id));
    }

    private AttendanceRecord findEntity(Long id) {
        return attendanceRecordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AttendanceRecord", id));
    }

    // ---- mapping helpers ----

    private AttendanceRecordDTO toDto(AttendanceRecord e) {
        AttendanceRecordDTO dto = new AttendanceRecordDTO();
        dto.setAttendanceId(e.getAttendanceId());
        dto.setEmployeeId(e.getEmployee() != null ? e.getEmployee().getEmployeeId() : null);
        dto.setDate(e.getDate());
        dto.setCheckIn(e.getCheckIn());
        dto.setCheckOut(e.getCheckOut());
        dto.setWorkingHours(e.getWorkingHours());
        dto.setStatus(e.getStatus());
        return dto;
    }

    private AttendanceRecord toEntity(AttendanceRecordDTO dto, AttendanceRecord e) {
        e.setEmployee(resolveEmployee(dto.getEmployeeId()));
        e.setDate(dto.getDate());
        e.setCheckIn(dto.getCheckIn());
        e.setCheckOut(dto.getCheckOut());
        e.setWorkingHours(dto.getWorkingHours());
        e.setStatus(dto.getStatus());
        return e;
    }

    private Employee resolveEmployee(Long id) {
        if (id == null) {
            return null;
        }
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }
}
