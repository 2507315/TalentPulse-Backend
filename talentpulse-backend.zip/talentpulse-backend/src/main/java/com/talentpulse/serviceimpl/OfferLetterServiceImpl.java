package com.talentpulse.serviceimpl;

import com.talentpulse.dto.OfferLetterDTO;
import com.talentpulse.entity.Candidate;
import com.talentpulse.entity.JobRequisition;
import com.talentpulse.entity.OfferLetter;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.CandidateRepository;
import com.talentpulse.repository.JobRequisitionRepository;
import com.talentpulse.repository.OfferLetterRepository;
import com.talentpulse.service.OfferLetterService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OfferLetterServiceImpl implements OfferLetterService {

    private final OfferLetterRepository offerLetterRepository;
    private final CandidateRepository candidateRepository;
    private final JobRequisitionRepository jobRequisitionRepository;

    public OfferLetterServiceImpl(OfferLetterRepository offerLetterRepository,
                                  CandidateRepository candidateRepository,
                                  JobRequisitionRepository jobRequisitionRepository) {
        this.offerLetterRepository = offerLetterRepository;
        this.candidateRepository = candidateRepository;
        this.jobRequisitionRepository = jobRequisitionRepository;
    }

    @Override
    public List<OfferLetterDTO> getAll() {
        return offerLetterRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public OfferLetterDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public OfferLetterDTO create(OfferLetterDTO dto) {
        OfferLetter entity = toEntity(dto, new OfferLetter());
        return toDto(offerLetterRepository.save(entity));
    }

    @Override
    public OfferLetterDTO update(Long id, OfferLetterDTO dto) {
        OfferLetter entity = toEntity(dto, findEntity(id));
        return toDto(offerLetterRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        offerLetterRepository.delete(findEntity(id));
    }

    private OfferLetter findEntity(Long id) {
        return offerLetterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OfferLetter", id));
    }

    // ---- mapping helpers ----

    private OfferLetterDTO toDto(OfferLetter e) {
        OfferLetterDTO dto = new OfferLetterDTO();
        dto.setOfferId(e.getOfferId());
        dto.setCandidateId(e.getCandidate() != null ? e.getCandidate().getCandidateId() : null);
        dto.setRequisitionId(e.getRequisition() != null ? e.getRequisition().getRequisitionId() : null);
        dto.setOfferedSalary(e.getOfferedSalary());
        dto.setJoiningDate(e.getJoiningDate());
        dto.setIssuedDate(e.getIssuedDate());
        dto.setStatus(e.getStatus());
        return dto;
    }

    private OfferLetter toEntity(OfferLetterDTO dto, OfferLetter e) {
        e.setCandidate(resolveCandidate(dto.getCandidateId()));
        e.setRequisition(resolveJobRequisition(dto.getRequisitionId()));
        e.setOfferedSalary(dto.getOfferedSalary());
        e.setJoiningDate(dto.getJoiningDate());
        e.setIssuedDate(dto.getIssuedDate());
        e.setStatus(dto.getStatus());
        return e;
    }

    private Candidate resolveCandidate(Long id) {
        if (id == null) {
            return null;
        }
        return candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate", id));
    }

    private JobRequisition resolveJobRequisition(Long id) {
        if (id == null) {
            return null;
        }
        return jobRequisitionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("JobRequisition", id));
    }
}
