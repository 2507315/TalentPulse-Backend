package com.talentpulse.serviceimpl;

import com.talentpulse.dto.JobRequisitionDTO;
import com.talentpulse.entity.Department;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.JobRequisition;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.DepartmentRepository;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.JobRequisitionRepository;
import com.talentpulse.service.JobRequisitionService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service  //business rules & logic
public class JobRequisitionServiceImpl implements JobRequisitionService {

    private final JobRequisitionRepository jobRequisitionRepository;
    private final DepartmentRepository departmentRepository;
    private final GradeStructureRepository gradeStructureRepository;

    public JobRequisitionServiceImpl(JobRequisitionRepository jobRequisitionRepository,
                                     DepartmentRepository departmentRepository,
                                     GradeStructureRepository gradeStructureRepository) {
        this.jobRequisitionRepository = jobRequisitionRepository;
        this.departmentRepository = departmentRepository;
        this.gradeStructureRepository = gradeStructureRepository;
    }

    @Override
    public List<JobRequisitionDTO> getAll() {
        return jobRequisitionRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public JobRequisitionDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public JobRequisitionDTO create(JobRequisitionDTO dto) {
        JobRequisition entity = toEntity(dto, new JobRequisition());
        return toDto(jobRequisitionRepository.save(entity));
    }

    @Override
    public JobRequisitionDTO update(Long id, JobRequisitionDTO dto) {
        JobRequisition entity = toEntity(dto, findEntity(id));
        return toDto(jobRequisitionRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        jobRequisitionRepository.delete(findEntity(id));
    }

    private JobRequisition findEntity(Long id) {
        return jobRequisitionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("JobRequisition", id));
    }

    // ---- mapping helpers ----

    private JobRequisitionDTO toDto(JobRequisition e) {
        JobRequisitionDTO dto = new JobRequisitionDTO();
        dto.setRequisitionId(e.getRequisitionId());
        dto.setDepartmentId(e.getDepartment() != null ? e.getDepartment().getDepartmentId() : null);
        dto.setDesignation(e.getDesignation());
        dto.setGradeId(e.getGrade() != null ? e.getGrade().getGradeId() : null);
        dto.setRequiredBy(e.getRequiredBy());
        dto.setStatus(e.getStatus());
        return dto;
    }

    private JobRequisition toEntity(JobRequisitionDTO dto, JobRequisition e) {
        e.setDepartment(resolveDepartment(dto.getDepartmentId()));
        e.setDesignation(dto.getDesignation());
        e.setGrade(resolveGradeStructure(dto.getGradeId()));
        e.setRequiredBy(dto.getRequiredBy());
        e.setStatus(dto.getStatus());
        return e;
    }

    private Department resolveDepartment(Long id) {
        if (id == null) {
            return null;
        }
        return departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department", id));
    }

    private GradeStructure resolveGradeStructure(Long id) {
        if (id == null) {
            return null;
        }
        return gradeStructureRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("GradeStructure", id));
    }
}
