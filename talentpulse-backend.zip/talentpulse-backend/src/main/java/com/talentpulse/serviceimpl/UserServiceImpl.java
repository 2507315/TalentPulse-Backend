//package com.talentpulse.serviceimpl;
//
//import com.talentpulse.dto.UserDTO;
//import com.talentpulse.entity.Employee;
//import com.talentpulse.entity.User;
//import com.talentpulse.exception.ResourceNotFoundException;
//import com.talentpulse.repository.EmployeeRepository;
//import com.talentpulse.repository.UserRepository;
//import com.talentpulse.service.UserService;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//@Service
//public class UserServiceImpl implements UserService {
//
//    private final UserRepository userRepository;
//    private final EmployeeRepository employeeRepository;
//    private final PasswordEncoder passwordEncoder;
//
//    public UserServiceImpl(UserRepository userRepository, EmployeeRepository employeeRepository, PasswordEncoder passwordEncoder) {
//        this.userRepository = userRepository;
//        this.employeeRepository = employeeRepository;
//        this.passwordEncoder = passwordEncoder;
//    }
//
//    @Override
//    public List<UserDTO> getAll() {
//        return userRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
//    }
//
//    @Override
//    public UserDTO getById(Long id) {
//        return toDto(findEntity(id));
//    }
//
//    @Override
//    public UserDTO create(UserDTO dto) {
//        User entity = toEntity(dto, new User());
//        return toDto(userRepository.save(entity));
//    }
//
//    @Override
//    public UserDTO update(Long id, UserDTO dto) {
//        User entity = toEntity(dto, findEntity(id));
//        return toDto(userRepository.save(entity));
//    }
//
//    @Override
//    public void delete(Long id) {
//        userRepository.delete(findEntity(id));
//    }
//
//    private User findEntity(Long id) {
//        return userRepository.findById(id)
//                .orElseThrow(() -> new ResourceNotFoundException("User", id));
//    }
//
//    // ---- mapping helpers ----
//
//    private UserDTO toDto(User e) {
//        UserDTO dto = new UserDTO();
//        dto.setUserId(e.getUserId());
//        dto.setEmployeeId(e.getEmployee() != null ? e.getEmployee().getEmployeeId() : null);
//        dto.setName(e.getName());
//        dto.setRole(e.getRole());
//        dto.setEmail(e.getEmail());
//        dto.setPhone(e.getPhone());
//        dto.setStatus(e.getStatus());
//        // password intentionally not exposed in responses
//        return dto;
//    }
//
//    private User toEntity(UserDTO dto, User e) {
//        e.setEmployee(resolveEmployeeSoft(dto.getEmployeeId()));
//        e.setName(dto.getName());
//        e.setRole(dto.getRole());
//        e.setEmail(dto.getEmail());
//        e.setPhone(dto.getPhone());
//        if (dto.getPassword() != null && !dto.getPassword().trim().isEmpty()) {
//            e.setPassword(passwordEncoder.encode(dto.getPassword()));
//        }
//        e.setStatus(dto.getStatus());
//        return e;
//    }
//
//    private Employee resolveEmployeeSoft(Long id) {
//        if (id == null) return null;
//        return employeeRepository.findById(id).orElse(null);   // soft: no throw, protects registration
//    }
//}


package com.talentpulse.serviceimpl;

import com.talentpulse.dto.UserDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.User;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.UserRepository;
import com.talentpulse.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final EmployeeRepository employeeRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository,
                           EmployeeRepository employeeRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.employeeRepository = employeeRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public List<UserDTO> getAll() {
        return userRepository.findAll()
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public UserDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public UserDTO create(UserDTO dto) {
        User user = toEntity(dto, new User());
        return toDto(userRepository.save(user));
    }

    @Override
    public UserDTO update(Long id, UserDTO dto) {
        User user = toEntity(dto, findEntity(id));
        return toDto(userRepository.save(user));
    }

    @Override
    public void delete(Long id) {
        userRepository.delete(findEntity(id));
    }

    private User findEntity(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }

    // ✅ Entity → DTO
    private UserDTO toDto(User e) {
        UserDTO dto = new UserDTO();
        dto.setUserId(e.getUserId());
        dto.setEmployeeId(
                e.getEmployee() != null ? e.getEmployee().getEmployeeId() : null
        );
        dto.setName(e.getName());
        dto.setRole(e.getRole());
        dto.setEmail(e.getEmail());
        dto.setPhone(e.getPhone());
        dto.setStatus(e.getStatus());
        return dto;
    }

    // ✅ DTO → Entity
    private User toEntity(UserDTO dto, User e) {

        // 🔥 FIX: Always fetch Employee (no null)
        Employee emp = employeeRepository.findById(dto.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee", dto.getEmployeeId()));

        e.setEmployee(emp);   // ✅ THIS FIXES employeeId NULL

        e.setName(dto.getName());
        e.setRole(dto.getRole());
        e.setEmail(dto.getEmail());
        e.setPhone(dto.getPhone());

        if (dto.getPassword() != null && !dto.getPassword().isEmpty()) {
            e.setPassword(passwordEncoder.encode(dto.getPassword()));
        }

        e.setStatus(dto.getStatus());

        return e;
    }
}
