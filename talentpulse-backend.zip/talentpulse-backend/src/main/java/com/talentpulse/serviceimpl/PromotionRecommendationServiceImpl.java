package com.talentpulse.serviceimpl;

import com.talentpulse.dto.PromotionRecommendationDTO;
import com.talentpulse.entity.AppraisalCycle;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.PromotionRecommendation;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AppraisalCycleRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.PromotionRecommendationRepository;
import com.talentpulse.service.PromotionRecommendationService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PromotionRecommendationServiceImpl implements PromotionRecommendationService {

    private final PromotionRecommendationRepository promotionRecommendationRepository;
    private final EmployeeRepository employeeRepository;
    private final AppraisalCycleRepository appraisalCycleRepository;
    private final GradeStructureRepository gradeStructureRepository;

    public PromotionRecommendationServiceImpl(PromotionRecommendationRepository promotionRecommendationRepository,
                                              EmployeeRepository employeeRepository,
                                              AppraisalCycleRepository appraisalCycleRepository,
                                              GradeStructureRepository gradeStructureRepository) {
        this.promotionRecommendationRepository = promotionRecommendationRepository;
        this.employeeRepository = employeeRepository;
        this.appraisalCycleRepository = appraisalCycleRepository;
        this.gradeStructureRepository = gradeStructureRepository;
    }

    @Override
    public List<PromotionRecommendationDTO> getAll() {
        return promotionRecommendationRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public PromotionRecommendationDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public PromotionRecommendationDTO create(PromotionRecommendationDTO dto) {
        PromotionRecommendation entity = toEntity(dto, new PromotionRecommendation());
        return toDto(promotionRecommendationRepository.save(entity));
    }

    @Override
    public PromotionRecommendationDTO update(Long id, PromotionRecommendationDTO dto) {
        PromotionRecommendation entity = toEntity(dto, findEntity(id));
        return toDto(promotionRecommendationRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        promotionRecommendationRepository.delete(findEntity(id));
    }

    private PromotionRecommendation findEntity(Long id) {
        return promotionRecommendationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PromotionRecommendation", id));
    }

    private Employee resolveEmployee(Long id) {
        if (id == null) {
            return null;
        }
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }

    private AppraisalCycle resolveAppraisalCycle(Long id) {
        if (id == null) {
            return null;
        }
        return appraisalCycleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AppraisalCycle", id));
    }

    private GradeStructure resolveGradeStructure(Long id) {
        if (id == null) {
            return null;
        }
        return gradeStructureRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("GradeStructure", id));
    }

    // ---- mapping helpers ----

    private PromotionRecommendationDTO toDto(PromotionRecommendation e) {
        PromotionRecommendationDTO dto = new PromotionRecommendationDTO();
        dto.setRecommendationId(e.getRecommendationId());
        dto.setEmployeeId(e.getEmployee() != null ? e.getEmployee().getEmployeeId() : null);
        dto.setCycleId(e.getCycle() != null ? e.getCycle().getCycleId() : null);
        dto.setCurrentGradeId(e.getCurrentGrade() != null ? e.getCurrentGrade().getGradeId() : null);
        dto.setRecommendedGradeId(e.getRecommendedGrade() != null ? e.getRecommendedGrade().getGradeId() : null);
        dto.setRecommendedBy(e.getRecommendedByEmployee() != null ? e.getRecommendedByEmployee().getEmployeeId() : null);
        dto.setStatus(e.getStatus());
        return dto;
    }

    private PromotionRecommendation toEntity(PromotionRecommendationDTO dto, PromotionRecommendation e) {
        e.setEmployee(resolveEmployee(dto.getEmployeeId()));
        e.setCycle(resolveAppraisalCycle(dto.getCycleId()));
        e.setCurrentGrade(resolveGradeStructure(dto.getCurrentGradeId()));
        e.setRecommendedGrade(resolveGradeStructure(dto.getRecommendedGradeId()));
        e.setRecommendedByEmployee(resolveEmployee(dto.getRecommendedBy()));
        e.setStatus(dto.getStatus());
        return e;
    }
}
