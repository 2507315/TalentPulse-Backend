package com.talentpulse.serviceimpl;

import com.talentpulse.dto.PayrollRunDTO;
import com.talentpulse.dto.PayslipDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.PayrollRun;
import com.talentpulse.entity.Payslip;
import com.talentpulse.entity.User;
import com.talentpulse.enums.PayrollStatus;
import com.talentpulse.exception.BadRequestException;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.PayrollRunRepository;
import com.talentpulse.repository.PayslipRepository;
import com.talentpulse.repository.UserRepository;
import com.talentpulse.service.PayrollRunService;
import com.talentpulse.service.PayslipService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class PayrollRunServiceImpl implements PayrollRunService {

    private final PayrollRunRepository payrollRunRepository;
    private final UserRepository userRepository;
    private final PayslipRepository payslipRepository;
    private final EmployeeRepository employeeRepository;
    private final PayslipService payslipService;

    public PayrollRunServiceImpl(PayrollRunRepository payrollRunRepository,
                                 UserRepository userRepository,
                                 PayslipRepository payslipRepository,
                                 EmployeeRepository employeeRepository,
                                 PayslipService payslipService) {
        this.payrollRunRepository = payrollRunRepository;
        this.userRepository = userRepository;
        this.payslipRepository = payslipRepository;
        this.employeeRepository = employeeRepository;
        this.payslipService = payslipService;
    }

    @Override
    public List<PayrollRunDTO> getAll() {
        return payrollRunRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public PayrollRunDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public PayrollRunDTO create(PayrollRunDTO dto) {
        PayrollRun entity = new PayrollRun();
        entity.setMonth(dto.getMonth());
        entity.setYear(dto.getYear());
        entity.setProcessedByUser(resolveUser(dto.getProcessedBy()));
        entity.setProcessedDate(dto.getProcessedDate());
        entity.setStatus(dto.getStatus() != null ? dto.getStatus() : PayrollStatus.DRAFT);
        entity.setTotalGross(0.0);
        entity.setTotalDeductions(0.0);
        entity.setTotalNet(0.0);
        return toDto(payrollRunRepository.save(entity));
    }

    @Override
    public PayrollRunDTO update(Long id, PayrollRunDTO dto) {
        PayrollRun entity = findEntity(id);
        PayrollStatus current = entity.getStatus();
        PayrollStatus requested = dto.getStatus() != null ? dto.getStatus() : current;

        if (current == PayrollStatus.DISBURSED) {
            throw new BadRequestException(
                    "Payroll run " + id + " is DISBURSED and can no longer be modified.");
        }
        if (current != null && requested != current && requested.ordinal() != current.ordinal() + 1) {
            throw new BadRequestException(
                    "Invalid status transition: " + current + " -> " + requested
                            + ". The next allowed status is " + nextStatus(current) + ".");
        }

        entity.setMonth(dto.getMonth());
        entity.setYear(dto.getYear());
        entity.setProcessedByUser(resolveUser(dto.getProcessedBy()));
        entity.setProcessedDate(dto.getProcessedDate());
        entity.setStatus(requested);
        recalculateTotals(entity);
        return toDto(payrollRunRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        payrollRunRepository.delete(findEntity(id));
    }

    /**
     * Generates a payslip for every employee that doesn't already have one in this run.
     * Each payslip's amounts are auto-computed by the PayslipService from the employee's
     * grade salary structure. Employees with no usable salary structure are skipped.
     */
    @Override
    public PayrollRunDTO generatePayslips(Long id) {
        PayrollRun run = findEntity(id);
        if (run.getStatus() != PayrollStatus.DRAFT) {
            throw new BadRequestException(
                    "Payslips can only be generated for a DRAFT payroll run (current status: " + run.getStatus() + ").");
        }

        Set<Long> alreadyPaid = payslipRepository.findByPayrollRun_PayrollRunId(id).stream()
                .filter(p -> p.getEmployee() != null)
                .map(p -> p.getEmployee().getEmployeeId())
                .collect(Collectors.toSet());

        LocalDate payslipDate = run.getProcessedDate() != null ? run.getProcessedDate() : LocalDate.now();

        for (Employee employee : employeeRepository.findAll()) {
            if (employee.getEmployeeId() == null || alreadyPaid.contains(employee.getEmployeeId())) {
                continue;
            }
            PayslipDTO dto = new PayslipDTO();
            dto.setPayrollRunId(id);
            dto.setEmployeeId(employee.getEmployeeId());
            dto.setPayslipDate(payslipDate);
            try {
                payslipService.create(dto); // amounts auto-computed from the salary structure
            } catch (BadRequestException ex) {
                // employee has no usable salary structure to derive gross from -> skip
            }
        }

        recalculateTotals(run);
        return toDto(payrollRunRepository.save(run));
    }

    private PayrollRun findEntity(Long id) {
        return payrollRunRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PayrollRun", id));
    }

    private void recalculateTotals(PayrollRun run) {
        if (run.getPayrollRunId() == null) {
            run.setTotalGross(0.0);
            run.setTotalDeductions(0.0);
            run.setTotalNet(0.0);
            return;
        }
        List<Payslip> payslips = payslipRepository.findByPayrollRun_PayrollRunId(run.getPayrollRunId());
        double gross = 0.0, deductions = 0.0, net = 0.0;
        for (Payslip p : payslips) {
            if (p.getGrossAmount() != null) gross += p.getGrossAmount();
            if (p.getTotalDeductions() != null) deductions += p.getTotalDeductions();
            if (p.getNetAmount() != null) net += p.getNetAmount();
        }
        run.setTotalGross(gross);
        run.setTotalDeductions(deductions);
        run.setTotalNet(net);
    }

    private String nextStatus(PayrollStatus s) {
        PayrollStatus[] all = PayrollStatus.values();
        return s.ordinal() + 1 < all.length ? all[s.ordinal() + 1].name() : "none (already final)";
    }

    private PayrollRunDTO toDto(PayrollRun e) {
        PayrollRunDTO dto = new PayrollRunDTO();
        dto.setPayrollRunId(e.getPayrollRunId());
        dto.setMonth(e.getMonth());
        dto.setYear(e.getYear());
        dto.setProcessedBy(e.getProcessedByUser() != null ? e.getProcessedByUser().getUserId() : null);
        dto.setProcessedDate(e.getProcessedDate());
        dto.setTotalGross(e.getTotalGross());
        dto.setTotalDeductions(e.getTotalDeductions());
        dto.setTotalNet(e.getTotalNet());
        dto.setStatus(e.getStatus());
        return dto;
    }

    private User resolveUser(Long id) {
        if (id == null) {
            return null;
        }
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }
}
