package com.talentpulse.serviceimpl;

import com.talentpulse.dto.PayslipDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.PayrollRun;
import com.talentpulse.entity.Payslip;
import com.talentpulse.entity.SalaryStructure;
import com.talentpulse.enums.PayslipStatus;
import com.talentpulse.exception.BadRequestException;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.PayrollRunRepository;
import com.talentpulse.repository.PayslipRepository;
import com.talentpulse.repository.SalaryStructureRepository;
import com.talentpulse.service.PayslipService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PayslipServiceImpl implements PayslipService {

    private final PayslipRepository payslipRepository;
    private final PayrollRunRepository payrollRunRepository;
    private final EmployeeRepository employeeRepository;
    private final SalaryStructureRepository salaryStructureRepository;
    private final GradeStructureRepository gradeStructureRepository;

    public PayslipServiceImpl(PayslipRepository payslipRepository,
                              PayrollRunRepository payrollRunRepository,
                              EmployeeRepository employeeRepository,
                              SalaryStructureRepository salaryStructureRepository,
                              GradeStructureRepository gradeStructureRepository) {
        this.payslipRepository = payslipRepository;
        this.payrollRunRepository = payrollRunRepository;
        this.employeeRepository = employeeRepository;
        this.salaryStructureRepository = salaryStructureRepository;
        this.gradeStructureRepository = gradeStructureRepository;
    }

    @Override
    public List<PayslipDTO> getAll() {
        return payslipRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public PayslipDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public PayslipDTO create(PayslipDTO dto) {
        Payslip entity = toEntity(dto, new Payslip());
        return toDto(payslipRepository.save(entity));
    }

    @Override
    public PayslipDTO update(Long id, PayslipDTO dto) {
        Payslip entity = toEntity(dto, findEntity(id));
        return toDto(payslipRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        payslipRepository.delete(findEntity(id));
    }

    private Payslip findEntity(Long id) {
        return payslipRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payslip", id));
    }

    // ---- mapping + business logic ----

    private Payslip toEntity(PayslipDTO dto, Payslip e) {
        PayrollRun run = resolvePayrollRun(dto.getPayrollRunId());
        Employee employee = resolveEmployee(dto.getEmployeeId());

        Double gross = dto.getGrossAmount();
        Double deductions = dto.getTotalDeductions();

        // The salary structure of the employee's grade drives auto-calculation.
        SalaryStructure structure = (gross == null || deductions == null) ? findStructure(employee) : null;

        // If gross is not supplied, derive it: base*(basic% + HRA%) + allowances.
        if (gross == null) {
            GradeStructure grade = loadGrade(employee);
            if (structure == null || grade == null) {
                throw new BadRequestException(
                        "grossAmount is required: it could not be derived because the employee has no grade salary structure.");
            }
            gross = computeGross(grade, structure);
        }
        if (gross < 0) {
            throw new BadRequestException("grossAmount must be >= 0.");
        }

        // If deductions are not supplied, derive them from the deduction rules applied to gross.
        if (deductions == null) {
            deductions = structure != null ? parseAmountRules(structure.getDeductionRules(), gross) : 0.0;
        }
        if (deductions < 0) {
            throw new BadRequestException("totalDeductions must be >= 0.");
        }
        if (deductions > gross) {
            throw new BadRequestException(
                    "totalDeductions (" + deductions + ") cannot exceed grossAmount (" + gross + ").");
        }

        e.setPayrollRun(run);
        e.setEmployee(employee);
        e.setGrossAmount(gross);
        e.setTotalDeductions(deductions);
        e.setNetAmount(gross - deductions); // net is always derived
        e.setPayslipDate(dto.getPayslipDate());
        e.setStatus(dto.getStatus() != null ? dto.getStatus() : PayslipStatus.GENERATED);
        return e;
    }

    /** Gross = base*(basicPercent + hraPercent)/100 + allowances, where base = grade.minSalary. */
    private double computeGross(GradeStructure grade, SalaryStructure structure) {
        double base = grade.getMinSalary() != null ? grade.getMinSalary() : 0.0;
        double basicAndHra = base * (nz(structure.getBasicPercent()) + nz(structure.getHraPercent())) / 100.0;
        double allowances = parseAmountRules(structure.getAllowances(), base);
        return round(basicAndHra + allowances);
    }

    /** Most recent SalaryStructure for the employee's grade, or null. */
    private SalaryStructure findStructure(Employee employee) {
        if (employee == null || employee.getGrade() == null) {
            return null;
        }
        return salaryStructureRepository.findByGrade_GradeId(employee.getGrade().getGradeId()).stream()
                .max(Comparator.comparing(s -> s.getEffectiveDate() != null ? s.getEffectiveDate() : LocalDate.MIN))
                .orElse(null);
    }

    private GradeStructure loadGrade(Employee employee) {
        if (employee == null || employee.getGrade() == null) {
            return null;
        }
        return gradeStructureRepository.findById(employee.getGrade().getGradeId()).orElse(null);
    }

    /**
     * Parses rules like "PF:12%;ProfTax:200" / "Travel:5000;Medical:2000":
     * a value ending in % is a percentage of {@code base}, otherwise a flat amount.
     */
    private double parseAmountRules(String rules, double base) {
        if (rules == null || rules.isBlank()) {
            return 0.0;
        }
        double total = 0.0;
        for (String part : rules.split(";")) {
            String[] kv = part.split(":");
            if (kv.length != 2) {
                continue;
            }
            String value = kv[1].trim();
            try {
                if (value.endsWith("%")) {
                    double percent = Double.parseDouble(value.substring(0, value.length() - 1).trim());
                    total += base * percent / 100.0;
                } else {
                    total += Double.parseDouble(value);
                }
            } catch (NumberFormatException ignored) {
                // skip malformed parts
            }
        }
        return round(total);
    }

    private double nz(Double d) {
        return d != null ? d : 0.0;
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private PayrollRun resolvePayrollRun(Long id) {
        if (id == null) {
            return null;
        }
        return payrollRunRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PayrollRun", id));
    }

    private Employee resolveEmployee(Long id) {
        if (id == null) {
            return null;
        }
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }

    private PayslipDTO toDto(Payslip e) {
        PayslipDTO dto = new PayslipDTO();
        dto.setPayslipId(e.getPayslipId());
        dto.setPayrollRunId(e.getPayrollRun() != null ? e.getPayrollRun().getPayrollRunId() : null);
        dto.setEmployeeId(e.getEmployee() != null ? e.getEmployee().getEmployeeId() : null);
        dto.setGrossAmount(e.getGrossAmount());
        dto.setTotalDeductions(e.getTotalDeductions());
        dto.setNetAmount(e.getNetAmount());
        dto.setPayslipDate(e.getPayslipDate());
        dto.setStatus(e.getStatus());
        return dto;
    }
}
