package com.talentpulse.serviceimpl;

import com.talentpulse.dto.DepartmentDTO;
import com.talentpulse.entity.Department;
import com.talentpulse.entity.User;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.DepartmentRepository;
import com.talentpulse.repository.UserRepository;
import com.talentpulse.service.DepartmentService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final UserRepository userRepository;

    public DepartmentServiceImpl(DepartmentRepository departmentRepository,
                                 UserRepository userRepository) {
        this.departmentRepository = departmentRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<DepartmentDTO> getAll() {
        return departmentRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public DepartmentDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public DepartmentDTO create(DepartmentDTO dto) {
        Department entity = toEntity(dto, new Department());
        return toDto(departmentRepository.save(entity));
    }

    @Override
    public DepartmentDTO update(Long id, DepartmentDTO dto) {
        Department entity = toEntity(dto, findEntity(id));
        return toDto(departmentRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        departmentRepository.delete(findEntity(id));
    }

    private Department findEntity(Long id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department", id));
    }

    private User resolveUser(Long id) {
        if (id == null) {
            return null;
        }
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }

    // ---- mapping helpers ----

    private DepartmentDTO toDto(Department e) {
        DepartmentDTO dto = new DepartmentDTO();
        dto.setDepartmentId(e.getDepartmentId());
        dto.setDepartmentName(e.getDepartmentName());
        dto.setCostCentreCode(e.getCostCentreCode());
        dto.setHrbpUserId(e.getHrbpUser() != null ? e.getHrbpUser().getUserId() : null);
        dto.setStatus(e.getStatus());
        return dto;
    }

    private Department toEntity(DepartmentDTO dto, Department e) {
        e.setDepartmentName(dto.getDepartmentName());
        e.setCostCentreCode(dto.getCostCentreCode());
        e.setHrbpUser(resolveUser(dto.getHrbpUserId()));
        e.setStatus(dto.getStatus());
        return e;
    }
}
