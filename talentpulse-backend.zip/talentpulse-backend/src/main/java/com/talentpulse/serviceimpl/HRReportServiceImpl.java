package com.talentpulse.serviceimpl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.talentpulse.dto.HRReportDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GoalSheet;
import com.talentpulse.entity.HRReport;
import com.talentpulse.entity.LeaveBalance;
import com.talentpulse.entity.Payslip;
import com.talentpulse.enums.EmployeeStatus;
import com.talentpulse.enums.ReportScope;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GoalSheetRepository;
import com.talentpulse.repository.HRReportRepository;
import com.talentpulse.repository.LeaveBalanceRepository;
import com.talentpulse.repository.PayslipRepository;
import com.talentpulse.service.HRReportService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class HRReportServiceImpl implements HRReportService {

    private final HRReportRepository hrReportRepository;
    private final EmployeeRepository employeeRepository;
    private final PayslipRepository payslipRepository;
    private final LeaveBalanceRepository leaveBalanceRepository;
    private final GoalSheetRepository goalSheetRepository;

    public HRReportServiceImpl(HRReportRepository hrReportRepository,
                               EmployeeRepository employeeRepository,
                               PayslipRepository payslipRepository,
                               LeaveBalanceRepository leaveBalanceRepository,
                               GoalSheetRepository goalSheetRepository) {
        this.hrReportRepository = hrReportRepository;
        this.employeeRepository = employeeRepository;
        this.payslipRepository = payslipRepository;
        this.leaveBalanceRepository = leaveBalanceRepository;
        this.goalSheetRepository = goalSheetRepository;
    }

    @Override
    public List<HRReportDTO> getAll() {
        return hrReportRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public HRReportDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public HRReportDTO create(HRReportDTO dto) {
        HRReport entity = toEntity(dto, new HRReport());
        return toDto(hrReportRepository.save(entity));
    }

    @Override
    public HRReportDTO update(Long id, HRReportDTO dto) {
        HRReport entity = toEntity(dto, findEntity(id));
        return toDto(hrReportRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        hrReportRepository.delete(findEntity(id));
    }

    /**
     * Computes the metrics live from current data, then saves and returns the report.
     */
    @Override
    public HRReportDTO generate(ReportScope scope) {
        List<Employee> employees = employeeRepository.findAll();
        List<Payslip> payslips = payslipRepository.findAll();
        List<LeaveBalance> balances = leaveBalanceRepository.findAll();
        List<GoalSheet> goals = goalSheetRepository.findAll();

        int headcount = employees.size();
        long active = employees.stream().filter(e -> e.getStatus() == EmployeeStatus.ACTIVE).count();
        long exited = employees.stream()
                .filter(e -> e.getStatus() == EmployeeStatus.EXITED || e.getStatus() == EmployeeStatus.RESIGNED)
                .count();
        double attritionRate = headcount == 0 ? 0.0 : round(exited * 100.0 / headcount);

        double avgTenureYears = round(employees.stream()
                .filter(e -> e.getJoiningDate() != null)
                .mapToDouble(e -> ChronoUnit.DAYS.between(e.getJoiningDate(), LocalDate.now()) / 365.25)
                .average().orElse(0.0));

        double payrollCost = round(payslips.stream()
                .filter(p -> p.getNetAmount() != null)
                .mapToDouble(Payslip::getNetAmount).sum());

        double entitled = balances.stream().filter(b -> b.getEntitled() != null)
                .mapToDouble(LeaveBalance::getEntitled).sum();
        double taken = balances.stream().filter(b -> b.getTaken() != null)
                .mapToDouble(LeaveBalance::getTaken).sum();
        double leaveUtilisation = entitled == 0 ? 0.0 : round(taken * 100.0 / entitled);

        Map<String, Long> performanceDistribution = new LinkedHashMap<>();
        performanceDistribution.put("A (>=4)", goals.stream()
                .filter(g -> g.getFinalRating() != null && g.getFinalRating() >= 4.0).count());
        performanceDistribution.put("B (3-4)", goals.stream()
                .filter(g -> g.getFinalRating() != null && g.getFinalRating() >= 3.0 && g.getFinalRating() < 4.0).count());
        performanceDistribution.put("C (<3)", goals.stream()
                .filter(g -> g.getFinalRating() != null && g.getFinalRating() < 3.0).count());

        Map<String, Object> metrics = new LinkedHashMap<>();
        metrics.put("Headcount", headcount);
        metrics.put("ActiveHeadcount", active);
        metrics.put("AttritionRate", attritionRate);
        metrics.put("AvgTenureYears", avgTenureYears);
        metrics.put("PayrollCost", payrollCost);
        metrics.put("LeaveUtilisation", leaveUtilisation);
        metrics.put("PerformanceDistribution", performanceDistribution);

        // Scope-specific breakdown (reads only the association id, no lazy load needed).
        if (scope == ReportScope.DEPARTMENT) {
            Map<Long, Long> byDepartment = employees.stream()
                    .filter(e -> e.getDepartment() != null)
                    .collect(Collectors.groupingBy(e -> e.getDepartment().getDepartmentId(), Collectors.counting()));
            metrics.put("HeadcountByDepartment", byDepartment);
        } else if (scope == ReportScope.GRADE) {
            Map<Long, Long> byGrade = employees.stream()
                    .filter(e -> e.getGrade() != null)
                    .collect(Collectors.groupingBy(e -> e.getGrade().getGradeId(), Collectors.counting()));
            metrics.put("HeadcountByGrade", byGrade);
        }

        HRReport entity = new HRReport();
        entity.setScope(scope);
        entity.setGeneratedDate(LocalDate.now());
        entity.setMetrics(toJson(metrics));
        return toDto(hrReportRepository.save(entity));
    }

    private HRReport findEntity(Long id) {
        return hrReportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("HRReport", id));
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    private String toJson(Map<String, Object> map) {
        try {
            return new ObjectMapper().writeValueAsString(map);
        } catch (Exception ex) {
            return "{}";
        }
    }

    // ---- mapping helpers ----

    private HRReportDTO toDto(HRReport e) {
        HRReportDTO dto = new HRReportDTO();
        dto.setReportId(e.getReportId());
        dto.setScope(e.getScope());
        dto.setMetrics(e.getMetrics());
        dto.setGeneratedDate(e.getGeneratedDate());
        return dto;
    }

    private HRReport toEntity(HRReportDTO dto, HRReport e) {
        e.setScope(dto.getScope());
        e.setMetrics(dto.getMetrics());
        e.setGeneratedDate(dto.getGeneratedDate());
        return e;
    }
}
