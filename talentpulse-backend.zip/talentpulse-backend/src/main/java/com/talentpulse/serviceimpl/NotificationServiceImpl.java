package com.talentpulse.serviceimpl;

import com.talentpulse.dto.NotificationDTO;
import com.talentpulse.entity.Notification;
import com.talentpulse.entity.User;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.NotificationRepository;
import com.talentpulse.repository.UserRepository;
import com.talentpulse.service.NotificationService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    public NotificationServiceImpl(NotificationRepository notificationRepository, UserRepository userRepository) {
        this.notificationRepository = notificationRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<NotificationDTO> getAll() {
        return notificationRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public NotificationDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public NotificationDTO create(NotificationDTO dto) {
        if (dto.getCreatedDate() == null) {
            dto.setCreatedDate(LocalDateTime.now());
        }
        Notification entity = toEntity(dto, new Notification());
        return toDto(notificationRepository.save(entity));
    }

    @Override
    public NotificationDTO update(Long id, NotificationDTO dto) {
        Notification entity = toEntity(dto, findEntity(id));
        return toDto(notificationRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        notificationRepository.delete(findEntity(id));
    }

    private Notification findEntity(Long id) {
        return notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification", id));
    }

    // ---- mapping helpers ----

    private NotificationDTO toDto(Notification e) {
        NotificationDTO dto = new NotificationDTO();
        dto.setNotificationId(e.getNotificationId());
        dto.setUserId(e.getUser() != null ? e.getUser().getUserId() : null);
        dto.setMessage(e.getMessage());
        dto.setCategory(e.getCategory());
        dto.setStatus(e.getStatus());
        dto.setCreatedDate(e.getCreatedDate());
        return dto;
    }

    private Notification toEntity(NotificationDTO dto, Notification e) {
        e.setUser(resolveUser(dto.getUserId()));
        e.setMessage(dto.getMessage());
        e.setCategory(dto.getCategory());
        e.setStatus(dto.getStatus());
        e.setCreatedDate(dto.getCreatedDate());
        return e;
    }

    private User resolveUser(Long id) {
        if (id == null) return null;
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }
}
