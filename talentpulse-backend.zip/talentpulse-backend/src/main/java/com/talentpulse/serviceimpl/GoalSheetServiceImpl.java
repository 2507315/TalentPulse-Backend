package com.talentpulse.serviceimpl;

import com.talentpulse.dto.GoalSheetDTO;
import com.talentpulse.entity.AppraisalCycle;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GoalSheet;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AppraisalCycleRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GoalSheetRepository;
import com.talentpulse.service.GoalSheetService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GoalSheetServiceImpl implements GoalSheetService {

    private final GoalSheetRepository goalSheetRepository;
    private final AppraisalCycleRepository appraisalCycleRepository;
    private final EmployeeRepository employeeRepository;

    public GoalSheetServiceImpl(GoalSheetRepository goalSheetRepository,
                                AppraisalCycleRepository appraisalCycleRepository,
                                EmployeeRepository employeeRepository) {
        this.goalSheetRepository = goalSheetRepository;
        this.appraisalCycleRepository = appraisalCycleRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    public List<GoalSheetDTO> getAll() {
        return goalSheetRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public GoalSheetDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public GoalSheetDTO create(GoalSheetDTO dto) {
        GoalSheet entity = toEntity(dto, new GoalSheet());
        return toDto(goalSheetRepository.save(entity));
    }

    @Override
    public GoalSheetDTO update(Long id, GoalSheetDTO dto) {
        GoalSheet entity = toEntity(dto, findEntity(id));
        return toDto(goalSheetRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        goalSheetRepository.delete(findEntity(id));
    }

    private GoalSheet findEntity(Long id) {
        return goalSheetRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("GoalSheet", id));
    }

    private AppraisalCycle resolveAppraisalCycle(Long id) {
        if (id == null) {
            return null;
        }
        return appraisalCycleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AppraisalCycle", id));
    }

    private Employee resolveEmployee(Long id) {
        if (id == null) {
            return null;
        }
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }

    // ---- mapping helpers ----

    private GoalSheetDTO toDto(GoalSheet e) {
        GoalSheetDTO dto = new GoalSheetDTO();
        dto.setGoalSheetId(e.getGoalSheetId());
        dto.setCycleId(e.getCycle() != null ? e.getCycle().getCycleId() : null);
        dto.setEmployeeId(e.getEmployee() != null ? e.getEmployee().getEmployeeId() : null);
        dto.setManagerId(e.getManager() != null ? e.getManager().getEmployeeId() : null);
        dto.setGoalsJson(e.getGoalsJson());
        dto.setSelfRating(e.getSelfRating());
        dto.setManagerRating(e.getManagerRating());
        dto.setFinalRating(e.getFinalRating());
        dto.setStatus(e.getStatus());
        return dto;
    }

    private GoalSheet toEntity(GoalSheetDTO dto, GoalSheet e) {
        e.setCycle(resolveAppraisalCycle(dto.getCycleId()));
        e.setEmployee(resolveEmployee(dto.getEmployeeId()));
        e.setManager(resolveEmployee(dto.getManagerId()));
        e.setGoalsJson(dto.getGoalsJson());
        e.setSelfRating(dto.getSelfRating());
        e.setManagerRating(dto.getManagerRating());
        e.setFinalRating(dto.getFinalRating());
        e.setStatus(dto.getStatus());
        return e;
    }
}
