package com.talentpulse.serviceimpl;

import com.talentpulse.dto.GradeStructureDTO;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.service.GradeStructureService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GradeStructureServiceImpl implements GradeStructureService {

    private final GradeStructureRepository gradeStructureRepository;

    public GradeStructureServiceImpl(GradeStructureRepository gradeStructureRepository) {
        this.gradeStructureRepository = gradeStructureRepository;
    }

    @Override
    public List<GradeStructureDTO> getAll() {
        return gradeStructureRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public GradeStructureDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public GradeStructureDTO create(GradeStructureDTO dto) {
        GradeStructure entity = toEntity(dto, new GradeStructure());
        return toDto(gradeStructureRepository.save(entity));
    }

    @Override
    public GradeStructureDTO update(Long id, GradeStructureDTO dto) {
        GradeStructure entity = toEntity(dto, findEntity(id));
        return toDto(gradeStructureRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        gradeStructureRepository.delete(findEntity(id));
    }

    private GradeStructure findEntity(Long id) {
        return gradeStructureRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("GradeStructure", id));
    }

    // ---- mapping helpers ----

    private GradeStructureDTO toDto(GradeStructure e) {
        GradeStructureDTO dto = new GradeStructureDTO();
        dto.setGradeId(e.getGradeId());
        dto.setGradeName(e.getGradeName());
        dto.setBand(e.getBand());
        dto.setMinSalary(e.getMinSalary());
        dto.setMaxSalary(e.getMaxSalary());
        dto.setLeaveEntitlement(e.getLeaveEntitlement());
        return dto;
    }

    private GradeStructure toEntity(GradeStructureDTO dto, GradeStructure e) {
        e.setGradeName(dto.getGradeName());
        e.setBand(dto.getBand());
        e.setMinSalary(dto.getMinSalary());
        e.setMaxSalary(dto.getMaxSalary());
        e.setLeaveEntitlement(dto.getLeaveEntitlement());
        return e;
    }
}
