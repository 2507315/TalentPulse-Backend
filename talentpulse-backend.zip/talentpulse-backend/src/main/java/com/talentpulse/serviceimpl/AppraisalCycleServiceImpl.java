package com.talentpulse.serviceimpl;

import com.talentpulse.dto.AppraisalCycleDTO;
import com.talentpulse.entity.AppraisalCycle;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AppraisalCycleRepository;
import com.talentpulse.service.AppraisalCycleService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AppraisalCycleServiceImpl implements AppraisalCycleService {

    private final AppraisalCycleRepository appraisalCycleRepository;

    public AppraisalCycleServiceImpl(AppraisalCycleRepository appraisalCycleRepository) {
        this.appraisalCycleRepository = appraisalCycleRepository;
    }

    @Override
    public List<AppraisalCycleDTO> getAll() {
        return appraisalCycleRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public AppraisalCycleDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public AppraisalCycleDTO create(AppraisalCycleDTO dto) {
        AppraisalCycle entity = toEntity(dto, new AppraisalCycle());
        return toDto(appraisalCycleRepository.save(entity));
    }

    @Override
    public AppraisalCycleDTO update(Long id, AppraisalCycleDTO dto) {
        AppraisalCycle entity = toEntity(dto, findEntity(id));
        return toDto(appraisalCycleRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        appraisalCycleRepository.delete(findEntity(id));
    }

    private AppraisalCycle findEntity(Long id) {
        return appraisalCycleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AppraisalCycle", id));
    }

    // ---- mapping helpers ----

    private AppraisalCycleDTO toDto(AppraisalCycle e) {
        AppraisalCycleDTO dto = new AppraisalCycleDTO();
        dto.setCycleId(e.getCycleId());
        dto.setName(e.getName());
        dto.setYear(e.getYear());
        dto.setType(e.getType());
        dto.setGoalSettingStart(e.getGoalSettingStart());
        dto.setGoalSettingEnd(e.getGoalSettingEnd());
        dto.setReviewStart(e.getReviewStart());
        dto.setReviewEnd(e.getReviewEnd());
        dto.setStatus(e.getStatus());
        return dto;
    }

    private AppraisalCycle toEntity(AppraisalCycleDTO dto, AppraisalCycle e) {
        e.setName(dto.getName());
        e.setYear(dto.getYear());
        e.setType(dto.getType());
        e.setGoalSettingStart(dto.getGoalSettingStart());
        e.setGoalSettingEnd(dto.getGoalSettingEnd());
        e.setReviewStart(dto.getReviewStart());
        e.setReviewEnd(dto.getReviewEnd());
        e.setStatus(dto.getStatus());
        return e;
    }
}
