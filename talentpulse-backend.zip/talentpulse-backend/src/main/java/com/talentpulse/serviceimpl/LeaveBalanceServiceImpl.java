package com.talentpulse.serviceimpl;

import com.talentpulse.dto.LeaveBalanceDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.LeaveBalance;
import com.talentpulse.entity.LeaveType;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.LeaveBalanceRepository;
import com.talentpulse.repository.LeaveTypeRepository;
import com.talentpulse.service.LeaveBalanceService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LeaveBalanceServiceImpl implements LeaveBalanceService {

    private final LeaveBalanceRepository leaveBalanceRepository;
    private final EmployeeRepository employeeRepository;
    private final LeaveTypeRepository leaveTypeRepository;

    public LeaveBalanceServiceImpl(LeaveBalanceRepository leaveBalanceRepository,
                                   EmployeeRepository employeeRepository,
                                   LeaveTypeRepository leaveTypeRepository) {
        this.leaveBalanceRepository = leaveBalanceRepository;
        this.employeeRepository = employeeRepository;
        this.leaveTypeRepository = leaveTypeRepository;
    }

    @Override
    public List<LeaveBalanceDTO> getAll() {
        return leaveBalanceRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public LeaveBalanceDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public LeaveBalanceDTO create(LeaveBalanceDTO dto) {
        LeaveBalance entity = toEntity(dto, new LeaveBalance());
        return toDto(leaveBalanceRepository.save(entity));
    }

    @Override
    public LeaveBalanceDTO update(Long id, LeaveBalanceDTO dto) {
        LeaveBalance entity = toEntity(dto, findEntity(id));
        return toDto(leaveBalanceRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        leaveBalanceRepository.delete(findEntity(id));
    }

    private LeaveBalance findEntity(Long id) {
        return leaveBalanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("LeaveBalance", id));
    }

    // ---- mapping helpers ----

    private LeaveBalanceDTO toDto(LeaveBalance e) {
        LeaveBalanceDTO dto = new LeaveBalanceDTO();
        dto.setBalanceId(e.getBalanceId());
        dto.setEmployeeId(e.getEmployee() != null ? e.getEmployee().getEmployeeId() : null);
        dto.setLeaveTypeId(e.getLeaveType() != null ? e.getLeaveType().getLeaveTypeId() : null);
        dto.setYear(e.getYear());
        dto.setEntitled(e.getEntitled());
        dto.setTaken(e.getTaken());
        dto.setPending(e.getPending());
        dto.setBalance(e.getBalance());
        return dto;
    }

    private LeaveBalance toEntity(LeaveBalanceDTO dto, LeaveBalance e) {
        e.setEmployee(resolveEmployee(dto.getEmployeeId()));
        e.setLeaveType(resolveLeaveType(dto.getLeaveTypeId()));
        e.setYear(dto.getYear());
        e.setEntitled(dto.getEntitled());
        e.setTaken(dto.getTaken());
        e.setPending(dto.getPending());
        e.setBalance(dto.getBalance());
        return e;
    }

    private Employee resolveEmployee(Long id) {
        if (id == null) {
            return null;
        }
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }

    private LeaveType resolveLeaveType(Long id) {
        if (id == null) {
            return null;
        }
        return leaveTypeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("LeaveType", id));
    }
}
