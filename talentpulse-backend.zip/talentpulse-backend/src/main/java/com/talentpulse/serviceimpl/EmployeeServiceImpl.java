package com.talentpulse.serviceimpl;

import com.talentpulse.dto.EmployeeDTO;
import com.talentpulse.entity.Department;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.DepartmentRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.service.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final GradeStructureRepository gradeStructureRepository;
    private final DepartmentRepository departmentRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository,
                               GradeStructureRepository gradeStructureRepository,
                               DepartmentRepository departmentRepository) {
        this.employeeRepository = employeeRepository;
        this.gradeStructureRepository = gradeStructureRepository;
        this.departmentRepository = departmentRepository;
    }

    @Override
    public List<EmployeeDTO> getAll() {
        return employeeRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public EmployeeDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public EmployeeDTO create(EmployeeDTO dto) {
        Employee entity = toEntity(dto, new Employee());
        return toDto(employeeRepository.save(entity));
    }

    @Override
    public EmployeeDTO update(Long id, EmployeeDTO dto) {
        Employee entity = toEntity(dto, findEntity(id));
        return toDto(employeeRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        employeeRepository.delete(findEntity(id));
    }

    private Employee findEntity(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }

    private GradeStructure resolveGradeStructure(Long id) {
        if (id == null) {
            return null;
        }
        return gradeStructureRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("GradeStructure", id));
    }

    private Department resolveDepartment(Long id) {
        if (id == null) {
            return null;
        }
        return departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department", id));
    }

    private Employee resolveEmployee(Long id) {
        if (id == null) {
            return null;
        }
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }

    // ---- mapping helpers ----

    private EmployeeDTO toDto(Employee e) {
        EmployeeDTO dto = new EmployeeDTO();
        dto.setEmployeeId(e.getEmployeeId());
        dto.setName(e.getName());
        dto.setDateOfBirth(e.getDateOfBirth());
        dto.setGender(e.getGender());
        dto.setDesignation(e.getDesignation());
        dto.setGradeId(e.getGrade() != null ? e.getGrade().getGradeId() : null);
        dto.setDepartmentId(e.getDepartment() != null ? e.getDepartment().getDepartmentId() : null);
        dto.setReportingManagerId(e.getReportingManager() != null ? e.getReportingManager().getEmployeeId() : null);
        dto.setJoiningDate(e.getJoiningDate());
        dto.setEmploymentType(e.getEmploymentType());
        dto.setStatus(e.getStatus());
        return dto;
    }

    private Employee toEntity(EmployeeDTO dto, Employee e) {
        e.setName(dto.getName());
        e.setDateOfBirth(dto.getDateOfBirth());
        e.setGender(dto.getGender());
        e.setDesignation(dto.getDesignation());
        e.setGrade(resolveGradeStructure(dto.getGradeId()));
        e.setDepartment(resolveDepartment(dto.getDepartmentId()));
        e.setReportingManager(resolveEmployee(dto.getReportingManagerId()));
        e.setJoiningDate(dto.getJoiningDate());
        e.setEmploymentType(dto.getEmploymentType());
        e.setStatus(dto.getStatus());
        return e;
    }
}
