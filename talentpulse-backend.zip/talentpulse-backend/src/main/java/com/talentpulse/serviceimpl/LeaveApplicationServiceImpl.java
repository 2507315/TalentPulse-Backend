package com.talentpulse.serviceimpl;

import com.talentpulse.dto.LeaveApplicationDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.LeaveApplication;
import com.talentpulse.entity.LeaveType;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.LeaveApplicationRepository;
import com.talentpulse.repository.LeaveTypeRepository;
import com.talentpulse.service.LeaveApplicationService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LeaveApplicationServiceImpl implements LeaveApplicationService {

    private final LeaveApplicationRepository leaveApplicationRepository;
    private final EmployeeRepository employeeRepository;
    private final LeaveTypeRepository leaveTypeRepository;

    public LeaveApplicationServiceImpl(LeaveApplicationRepository leaveApplicationRepository,
                                       EmployeeRepository employeeRepository,
                                       LeaveTypeRepository leaveTypeRepository) {
        this.leaveApplicationRepository = leaveApplicationRepository;
        this.employeeRepository = employeeRepository;
        this.leaveTypeRepository = leaveTypeRepository;
    }

    @Override
    public List<LeaveApplicationDTO> getAll() {
        return leaveApplicationRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public LeaveApplicationDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public LeaveApplicationDTO create(LeaveApplicationDTO dto) {
        LeaveApplication entity = toEntity(dto, new LeaveApplication());
        return toDto(leaveApplicationRepository.save(entity));
    }

    @Override
    public LeaveApplicationDTO update(Long id, LeaveApplicationDTO dto) {
        LeaveApplication entity = toEntity(dto, findEntity(id));
        return toDto(leaveApplicationRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        leaveApplicationRepository.delete(findEntity(id));
    }

    private LeaveApplication findEntity(Long id) {
        return leaveApplicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("LeaveApplication", id));
    }

    // ---- mapping helpers ----

    private LeaveApplicationDTO toDto(LeaveApplication e) {
        LeaveApplicationDTO dto = new LeaveApplicationDTO();
        dto.setApplicationId(e.getApplicationId());
        dto.setEmployeeId(e.getEmployee() != null ? e.getEmployee().getEmployeeId() : null);
        dto.setLeaveTypeId(e.getLeaveType() != null ? e.getLeaveType().getLeaveTypeId() : null);
        dto.setFromDate(e.getFromDate());
        dto.setToDate(e.getToDate());
        dto.setDaysRequested(e.getDaysRequested());
        dto.setReason(e.getReason());
        dto.setApproverId(e.getApprover() != null ? e.getApprover().getEmployeeId() : null);
        dto.setStatus(e.getStatus());
        return dto;
    }

    private LeaveApplication toEntity(LeaveApplicationDTO dto, LeaveApplication e) {
        e.setEmployee(resolveEmployee(dto.getEmployeeId()));
        e.setLeaveType(resolveLeaveType(dto.getLeaveTypeId()));
        e.setFromDate(dto.getFromDate());
        e.setToDate(dto.getToDate());
        e.setDaysRequested(dto.getDaysRequested());
        e.setReason(dto.getReason());
        e.setApprover(resolveEmployee(dto.getApproverId()));
        e.setStatus(dto.getStatus());
        return e;
    }

    private Employee resolveEmployee(Long id) {
        if (id == null) {
            return null;
        }
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }

    private LeaveType resolveLeaveType(Long id) {
        if (id == null) {
            return null;
        }
        return leaveTypeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("LeaveType", id));
    }
}
