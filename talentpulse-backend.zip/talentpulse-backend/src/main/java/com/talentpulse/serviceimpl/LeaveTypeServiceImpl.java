package com.talentpulse.serviceimpl;

import com.talentpulse.dto.LeaveTypeDTO;
import com.talentpulse.entity.LeaveType;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.LeaveTypeRepository;
import com.talentpulse.service.LeaveTypeService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class LeaveTypeServiceImpl implements LeaveTypeService {

    private final LeaveTypeRepository leaveTypeRepository;

    public LeaveTypeServiceImpl(LeaveTypeRepository leaveTypeRepository) {
        this.leaveTypeRepository = leaveTypeRepository;
    }

    @Override
    public List<LeaveTypeDTO> getAll() {
        return leaveTypeRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public LeaveTypeDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public LeaveTypeDTO create(LeaveTypeDTO dto) {
        LeaveType entity = toEntity(dto, new LeaveType());
        return toDto(leaveTypeRepository.save(entity));
    }

    @Override
    public LeaveTypeDTO update(Long id, LeaveTypeDTO dto) {
        LeaveType entity = toEntity(dto, findEntity(id));
        return toDto(leaveTypeRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        leaveTypeRepository.delete(findEntity(id));
    }

    private LeaveType findEntity(Long id) {
        return leaveTypeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("LeaveType", id));
    }

    // ---- mapping helpers ----

    private LeaveTypeDTO toDto(LeaveType e) {
        LeaveTypeDTO dto = new LeaveTypeDTO();
        dto.setLeaveTypeId(e.getLeaveTypeId());
        dto.setName(e.getName());
        dto.setAnnualQuota(e.getAnnualQuota());
        dto.setCarryForwardAllowed(e.getCarryForwardAllowed());
        dto.setRequiresApproval(e.getRequiresApproval());
        return dto;
    }

    private LeaveType toEntity(LeaveTypeDTO dto, LeaveType e) {
        e.setName(dto.getName());
        e.setAnnualQuota(dto.getAnnualQuota());
        e.setCarryForwardAllowed(dto.getCarryForwardAllowed());
        e.setRequiresApproval(dto.getRequiresApproval());
        return e;
    }
}
