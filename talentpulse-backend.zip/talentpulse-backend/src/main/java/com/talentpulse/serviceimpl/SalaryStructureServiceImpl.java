package com.talentpulse.serviceimpl;

import com.talentpulse.dto.SalaryStructureDTO;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.SalaryStructure;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.SalaryStructureRepository;
import com.talentpulse.service.SalaryStructureService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SalaryStructureServiceImpl implements SalaryStructureService {

    private final SalaryStructureRepository salaryStructureRepository;
    private final GradeStructureRepository gradeStructureRepository;

    public SalaryStructureServiceImpl(SalaryStructureRepository salaryStructureRepository,
                                      GradeStructureRepository gradeStructureRepository) {
        this.salaryStructureRepository = salaryStructureRepository;
        this.gradeStructureRepository = gradeStructureRepository;
    }

    @Override
    public List<SalaryStructureDTO> getAll() {
        return salaryStructureRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public SalaryStructureDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public SalaryStructureDTO create(SalaryStructureDTO dto) {
        SalaryStructure entity = toEntity(dto, new SalaryStructure());
        return toDto(salaryStructureRepository.save(entity));
    }

    @Override
    public SalaryStructureDTO update(Long id, SalaryStructureDTO dto) {
        SalaryStructure entity = toEntity(dto, findEntity(id));
        return toDto(salaryStructureRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        salaryStructureRepository.delete(findEntity(id));
    }

    private SalaryStructure findEntity(Long id) {
        return salaryStructureRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SalaryStructure", id));
    }

    // ---- mapping helpers ----

    private SalaryStructureDTO toDto(SalaryStructure e) {
        SalaryStructureDTO dto = new SalaryStructureDTO();
        dto.setStructureId(e.getStructureId());
        dto.setGradeId(e.getGrade() != null ? e.getGrade().getGradeId() : null);
        dto.setBasicPercent(e.getBasicPercent());
        dto.setHraPercent(e.getHraPercent());
        dto.setAllowances(e.getAllowances());
        dto.setDeductionRules(e.getDeductionRules());
        dto.setEffectiveDate(e.getEffectiveDate());
        return dto;
    }

    private SalaryStructure toEntity(SalaryStructureDTO dto, SalaryStructure e) {
        e.setGrade(resolveGradeStructure(dto.getGradeId()));
        e.setBasicPercent(dto.getBasicPercent());
        e.setHraPercent(dto.getHraPercent());
        e.setAllowances(dto.getAllowances());
        e.setDeductionRules(dto.getDeductionRules());
        e.setEffectiveDate(dto.getEffectiveDate());
        return e;
    }

    private GradeStructure resolveGradeStructure(Long id) {
        if (id == null) {
            return null;
        }
        return gradeStructureRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("GradeStructure", id));
    }
}
