package com.talentpulse.serviceimpl;

import com.talentpulse.dto.AuditLogDTO;
import com.talentpulse.entity.AuditLog;
import com.talentpulse.entity.User;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AuditLogRepository;
import com.talentpulse.repository.UserRepository;
import com.talentpulse.service.AuditLogService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;

    public AuditLogServiceImpl(AuditLogRepository auditLogRepository, UserRepository userRepository) {
        this.auditLogRepository = auditLogRepository;
        this.userRepository = userRepository;
    }

    @Override
    public List<AuditLogDTO> getAll() {
        return auditLogRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public AuditLogDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public AuditLogDTO create(AuditLogDTO dto) {
        AuditLog entity = toEntity(dto, new AuditLog());
        if (entity.getTimestamp() == null) {
            entity.setTimestamp(LocalDateTime.now());
        }
        return toDto(auditLogRepository.save(entity));
    }

    @Override
    public AuditLogDTO update(Long id, AuditLogDTO dto) {
        AuditLog entity = toEntity(dto, findEntity(id));
        return toDto(auditLogRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        auditLogRepository.delete(findEntity(id));
    }

    private AuditLog findEntity(Long id) {
        return auditLogRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AuditLog", id));
    }

    // ---- mapping helpers ----

    private AuditLogDTO toDto(AuditLog e) {
        AuditLogDTO dto = new AuditLogDTO();
        dto.setAuditId(e.getAuditId());
        dto.setUserId(e.getUser() != null ? e.getUser().getUserId() : null);
        dto.setAction(e.getAction());
        dto.setModule(e.getModule());
        dto.setTimestamp(e.getTimestamp());
        return dto;
    }

    private AuditLog toEntity(AuditLogDTO dto, AuditLog e) {
        e.setUser(resolveUser(dto.getUserId()));
        e.setAction(dto.getAction());
        e.setModule(dto.getModule());
        e.setTimestamp(dto.getTimestamp());
        return e;
    }

    private User resolveUser(Long id) {
        if (id == null) return null;
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", id));
    }
}
