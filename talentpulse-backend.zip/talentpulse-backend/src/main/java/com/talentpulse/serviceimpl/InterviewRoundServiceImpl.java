package com.talentpulse.serviceimpl;

import com.talentpulse.dto.InterviewRoundDTO;
import com.talentpulse.entity.Candidate;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.InterviewRound;
import com.talentpulse.entity.JobRequisition;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.CandidateRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.InterviewRoundRepository;
import com.talentpulse.repository.JobRequisitionRepository;
import com.talentpulse.service.InterviewRoundService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class InterviewRoundServiceImpl implements InterviewRoundService {

    private final InterviewRoundRepository interviewRoundRepository;
    private final CandidateRepository candidateRepository;
    private final JobRequisitionRepository jobRequisitionRepository;
    private final EmployeeRepository employeeRepository;

    public InterviewRoundServiceImpl(InterviewRoundRepository interviewRoundRepository,
                                     CandidateRepository candidateRepository,
                                     JobRequisitionRepository jobRequisitionRepository,
                                     EmployeeRepository employeeRepository) {
        this.interviewRoundRepository = interviewRoundRepository;
        this.candidateRepository = candidateRepository;
        this.jobRequisitionRepository = jobRequisitionRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    public List<InterviewRoundDTO> getAll() {
        return interviewRoundRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    @Override
    public InterviewRoundDTO getById(Long id) {
        return toDto(findEntity(id));
    }

    @Override
    public InterviewRoundDTO create(InterviewRoundDTO dto) {
        InterviewRound entity = toEntity(dto, new InterviewRound());
        return toDto(interviewRoundRepository.save(entity));
    }

    @Override
    public InterviewRoundDTO update(Long id, InterviewRoundDTO dto) {
        InterviewRound entity = toEntity(dto, findEntity(id));
        return toDto(interviewRoundRepository.save(entity));
    }

    @Override
    public void delete(Long id) {
        interviewRoundRepository.delete(findEntity(id));
    }

    private InterviewRound findEntity(Long id) {
        return interviewRoundRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("InterviewRound", id));
    }

    // ---- mapping helpers ----

    private InterviewRoundDTO toDto(InterviewRound e) {
        InterviewRoundDTO dto = new InterviewRoundDTO();
        dto.setRoundId(e.getRoundId());
        dto.setCandidateId(e.getCandidate() != null ? e.getCandidate().getCandidateId() : null);
        dto.setRequisitionId(e.getRequisition() != null ? e.getRequisition().getRequisitionId() : null);
        dto.setRoundType(e.getRoundType());
        dto.setInterviewerId(e.getInterviewer() != null ? e.getInterviewer().getEmployeeId() : null);
        dto.setScheduledDate(e.getScheduledDate());
        dto.setOutcome(e.getOutcome());
        dto.setFeedback(e.getFeedback());
        return dto;
    }

    private InterviewRound toEntity(InterviewRoundDTO dto, InterviewRound e) {
        e.setCandidate(resolveCandidate(dto.getCandidateId()));
        e.setRequisition(resolveJobRequisition(dto.getRequisitionId()));
        e.setRoundType(dto.getRoundType());
        e.setInterviewer(resolveEmployee(dto.getInterviewerId()));
        e.setScheduledDate(dto.getScheduledDate());
        e.setOutcome(dto.getOutcome());
        e.setFeedback(dto.getFeedback());
        return e;
    }

    private Candidate resolveCandidate(Long id) {
        if (id == null) {
            return null;
        }
        return candidateRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate", id));
    }

    private JobRequisition resolveJobRequisition(Long id) {
        if (id == null) {
            return null;
        }
        return jobRequisitionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("JobRequisition", id));
    }

    private Employee resolveEmployee(Long id) {
        if (id == null) {
            return null;
        }
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee", id));
    }
}
