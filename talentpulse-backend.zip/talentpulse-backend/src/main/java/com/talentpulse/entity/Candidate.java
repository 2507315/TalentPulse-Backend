package com.talentpulse.entity;

import com.talentpulse.enums.CandidateStatus;
import com.talentpulse.enums.SourceChannel;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Recruitment & Applicant Tracking - candidate.
 */
@Entity
@Table(name = "candidates")
public class Candidate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long candidateId;

    private String name;
    private String email;
    private String phone;
    private String resumeRef;

    /** Portal/Referral/Agency/Campus */
    @Enumerated(EnumType.STRING)
    private SourceChannel sourceChannel;

    /** Applied/Shortlisted/InterviewScheduled/Offered/Joined/Rejected */
    @Enumerated(EnumType.STRING)
    private CandidateStatus status;

    public Long getCandidateId() { return candidateId; }
    public void setCandidateId(Long candidateId) { this.candidateId = candidateId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getResumeRef() { return resumeRef; }
    public void setResumeRef(String resumeRef) { this.resumeRef = resumeRef; }

    public SourceChannel getSourceChannel() { return sourceChannel; }
    public void setSourceChannel(SourceChannel sourceChannel) { this.sourceChannel = sourceChannel; }

    public CandidateStatus getStatus() { return status; }
    public void setStatus(CandidateStatus status) { this.status = status; }
}
