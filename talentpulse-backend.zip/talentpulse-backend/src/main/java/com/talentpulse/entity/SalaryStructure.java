package com.talentpulse.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDate;

/**
 * Payroll & Compensation Management - salary structure for a grade.
 */
@Entity
@Table(name = "salary_structures")
public class SalaryStructure {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long structureId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "grade_id")
    private GradeStructure grade;
    private Double basicPercent;
    private Double hraPercent;

    @Column(length = 1000)
    private String allowances;

    @Column(length = 1000)
    private String deductionRules;

    private LocalDate effectiveDate;

    public Long getStructureId() { return structureId; }
    public void setStructureId(Long structureId) { this.structureId = structureId; }

    public GradeStructure getGrade() { return grade; }
    public void setGrade(GradeStructure grade) { this.grade = grade; }

    public Double getBasicPercent() { return basicPercent; }
    public void setBasicPercent(Double basicPercent) { this.basicPercent = basicPercent; }

    public Double getHraPercent() { return hraPercent; }
    public void setHraPercent(Double hraPercent) { this.hraPercent = hraPercent; }

    public String getAllowances() { return allowances; }
    public void setAllowances(String allowances) { this.allowances = allowances; }

    public String getDeductionRules() { return deductionRules; }
    public void setDeductionRules(String deductionRules) { this.deductionRules = deductionRules; }

    public LocalDate getEffectiveDate() { return effectiveDate; }
    public void setEffectiveDate(LocalDate effectiveDate) { this.effectiveDate = effectiveDate; }
}
