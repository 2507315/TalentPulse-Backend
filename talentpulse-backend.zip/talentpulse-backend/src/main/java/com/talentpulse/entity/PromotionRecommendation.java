package com.talentpulse.entity;

import com.talentpulse.enums.RecommendationStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Performance & Appraisal Management - promotion recommendation.
 */
@Entity
@Table(name = "promotion_recommendations")
public class PromotionRecommendation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long recommendationId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cycle_id")
    private AppraisalCycle cycle;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "current_grade_id")
    private GradeStructure currentGrade;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recommended_grade_id")
    private GradeStructure recommendedGrade;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recommended_by")
    private Employee recommendedByEmployee;

    /** Recommended/Approved/Declined */
    @Enumerated(EnumType.STRING)
    private RecommendationStatus status;

    public Long getRecommendationId() { return recommendationId; }
    public void setRecommendationId(Long recommendationId) { this.recommendationId = recommendationId; }

    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }

    public AppraisalCycle getCycle() { return cycle; }
    public void setCycle(AppraisalCycle cycle) { this.cycle = cycle; }

    public GradeStructure getCurrentGrade() { return currentGrade; }
    public void setCurrentGrade(GradeStructure currentGrade) { this.currentGrade = currentGrade; }

    public GradeStructure getRecommendedGrade() { return recommendedGrade; }
    public void setRecommendedGrade(GradeStructure recommendedGrade) { this.recommendedGrade = recommendedGrade; }

    public Employee getRecommendedByEmployee() { return recommendedByEmployee; }
    public void setRecommendedByEmployee(Employee recommendedByEmployee) { this.recommendedByEmployee = recommendedByEmployee; }

    public RecommendationStatus getStatus() { return status; }
    public void setStatus(RecommendationStatus status) { this.status = status; }
}
