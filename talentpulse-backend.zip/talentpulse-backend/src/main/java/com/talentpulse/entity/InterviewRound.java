package com.talentpulse.entity;

import com.talentpulse.enums.InterviewOutcome;
import com.talentpulse.enums.RoundType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDate;

/**
 * Recruitment & Applicant Tracking - interview round.
 */
@Entity
@Table(name = "interview_rounds")
public class InterviewRound {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roundId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "candidate_id")
    private Candidate candidate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requisition_id")
    private JobRequisition requisition;

    /** HR/Technical/Managerial/Final */
    @Enumerated(EnumType.STRING)
    private RoundType roundType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "interviewer_id")
    private Employee interviewer;

    private LocalDate scheduledDate;

    /** Pass/Fail/Hold/Pending */
    @Enumerated(EnumType.STRING)
    private InterviewOutcome outcome;

    @Column(length = 2000)
    private String feedback;

    public Long getRoundId() { return roundId; }
    public void setRoundId(Long roundId) { this.roundId = roundId; }

    public Candidate getCandidate() { return candidate; }
    public void setCandidate(Candidate candidate) { this.candidate = candidate; }

    public JobRequisition getRequisition() { return requisition; }
    public void setRequisition(JobRequisition requisition) { this.requisition = requisition; }

    public RoundType getRoundType() { return roundType; }
    public void setRoundType(RoundType roundType) { this.roundType = roundType; }

    public Employee getInterviewer() { return interviewer; }
    public void setInterviewer(Employee interviewer) { this.interviewer = interviewer; }

    public LocalDate getScheduledDate() { return scheduledDate; }
    public void setScheduledDate(LocalDate scheduledDate) { this.scheduledDate = scheduledDate; }

    public InterviewOutcome getOutcome() { return outcome; }
    public void setOutcome(InterviewOutcome outcome) { this.outcome = outcome; }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }
}
