package com.talentpulse.entity;

import com.talentpulse.enums.PayrollStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDate;

/**
 * Payroll & Compensation Management - monthly payroll run.
 */
@Entity
@Table(name = "payroll_runs")
public class PayrollRun {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long payrollRunId;

    private Integer month;
    private Integer year;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "processed_by_id")
    private User processedByUser;
    private LocalDate processedDate;
    private Double totalGross;
    private Double totalDeductions;
    private Double totalNet;

    /** Draft/Processed/Approved/Disbursed */
    @Enumerated(EnumType.STRING)
    private PayrollStatus status;

    public Long getPayrollRunId() { return payrollRunId; }
    public void setPayrollRunId(Long payrollRunId) { this.payrollRunId = payrollRunId; }

    public Integer getMonth() { return month; }
    public void setMonth(Integer month) { this.month = month; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public User getProcessedByUser() { return processedByUser; }
    public void setProcessedByUser(User processedByUser) { this.processedByUser = processedByUser; }

    public LocalDate getProcessedDate() { return processedDate; }
    public void setProcessedDate(LocalDate processedDate) { this.processedDate = processedDate; }

    public Double getTotalGross() { return totalGross; }
    public void setTotalGross(Double totalGross) { this.totalGross = totalGross; }

    public Double getTotalDeductions() { return totalDeductions; }
    public void setTotalDeductions(Double totalDeductions) { this.totalDeductions = totalDeductions; }

    public Double getTotalNet() { return totalNet; }
    public void setTotalNet(Double totalNet) { this.totalNet = totalNet; }

    public PayrollStatus getStatus() { return status; }
    public void setStatus(PayrollStatus status) { this.status = status; }
}
