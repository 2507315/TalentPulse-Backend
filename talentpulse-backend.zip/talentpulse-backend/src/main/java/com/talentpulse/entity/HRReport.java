package com.talentpulse.entity;

import com.talentpulse.enums.ReportScope;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDate;

/**
 * HR Analytics & Reporting - generated HR report.
 */
@Entity
@Table(name = "hr_reports")
public class HRReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reportId;

    /** Department/Grade/Period/CostCentre */
    @Enumerated(EnumType.STRING)
    private ReportScope scope;

    /** Headcount, AttritionRate, AvgTenure, PayrollCost, LeaveUtilisation, PerformanceDistribution */
    @Column(length = 4000)
    private String metrics;

    private LocalDate generatedDate;

    public Long getReportId() { return reportId; }
    public void setReportId(Long reportId) { this.reportId = reportId; }

    public ReportScope getScope() { return scope; }
    public void setScope(ReportScope scope) { this.scope = scope; }

    public String getMetrics() { return metrics; }
    public void setMetrics(String metrics) { this.metrics = metrics; }

    public LocalDate getGeneratedDate() { return generatedDate; }
    public void setGeneratedDate(LocalDate generatedDate) { this.generatedDate = generatedDate; }
}
