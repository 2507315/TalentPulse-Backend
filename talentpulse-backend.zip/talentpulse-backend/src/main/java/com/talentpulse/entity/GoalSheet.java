package com.talentpulse.entity;

import com.talentpulse.enums.GoalSheetStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Performance & Appraisal Management - employee goal sheet.
 */
@Entity
@Table(name = "goal_sheets")
public class GoalSheet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long goalSheetId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cycle_id")
    private AppraisalCycle cycle;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "manager_id")
    private Employee manager;

    @Column(length = 4000)
    private String goalsJson;

    private Double selfRating;
    private Double managerRating;
    private Double finalRating;

    /** Draft/Submitted/Reviewed/Finalised */
    @Enumerated(EnumType.STRING)
    private GoalSheetStatus status;

    public Long getGoalSheetId() { return goalSheetId; }
    public void setGoalSheetId(Long goalSheetId) { this.goalSheetId = goalSheetId; }

    public AppraisalCycle getCycle() { return cycle; }
    public void setCycle(AppraisalCycle cycle) { this.cycle = cycle; }

    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }

    public Employee getManager() { return manager; }
    public void setManager(Employee manager) { this.manager = manager; }

    public String getGoalsJson() { return goalsJson; }
    public void setGoalsJson(String goalsJson) { this.goalsJson = goalsJson; }

    public Double getSelfRating() { return selfRating; }
    public void setSelfRating(Double selfRating) { this.selfRating = selfRating; }

    public Double getManagerRating() { return managerRating; }
    public void setManagerRating(Double managerRating) { this.managerRating = managerRating; }

    public Double getFinalRating() { return finalRating; }
    public void setFinalRating(Double finalRating) { this.finalRating = finalRating; }

    public GoalSheetStatus getStatus() { return status; }
    public void setStatus(GoalSheetStatus status) { this.status = status; }
}
