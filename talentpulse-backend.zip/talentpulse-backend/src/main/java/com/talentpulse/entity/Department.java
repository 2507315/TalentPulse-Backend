package com.talentpulse.entity;

import com.talentpulse.enums.ActiveStatus;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * Employee Profile & Organisation Management - department.
 */
@Entity
@Table(name = "departments")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long departmentId;

    private String departmentName;
    private String costCentreCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hrbp_user_id")
    private User hrbpUser;

    /** Active/Inactive */
    @Enumerated(EnumType.STRING)
    private ActiveStatus status;

    public Long getDepartmentId() { return departmentId; }
    public void setDepartmentId(Long departmentId) { this.departmentId = departmentId; }

    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }

    public String getCostCentreCode() { return costCentreCode; }
    public void setCostCentreCode(String costCentreCode) { this.costCentreCode = costCentreCode; }

    public User getHrbpUser() { return hrbpUser; }
    public void setHrbpUser(User hrbpUser) { this.hrbpUser = hrbpUser; }

    public ActiveStatus getStatus() { return status; }
    public void setStatus(ActiveStatus status) { this.status = status; }
}
