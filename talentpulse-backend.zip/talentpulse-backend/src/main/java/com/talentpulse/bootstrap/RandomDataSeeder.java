package com.talentpulse.bootstrap;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.talentpulse.entity.AttendanceRecord;
import com.talentpulse.entity.Candidate;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.JobRequisition;
import com.talentpulse.entity.LeaveApplication;
import com.talentpulse.entity.LeaveType;
import com.talentpulse.entity.Notification;
import com.talentpulse.entity.User;
import com.talentpulse.enums.AttendanceStatus;
import com.talentpulse.enums.CandidateStatus;
import com.talentpulse.enums.LeaveStatus;
import com.talentpulse.enums.NotificationCategory;
import com.talentpulse.enums.NotificationStatus;
import com.talentpulse.enums.RequisitionStatus;
import com.talentpulse.enums.SourceChannel;
import com.talentpulse.repository.AttendanceRecordRepository;
import com.talentpulse.repository.CandidateRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.JobRequisitionRepository;
import com.talentpulse.repository.LeaveApplicationRepository;
import com.talentpulse.repository.LeaveTypeRepository;
import com.talentpulse.repository.NotificationRepository;
import com.talentpulse.repository.UserRepository;

/**
 * Generates a larger volume of RANDOM demo data so the tables are visibly populated:
 * candidates, job requisitions, attendance records, leave applications and notifications.
 *
 * <p>Runs AFTER {@link DataSeeder} (so the base employees / leave types exist) and only when
 * the candidates table is empty, so repeated startups never duplicate rows.
 * Toggle with {@code talentpulse.seed.random.enabled} (default true).</p>
 */
@Component
@Order(10)
public class RandomDataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(RandomDataSeeder.class);

    private final EmployeeRepository employeeRepo;
    private final UserRepository userRepo;
    private final LeaveTypeRepository leaveTypeRepo;
    private final CandidateRepository candidateRepo;
    private final JobRequisitionRepository requisitionRepo;
    private final AttendanceRecordRepository attendanceRepo;
    private final LeaveApplicationRepository leaveApplicationRepo;
    private final NotificationRepository notificationRepo;

    @Value("${talentpulse.seed.random.enabled:true}")
    private boolean randomSeedEnabled;

    /** Fixed seed -> reproducible "random" data across runs. */
    private final Random random = new Random(42);

    private static final String[] FIRST_NAMES = {
            "Aarav", "Vivaan", "Aditya", "Vihaan", "Ananya", "Diya", "Ishaan", "Kabir",
            "Saanvi", "Myra", "Reyansh", "Aadhya", "Krishna", "Anika", "Rohan", "Tara",
            "Dev", "Riya", "Kiaan", "Meera", "Aryan", "Naina", "Yash", "Pooja"
    };
    private static final String[] LAST_NAMES = {
            "Sharma", "Verma", "Gupta", "Reddy", "Nair", "Iyer", "Patel", "Singh",
            "Das", "Bose", "Khan", "Mehta", "Joshi", "Pillai", "Rao", "Kapoor"
    };
    private static final String[] DESIGNATIONS = {
            "Software Engineer", "Senior Software Engineer", "QA Analyst", "Business Analyst",
            "Product Manager", "DevOps Engineer", "Data Engineer", "UX Designer", "Support Engineer"
    };
    private static final String[] LEAVE_REASONS = {
            "Family function", "Medical appointment", "Personal work", "Vacation",
            "Childcare", "Festival", "Relocation", "Marriage in family"
    };

    public RandomDataSeeder(EmployeeRepository employeeRepo,
                            UserRepository userRepo,
                            LeaveTypeRepository leaveTypeRepo,
                            CandidateRepository candidateRepo,
                            JobRequisitionRepository requisitionRepo,
                            AttendanceRecordRepository attendanceRepo,
                            LeaveApplicationRepository leaveApplicationRepo,
                            NotificationRepository notificationRepo) {
        this.employeeRepo = employeeRepo;
        this.userRepo = userRepo;
        this.leaveTypeRepo = leaveTypeRepo;
        this.candidateRepo = candidateRepo;
        this.requisitionRepo = requisitionRepo;
        this.attendanceRepo = attendanceRepo;
        this.leaveApplicationRepo = leaveApplicationRepo;
        this.notificationRepo = notificationRepo;
    }

    @Override
    public void run(String... args) {
        if (!randomSeedEnabled || candidateRepo.count() > 0) {
            return;
        }
        log.info("Generating random TalentPulse demo data...");

        List<Employee> employees = employeeRepo.findAll();
        List<LeaveType> leaveTypes = leaveTypeRepo.findAll();
        List<User> users = userRepo.findAll();

        seedCandidates(40);
        seedRequisitions(15, employees);
        seedAttendance(employees, 20);
        seedLeaveApplications(employees, leaveTypes, 30);
        seedNotifications(users, 50);

        log.info("Random data generated: 40 candidates, 15 requisitions, ~{} attendance rows, "
                + "30 leave applications, 50 notifications.", employees.size() * 20);
    }

    private void seedCandidates(int count) {
        SourceChannel[] channels = SourceChannel.values();
        CandidateStatus[] statuses = CandidateStatus.values();
        for (int i = 0; i < count; i++) {
            String name = randomName();
            Candidate c = new Candidate();
            c.setName(name);
            c.setEmail(emailFromName(name, "mail.com", i));
            c.setPhone(randomPhone());
            c.setResumeRef("resume-" + (1000 + i) + ".pdf");
            c.setSourceChannel(channels[random.nextInt(channels.length)]);
            c.setStatus(statuses[random.nextInt(statuses.length)]);
            candidateRepo.save(c);
        }
    }

    private void seedRequisitions(int count, List<Employee> employees) {
        RequisitionStatus[] statuses = RequisitionStatus.values();
        for (int i = 0; i < count; i++) {
            JobRequisition r = new JobRequisition();
            if (!employees.isEmpty()) {
                Employee ref = employees.get(random.nextInt(employees.size()));
                r.setDepartment(ref.getDepartment());
                r.setGrade(ref.getGrade());
            }
            r.setDesignation(DESIGNATIONS[random.nextInt(DESIGNATIONS.length)]);
            r.setRequiredBy(LocalDate.now().plusDays(random.nextInt(120) + 15));
            r.setStatus(statuses[random.nextInt(statuses.length)]);
            requisitionRepo.save(r);
        }
    }

    private void seedAttendance(List<Employee> employees, int daysBack) {
        LocalDate today = LocalDate.now();
        for (Employee e : employees) {
            for (int d = 1; d <= daysBack; d++) {
                LocalDate date = today.minusDays(d);
                if (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
                    continue;
                }
                AttendanceRecord a = new AttendanceRecord();
                a.setEmployee(e);
                a.setDate(date);

                int roll = random.nextInt(100);
                if (roll < 80) {
                    LocalTime in = LocalTime.of(9, random.nextInt(45));
                    LocalTime out = LocalTime.of(18, random.nextInt(45));
                    a.setCheckIn(in);
                    a.setCheckOut(out);
                    a.setWorkingHours(8.0 + random.nextInt(20) / 10.0);
                    a.setStatus(AttendanceStatus.PRESENT);
                } else if (roll < 88) {
                    LocalTime in = LocalTime.of(9, random.nextInt(30));
                    a.setCheckIn(in);
                    a.setCheckOut(LocalTime.of(13, 30));
                    a.setWorkingHours(4.0);
                    a.setStatus(AttendanceStatus.HALF_DAY);
                } else if (roll < 95) {
                    a.setWorkingHours(0.0);
                    a.setStatus(AttendanceStatus.ON_LEAVE);
                } else {
                    a.setWorkingHours(0.0);
                    a.setStatus(AttendanceStatus.ABSENT);
                }
                attendanceRepo.save(a);
            }
        }
    }

    private void seedLeaveApplications(List<Employee> employees, List<LeaveType> leaveTypes, int count) {
        if (employees.isEmpty() || leaveTypes.isEmpty()) {
            return;
        }
        LeaveStatus[] statuses = LeaveStatus.values();
        for (int i = 0; i < count; i++) {
            Employee e = employees.get(random.nextInt(employees.size()));
            LeaveType lt = leaveTypes.get(random.nextInt(leaveTypes.size()));
            LocalDate from = LocalDate.now().minusDays(random.nextInt(60)).plusDays(random.nextInt(10));
            int span = random.nextInt(4); // 0..3 extra days
            LocalDate to = from.plusDays(span);

            LeaveApplication la = new LeaveApplication();
            la.setEmployee(e);
            la.setLeaveType(lt);
            la.setFromDate(from);
            la.setToDate(to);
            la.setDaysRequested((double) (span + 1));
            la.setReason(LEAVE_REASONS[random.nextInt(LEAVE_REASONS.length)]);
            la.setApprover(e.getReportingManager());
            la.setStatus(statuses[random.nextInt(statuses.length)]);
            leaveApplicationRepo.save(la);
        }
    }

    private void seedNotifications(List<User> users, int count) {
        if (users.isEmpty()) {
            return;
        }
        NotificationCategory[] categories = NotificationCategory.values();
        NotificationStatus[] statuses = NotificationStatus.values();
        String[] templates = {
                "Your leave request has been %s.",
                "Payslip for last month is now available.",
                "Appraisal cycle review window is %s.",
                "A new candidate has been added to your requisition.",
                "Please complete your compliance training."
        };
        for (int i = 0; i < count; i++) {
            User u = users.get(random.nextInt(users.size()));
            NotificationCategory cat = categories[random.nextInt(categories.length)];
            String msg = String.format(templates[random.nextInt(templates.length)], "updated");

            Notification n = new Notification();
            n.setUser(u);
            n.setMessage(msg);
            n.setCategory(cat);
            n.setStatus(statuses[random.nextInt(statuses.length)]);
            n.setCreatedDate(LocalDateTime.now().minusDays(random.nextInt(30)).minusHours(random.nextInt(24)));
            notificationRepo.save(n);
        }
    }

    private String randomName() {
        return FIRST_NAMES[random.nextInt(FIRST_NAMES.length)] + " "
                + LAST_NAMES[random.nextInt(LAST_NAMES.length)];
    }

    private String emailFromName(String name, String domain, int salt) {
        return name.toLowerCase().replace(" ", ".") + salt + "@" + domain;
    }

    private String randomPhone() {
        StringBuilder sb = new StringBuilder("+91");
        sb.append(7 + random.nextInt(3)); // starts 7/8/9
        for (int i = 0; i < 9; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
}
