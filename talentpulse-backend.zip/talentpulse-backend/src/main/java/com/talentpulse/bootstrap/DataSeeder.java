package com.talentpulse.bootstrap;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.talentpulse.entity.AppraisalCycle;
import com.talentpulse.entity.Department;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.LeaveType;
import com.talentpulse.entity.SalaryStructure;
import com.talentpulse.entity.User;
import com.talentpulse.enums.ActiveStatus;
import com.talentpulse.enums.AppraisalType;
import com.talentpulse.enums.CycleStatus;
import com.talentpulse.enums.EmployeeStatus;
import com.talentpulse.enums.EmploymentType;
import com.talentpulse.enums.Role;
import com.talentpulse.enums.UserStatus;
import com.talentpulse.repository.AppraisalCycleRepository;
import com.talentpulse.repository.DepartmentRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.LeaveTypeRepository;
import com.talentpulse.repository.SalaryStructureRepository;
import com.talentpulse.repository.UserRepository;

/**
 * Seeds demo reference data and one login per role on first startup.
 * Runs only when the {@code users} table is empty and seeding is enabled.
 * Default password for every demo account: {@code Password@123}
 */
@Component
@Order(1)
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);
    private static final String DEMO_PASSWORD = "Password@123";

    private final UserRepository userRepo;
    private final EmployeeRepository employeeRepo;
    private final DepartmentRepository departmentRepo;
    private final GradeStructureRepository gradeRepo;
    private final LeaveTypeRepository leaveTypeRepo;
    private final SalaryStructureRepository salaryStructureRepo;
    private final AppraisalCycleRepository cycleRepo;
    private final PasswordEncoder passwordEncoder;

    @Value("${talentpulse.seed.enabled:true}")
    private boolean seedEnabled;

    public DataSeeder(UserRepository userRepo,
                      EmployeeRepository employeeRepo,
                      DepartmentRepository departmentRepo,
                      GradeStructureRepository gradeRepo,
                      LeaveTypeRepository leaveTypeRepo,
                      SalaryStructureRepository salaryStructureRepo,
                      AppraisalCycleRepository cycleRepo,
                      PasswordEncoder passwordEncoder) {
        this.userRepo = userRepo;
        this.employeeRepo = employeeRepo;
        this.departmentRepo = departmentRepo;
        this.gradeRepo = gradeRepo;
        this.leaveTypeRepo = leaveTypeRepo;
        this.salaryStructureRepo = salaryStructureRepo;
        this.cycleRepo = cycleRepo;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (!seedEnabled || userRepo.count() > 0) {
            return;
        }
        log.info("Seeding TalentPulse demo data...");

        // ===== Grades =====
        GradeStructure g1 = gradeRepo.save(grade("G1 - Associate", "Junior", 30000, 50000, 18));
        GradeStructure g2 = gradeRepo.save(grade("G2 - Senior Associate", "Mid", 50000, 80000, 20));
        GradeStructure g3 = gradeRepo.save(grade("G3 - Manager", "Senior", 80000, 130000, 22));
        GradeStructure g4 = gradeRepo.save(grade("G4 - Director", "Leadership", 130000, 220000, 25));

        // ===== Departments =====
        Department eng = departmentRepo.save(dept("Engineering", "CC-ENG"));
        Department hr = departmentRepo.save(dept("Human Resources", "CC-HR"));
        Department fin = departmentRepo.save(dept("Finance", "CC-FIN"));
        departmentRepo.save(dept("Sales", "CC-SAL"));

        // ===== Leave types =====
        leaveTypeRepo.save(leaveType("Casual Leave", 12, true, true));
        leaveTypeRepo.save(leaveType("Sick Leave", 10, false, true));
        leaveTypeRepo.save(leaveType("Earned Leave", 15, true, true));
        leaveTypeRepo.save(leaveType("Maternity Leave", 180, false, true));
        leaveTypeRepo.save(leaveType("Loss of Pay", 0, false, true));

        // ===== Salary structures per grade =====
        salaryStructureRepo.save(salary(g1, 40, 50, "3000", "PF:12%;PT:200"));
        salaryStructureRepo.save(salary(g2, 40, 50, "5000", "PF:12%;PT:200"));
        salaryStructureRepo.save(salary(g3, 45, 50, "8000", "PF:12%;PT:200"));
        salaryStructureRepo.save(salary(g4, 50, 50, "15000", "PF:12%;PT:200"));

        // ===== Employees =====
        Employee director = employeeRepo.save(emp("Asha Director", "Director", g4, eng, null, "Female"));
        Employee engMgr = employeeRepo.save(emp("Ravi Manager", "Engineering Manager", g3, eng, director.getEmployeeId(), "Male"));
        Employee dev1 = employeeRepo.save(emp("Neha Sharma", "Software Engineer", g2, eng, engMgr.getEmployeeId(), "Female"));
        Employee dev2 = employeeRepo.save(emp("Arjun Mehta", "Software Engineer", g1, eng, engMgr.getEmployeeId(), "Male"));
        Employee hrbpEmp = employeeRepo.save(emp("Priya HRBP", "HR Business Partner", g3, hr, director.getEmployeeId(), "Female"));
        Employee payrollEmp = employeeRepo.save(emp("Karan Payroll", "Payroll Executive", g2, fin, director.getEmployeeId(), "Male"));
        Employee recruiterEmp = employeeRepo.save(emp("Sara Recruiter", "Talent Acquisition", g2, hr, hrbpEmp.getEmployeeId(), "Female"));

        // ===== Users (one per role) =====
        createUser("System Admin", "admin@talentpulse.com", Role.ADMIN, null);
        createUser(engMgr.getName(), "manager@talentpulse.com", Role.MANAGER, engMgr.getEmployeeId());
        createUser(hrbpEmp.getName(), "hrbp@talentpulse.com", Role.HRBP, hrbpEmp.getEmployeeId());
        createUser(payrollEmp.getName(), "payroll@talentpulse.com", Role.PAYROLL, payrollEmp.getEmployeeId());
        createUser(recruiterEmp.getName(), "recruiter@talentpulse.com", Role.RECRUITER, recruiterEmp.getEmployeeId());
        createUser(dev1.getName(), "employee@talentpulse.com", Role.EMPLOYEE, dev1.getEmployeeId());
        createUser(dev2.getName(), "arjun@talentpulse.com", Role.EMPLOYEE, dev2.getEmployeeId());

        // ===== Active appraisal cycle =====
        AppraisalCycle cycle = new AppraisalCycle();
        cycle.setName("Annual Appraisal " + LocalDate.now().getYear());
        cycle.setYear(LocalDate.now().getYear());
        cycle.setType(AppraisalType.ANNUAL);
        cycle.setGoalSettingStart(LocalDate.now().minusMonths(2));
        cycle.setGoalSettingEnd(LocalDate.now().minusMonths(1));
        cycle.setReviewStart(LocalDate.now());
        cycle.setReviewEnd(LocalDate.now().plusMonths(1));
        cycle.setStatus(CycleStatus.ACTIVE);
        cycleRepo.save(cycle);

        log.info("Seed complete. Demo logins (password '{}'): admin@, manager@, hrbp@, payroll@, recruiter@, employee@ talentpulse.com", DEMO_PASSWORD);
    }

    private GradeStructure grade(String name, String band, double min, double max, int leave) {
        GradeStructure g = new GradeStructure();
        g.setGradeName(name);
        g.setBand(band);
        g.setMinSalary(min);
        g.setMaxSalary(max);
        g.setLeaveEntitlement(leave);
        return g;
    }

    private Department dept(String name, String costCentreCode) {
        Department d = new Department();
        d.setDepartmentName(name);
        d.setCostCentreCode(costCentreCode);
        d.setStatus(ActiveStatus.ACTIVE);
        return d;
    }

    private LeaveType leaveType(String name, int quota, boolean carryForward, boolean requiresApproval) {
        LeaveType lt = new LeaveType();
        lt.setName(name);
        lt.setAnnualQuota(quota);
        lt.setCarryForwardAllowed(carryForward);
        lt.setRequiresApproval(requiresApproval);
        return lt;
    }

    private SalaryStructure salary(GradeStructure grade, double basicPct, double hraPct, String allowances, String deductionRules) {
        SalaryStructure s = new SalaryStructure();
        s.setGrade(grade);
        s.setBasicPercent(basicPct);
        s.setHraPercent(hraPct);
        s.setAllowances(allowances);
        s.setDeductionRules(deductionRules);
        s.setEffectiveDate(LocalDate.now().minusMonths(6));
        return s;
    }

    private Employee emp(String name, String designation, GradeStructure grade, Department dept, Long managerId, String gender) {
        Employee e = new Employee();
        e.setName(name);
        e.setDesignation(designation);
        e.setGender(gender);
        e.setGrade(grade);
        e.setDepartment(dept);
        if (managerId != null) {
            e.setReportingManager(employeeRepo.getReferenceById(managerId));
        }
        e.setJoiningDate(LocalDate.now().minusMonths((long) (Math.random() * 36) + 6));
        e.setEmploymentType(EmploymentType.PERMANENT);
        e.setStatus(EmployeeStatus.ACTIVE);
        return e;
    }

    private void createUser(String name, String email, Role role, Long employeeId) {
        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setRole(role);
        u.setEmployee(employeeId != null ? employeeRepo.findById(employeeId).orElse(null) : null);
        u.setPassword(passwordEncoder.encode(DEMO_PASSWORD));
        u.setStatus(UserStatus.ACTIVE);
        userRepo.save(u);
    }
}
