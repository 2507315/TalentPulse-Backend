package com.talentpulse.controller;

import com.talentpulse.dto.InterviewRoundDTO;
import com.talentpulse.service.InterviewRoundService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/interview-rounds")
public class InterviewRoundController {

    private final InterviewRoundService interviewRoundService;

    public InterviewRoundController(InterviewRoundService interviewRoundService) {
        this.interviewRoundService = interviewRoundService;
    }

    @GetMapping
    public List<InterviewRoundDTO> getAll() {
        return interviewRoundService.getAll();
    }

    @GetMapping("/{id}")
    public InterviewRoundDTO getById(@PathVariable Long id) {
        return interviewRoundService.getById(id);
    }

    @PostMapping
    public ResponseEntity<InterviewRoundDTO> create(@RequestBody InterviewRoundDTO dto) {
        return new ResponseEntity<>(interviewRoundService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public InterviewRoundDTO update(@PathVariable Long id, @RequestBody InterviewRoundDTO dto) {
        return interviewRoundService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        interviewRoundService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
