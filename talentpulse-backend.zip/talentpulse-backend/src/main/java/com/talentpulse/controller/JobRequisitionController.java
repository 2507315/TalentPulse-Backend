package com.talentpulse.controller;

import com.talentpulse.dto.JobRequisitionDTO;
import com.talentpulse.service.JobRequisitionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/job-requisitions")
public class JobRequisitionController {

    private final JobRequisitionService jobRequisitionService;

    public JobRequisitionController(JobRequisitionService jobRequisitionService) {
        this.jobRequisitionService = jobRequisitionService;
    }

    @GetMapping
    public List<JobRequisitionDTO> getAll() {
        return jobRequisitionService.getAll();
    }

    @GetMapping("/{id}")
    public JobRequisitionDTO getById(@PathVariable Long id) {
        return jobRequisitionService.getById(id);
    }

    @PostMapping
    public ResponseEntity<JobRequisitionDTO> create(@RequestBody JobRequisitionDTO dto) {
        return new ResponseEntity<>(jobRequisitionService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public JobRequisitionDTO update(@PathVariable Long id, @RequestBody JobRequisitionDTO dto) {
        return jobRequisitionService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        jobRequisitionService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
