package com.talentpulse.controller;

import com.talentpulse.dto.HRReportDTO;
import com.talentpulse.enums.ReportScope;
import com.talentpulse.service.HRReportService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/hr-reports")
public class HRReportController {

    private final HRReportService hrReportService;

    public HRReportController(HRReportService hrReportService) {
        this.hrReportService = hrReportService;
    }

    @GetMapping
    public List<HRReportDTO> getAll() {
        return hrReportService.getAll();
    }

    @GetMapping("/{id}")
    public HRReportDTO getById(@PathVariable Long id) {
        return hrReportService.getById(id);
    }

    @PostMapping
    public ResponseEntity<HRReportDTO> create(@RequestBody HRReportDTO dto) {
        return new ResponseEntity<>(hrReportService.create(dto), HttpStatus.CREATED);
    }

    /**
     * Generates a report with metrics computed live from current data.
     * Example: POST /api/hr-reports/generate?scope=DEPARTMENT
     */
    @PostMapping("/generate")
    public ResponseEntity<HRReportDTO> generate(@RequestParam(defaultValue = "DEPARTMENT") ReportScope scope) {
        return new ResponseEntity<>(hrReportService.generate(scope), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public HRReportDTO update(@PathVariable Long id, @RequestBody HRReportDTO dto) {
        return hrReportService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        hrReportService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
