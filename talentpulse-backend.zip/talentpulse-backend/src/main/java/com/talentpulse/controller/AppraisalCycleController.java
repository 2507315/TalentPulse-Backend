package com.talentpulse.controller;

import com.talentpulse.dto.AppraisalCycleDTO;
import com.talentpulse.service.AppraisalCycleService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/appraisal-cycles")
public class AppraisalCycleController {

    private final AppraisalCycleService appraisalCycleService;

    public AppraisalCycleController(AppraisalCycleService appraisalCycleService) {
        this.appraisalCycleService = appraisalCycleService;
    }

    @GetMapping
    public List<AppraisalCycleDTO> getAll() {
        return appraisalCycleService.getAll();
    }

    @GetMapping("/{id}")
    public AppraisalCycleDTO getById(@PathVariable Long id) {
        return appraisalCycleService.getById(id);
    }

    @PostMapping
    public ResponseEntity<AppraisalCycleDTO> create(@RequestBody AppraisalCycleDTO dto) {
        return new ResponseEntity<>(appraisalCycleService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public AppraisalCycleDTO update(@PathVariable Long id, @RequestBody AppraisalCycleDTO dto) {
        return appraisalCycleService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        appraisalCycleService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
