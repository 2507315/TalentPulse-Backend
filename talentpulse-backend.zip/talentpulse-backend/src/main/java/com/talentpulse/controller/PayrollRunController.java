package com.talentpulse.controller;

import com.talentpulse.dto.PayrollRunDTO;
import com.talentpulse.service.PayrollRunService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/payroll-runs")
public class PayrollRunController {

    private final PayrollRunService payrollRunService;

    public PayrollRunController(PayrollRunService payrollRunService) {
        this.payrollRunService = payrollRunService;
    }

    @GetMapping
    public List<PayrollRunDTO> getAll() {
        return payrollRunService.getAll();
    }

    @GetMapping("/{id}")
    public PayrollRunDTO getById(@PathVariable Long id) {
        return payrollRunService.getById(id);
    }

    @PostMapping
    public ResponseEntity<PayrollRunDTO> create(@RequestBody PayrollRunDTO dto) {
        return new ResponseEntity<>(payrollRunService.create(dto), HttpStatus.CREATED);
    }

    /**
     * Auto-generates a payslip for every employee in this DRAFT run and rolls up totals.
     * Example: POST /api/payroll-runs/1/generate
     */
    @PostMapping("/{id}/generate")
    public PayrollRunDTO generate(@PathVariable Long id) {
        return payrollRunService.generatePayslips(id);
    }

    @PutMapping("/{id}")
    public PayrollRunDTO update(@PathVariable Long id, @RequestBody PayrollRunDTO dto) {
        return payrollRunService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        payrollRunService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
