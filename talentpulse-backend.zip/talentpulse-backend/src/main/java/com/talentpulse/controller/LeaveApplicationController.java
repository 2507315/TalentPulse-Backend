package com.talentpulse.controller;

import com.talentpulse.dto.LeaveApplicationDTO;
import com.talentpulse.service.LeaveApplicationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/leave-applications")
public class LeaveApplicationController {

    private final LeaveApplicationService leaveApplicationService;

    public LeaveApplicationController(LeaveApplicationService leaveApplicationService) {
        this.leaveApplicationService = leaveApplicationService;
    }

    @GetMapping
    public List<LeaveApplicationDTO> getAll() {
        return leaveApplicationService.getAll();
    }

    @GetMapping("/{id}")
    public LeaveApplicationDTO getById(@PathVariable Long id) {
        return leaveApplicationService.getById(id);
    }

    @PostMapping
    public ResponseEntity<LeaveApplicationDTO> create(@RequestBody LeaveApplicationDTO dto) {
        return new ResponseEntity<>(leaveApplicationService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public LeaveApplicationDTO update(@PathVariable Long id, @RequestBody LeaveApplicationDTO dto) {
        return leaveApplicationService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        leaveApplicationService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
