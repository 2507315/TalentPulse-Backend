package com.talentpulse.controller;

import com.talentpulse.dto.AuditLogDTO;
import com.talentpulse.service.AuditLogService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/audit-logs")
public class AuditLogController {

    private final AuditLogService auditLogService;

    public AuditLogController(AuditLogService auditLogService) {
        this.auditLogService = auditLogService;
    }

    @GetMapping    public List<AuditLogDTO> getAll() {
        return auditLogService.getAll();
    }

    @GetMapping("/{id}")    public AuditLogDTO getById(@PathVariable Long id) {
        return auditLogService.getById(id);
    }

    @PostMapping    public ResponseEntity<AuditLogDTO> create(@RequestBody AuditLogDTO dto) {
        return new ResponseEntity<>(auditLogService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")    public AuditLogDTO update(@PathVariable Long id, @RequestBody AuditLogDTO dto) {
        return auditLogService.update(id, dto);
    }

    @DeleteMapping("/{id}")    public ResponseEntity<Void> delete(@PathVariable Long id) {
        auditLogService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
