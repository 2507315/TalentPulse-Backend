package com.talentpulse.controller;

import com.talentpulse.dto.LeaveTypeDTO;
import com.talentpulse.service.LeaveTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/leave-types")
public class LeaveTypeController {

    private final LeaveTypeService leaveTypeService;

    public LeaveTypeController(LeaveTypeService leaveTypeService) {
        this.leaveTypeService = leaveTypeService;
    }

    @GetMapping
    public List<LeaveTypeDTO> getAll() {
        return leaveTypeService.getAll();
    }

    @GetMapping("/{id}")
    public LeaveTypeDTO getById(@PathVariable Long id) {
        return leaveTypeService.getById(id);
    }

    @PostMapping
    public ResponseEntity<LeaveTypeDTO> create(@RequestBody LeaveTypeDTO dto) {
        return new ResponseEntity<>(leaveTypeService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public LeaveTypeDTO update(@PathVariable Long id, @RequestBody LeaveTypeDTO dto) {
        return leaveTypeService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        leaveTypeService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
