package com.talentpulse.controller;

import com.talentpulse.dto.CandidateDTO;
import com.talentpulse.service.CandidateService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/candidates")
public class CandidateController {

    private final CandidateService candidateService;

    public CandidateController(CandidateService candidateService) {
        this.candidateService = candidateService;
    }

    @GetMapping
    public List<CandidateDTO> getAll() {
        return candidateService.getAll();
    }

    @GetMapping("/{id}")
    public CandidateDTO getById(@PathVariable Long id) {
        return candidateService.getById(id);
    }

    @PostMapping
    public ResponseEntity<CandidateDTO> create(@RequestBody CandidateDTO dto) {
        return new ResponseEntity<>(candidateService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public CandidateDTO update(@PathVariable Long id, @RequestBody CandidateDTO dto) {
        return candidateService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        candidateService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
