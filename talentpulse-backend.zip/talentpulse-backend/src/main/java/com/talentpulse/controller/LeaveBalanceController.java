package com.talentpulse.controller;

import com.talentpulse.dto.LeaveBalanceDTO;
import com.talentpulse.service.LeaveBalanceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/leave-balances")
public class LeaveBalanceController {

    private final LeaveBalanceService leaveBalanceService;

    public LeaveBalanceController(LeaveBalanceService leaveBalanceService) {
        this.leaveBalanceService = leaveBalanceService;
    }

    @GetMapping
    public List<LeaveBalanceDTO> getAll() {
        return leaveBalanceService.getAll();
    }

    @GetMapping("/{id}")
    public LeaveBalanceDTO getById(@PathVariable Long id) {
        return leaveBalanceService.getById(id);
    }

    @PostMapping
    public ResponseEntity<LeaveBalanceDTO> create(@RequestBody LeaveBalanceDTO dto) {
        return new ResponseEntity<>(leaveBalanceService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public LeaveBalanceDTO update(@PathVariable Long id, @RequestBody LeaveBalanceDTO dto) {
        return leaveBalanceService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        leaveBalanceService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
