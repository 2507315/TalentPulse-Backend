package com.talentpulse.controller;

import com.talentpulse.dto.GradeStructureDTO;
import com.talentpulse.service.GradeStructureService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/grades")
public class GradeStructureController {

    private final GradeStructureService gradeStructureService;

    public GradeStructureController(GradeStructureService gradeStructureService) {
        this.gradeStructureService = gradeStructureService;
    }

    @GetMapping
    public List<GradeStructureDTO> getAll() {
        return gradeStructureService.getAll();
    }

    @GetMapping("/{id}")
    public GradeStructureDTO getById(@PathVariable Long id) {
        return gradeStructureService.getById(id);
    }

    @PostMapping
    public ResponseEntity<GradeStructureDTO> create(@RequestBody GradeStructureDTO dto) {
        return new ResponseEntity<>(gradeStructureService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public GradeStructureDTO update(@PathVariable Long id, @RequestBody GradeStructureDTO dto) {
        return gradeStructureService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        gradeStructureService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
