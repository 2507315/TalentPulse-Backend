package com.talentpulse.controller;

import com.talentpulse.dto.PromotionRecommendationDTO;
import com.talentpulse.service.PromotionRecommendationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/promotion-recommendations")
public class PromotionRecommendationController {

    private final PromotionRecommendationService promotionRecommendationService;

    public PromotionRecommendationController(PromotionRecommendationService promotionRecommendationService) {
        this.promotionRecommendationService = promotionRecommendationService;
    }

    @GetMapping
    public List<PromotionRecommendationDTO> getAll() {
        return promotionRecommendationService.getAll();
    }

    @GetMapping("/{id}")
    public PromotionRecommendationDTO getById(@PathVariable Long id) {
        return promotionRecommendationService.getById(id);
    }

    @PostMapping
    public ResponseEntity<PromotionRecommendationDTO> create(@RequestBody PromotionRecommendationDTO dto) {
        return new ResponseEntity<>(promotionRecommendationService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public PromotionRecommendationDTO update(@PathVariable Long id, @RequestBody PromotionRecommendationDTO dto) {
        return promotionRecommendationService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        promotionRecommendationService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
