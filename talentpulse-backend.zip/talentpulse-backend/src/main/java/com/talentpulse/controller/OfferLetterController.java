package com.talentpulse.controller;

import com.talentpulse.dto.OfferLetterDTO;
import com.talentpulse.service.OfferLetterService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/offer-letters")
public class OfferLetterController {

    private final OfferLetterService offerLetterService;

    public OfferLetterController(OfferLetterService offerLetterService) {
        this.offerLetterService = offerLetterService;
    }

    @GetMapping
    public List<OfferLetterDTO> getAll() {
        return offerLetterService.getAll();
    }

    @GetMapping("/{id}")
    public OfferLetterDTO getById(@PathVariable Long id) {
        return offerLetterService.getById(id);
    }

    @PostMapping
    public ResponseEntity<OfferLetterDTO> create(@RequestBody OfferLetterDTO dto) {
        return new ResponseEntity<>(offerLetterService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public OfferLetterDTO update(@PathVariable Long id, @RequestBody OfferLetterDTO dto) {
        return offerLetterService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        offerLetterService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
