package com.talentpulse.controller;

import com.talentpulse.dto.PayslipDTO;
import com.talentpulse.service.PayslipService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/payslips")
public class PayslipController {

    private final PayslipService payslipService;

    public PayslipController(PayslipService payslipService) {
        this.payslipService = payslipService;
    }

    @GetMapping
    public List<PayslipDTO> getAll() {
        return payslipService.getAll();
    }

    @GetMapping("/{id}")
    public PayslipDTO getById(@PathVariable Long id) {
        return payslipService.getById(id);
    }

    @PostMapping
    public ResponseEntity<PayslipDTO> create(@RequestBody PayslipDTO dto) {
        return new ResponseEntity<>(payslipService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public PayslipDTO update(@PathVariable Long id, @RequestBody PayslipDTO dto) {
        return payslipService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        payslipService.delete(id);
        return ResponseEntity.noContent().build();
    }
}