package com.talentpulse.controller;

import com.talentpulse.dto.GoalSheetDTO;
import com.talentpulse.service.GoalSheetService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/goal-sheets")
public class GoalSheetController {

    private final GoalSheetService goalSheetService;

    public GoalSheetController(GoalSheetService goalSheetService) {
        this.goalSheetService = goalSheetService;
    }

    @GetMapping
    public List<GoalSheetDTO> getAll() {
        return goalSheetService.getAll();
    }

    @GetMapping("/{id}")
    public GoalSheetDTO getById(@PathVariable Long id) {
        return goalSheetService.getById(id);
    }

    @PostMapping
    public ResponseEntity<GoalSheetDTO> create(@RequestBody GoalSheetDTO dto) {
        return new ResponseEntity<>(goalSheetService.create(dto), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public GoalSheetDTO update(@PathVariable Long id, @RequestBody GoalSheetDTO dto) {
        return goalSheetService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        goalSheetService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
