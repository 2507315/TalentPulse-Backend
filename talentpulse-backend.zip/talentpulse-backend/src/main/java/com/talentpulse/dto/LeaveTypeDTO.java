package com.talentpulse.dto;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.LeaveType}.
 */
public class LeaveTypeDTO {

    private Long leaveTypeId;
    private String name;
    private Integer annualQuota;
    private Boolean carryForwardAllowed;
    private Boolean requiresApproval;

    public Long getLeaveTypeId() { return leaveTypeId; }
    public void setLeaveTypeId(Long leaveTypeId) { this.leaveTypeId = leaveTypeId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getAnnualQuota() { return annualQuota; }
    public void setAnnualQuota(Integer annualQuota) { this.annualQuota = annualQuota; }

    public Boolean getCarryForwardAllowed() { return carryForwardAllowed; }
    public void setCarryForwardAllowed(Boolean carryForwardAllowed) { this.carryForwardAllowed = carryForwardAllowed; }

    public Boolean getRequiresApproval() { return requiresApproval; }
    public void setRequiresApproval(Boolean requiresApproval) { this.requiresApproval = requiresApproval; }
}
