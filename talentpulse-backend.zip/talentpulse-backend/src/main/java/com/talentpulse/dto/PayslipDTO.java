package com.talentpulse.dto;

import com.talentpulse.enums.PayslipStatus;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.Payslip}.
 */
public class PayslipDTO {

    private Long payslipId;
    private Long payrollRunId;
    private Long employeeId;
    private Double grossAmount;
    private Double totalDeductions;
    private Double netAmount;
    private LocalDate payslipDate;
    private PayslipStatus status;

    public Long getPayslipId() { return payslipId; }
    public void setPayslipId(Long payslipId) { this.payslipId = payslipId; }

    public Long getPayrollRunId() { return payrollRunId; }
    public void setPayrollRunId(Long payrollRunId) { this.payrollRunId = payrollRunId; }

    public Long getEmployeeId() { return employeeId; }
    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }

    public Double getGrossAmount() { return grossAmount; }
    public void setGrossAmount(Double grossAmount) { this.grossAmount = grossAmount; }

    public Double getTotalDeductions() { return totalDeductions; }
    public void setTotalDeductions(Double totalDeductions) { this.totalDeductions = totalDeductions; }

    public Double getNetAmount() { return netAmount; }
    public void setNetAmount(Double netAmount) { this.netAmount = netAmount; }

    public LocalDate getPayslipDate() { return payslipDate; }
    public void setPayslipDate(LocalDate payslipDate) { this.payslipDate = payslipDate; }

    public PayslipStatus getStatus() { return status; }
    public void setStatus(PayslipStatus status) { this.status = status; }
}
