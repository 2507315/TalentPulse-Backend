package com.talentpulse.dto;

import com.talentpulse.enums.InterviewOutcome;
import com.talentpulse.enums.RoundType;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.InterviewRound}.
 */
public class InterviewRoundDTO {

    private Long roundId;
    private Long candidateId;
    private Long requisitionId;
    private RoundType roundType;
    private Long interviewerId;
    private LocalDate scheduledDate;
    private InterviewOutcome outcome;
    private String feedback;

    public Long getRoundId() { return roundId; }
    public void setRoundId(Long roundId) { this.roundId = roundId; }

    public Long getCandidateId() { return candidateId; }
    public void setCandidateId(Long candidateId) { this.candidateId = candidateId; }

    public Long getRequisitionId() { return requisitionId; }
    public void setRequisitionId(Long requisitionId) { this.requisitionId = requisitionId; }

    public RoundType getRoundType() { return roundType; }
    public void setRoundType(RoundType roundType) { this.roundType = roundType; }

    public Long getInterviewerId() { return interviewerId; }
    public void setInterviewerId(Long interviewerId) { this.interviewerId = interviewerId; }

    public LocalDate getScheduledDate() { return scheduledDate; }
    public void setScheduledDate(LocalDate scheduledDate) { this.scheduledDate = scheduledDate; }

    public InterviewOutcome getOutcome() { return outcome; }
    public void setOutcome(InterviewOutcome outcome) { this.outcome = outcome; }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }
}
