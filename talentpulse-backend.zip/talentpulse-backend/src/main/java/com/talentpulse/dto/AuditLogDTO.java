
package com.talentpulse.dto;
import java.time.LocalDateTime;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.AuditLog}.
 */
public class AuditLogDTO {

    private Long auditId;
    private Long userId;
    private String action;
    private String module;
    private LocalDateTime timestamp;

    public Long getAuditId() { return auditId; }
    public void setAuditId(Long auditId) { this.auditId = auditId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
