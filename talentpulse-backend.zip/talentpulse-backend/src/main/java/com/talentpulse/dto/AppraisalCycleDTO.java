package com.talentpulse.dto;

import com.talentpulse.enums.AppraisalType;
import com.talentpulse.enums.CycleStatus;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.AppraisalCycle}.
 */
public class AppraisalCycleDTO {

    private Long cycleId;
    private String name;
    private Integer year;
    private AppraisalType type;
    private LocalDate goalSettingStart;
    private LocalDate goalSettingEnd;
    private LocalDate reviewStart;
    private LocalDate reviewEnd;
    private CycleStatus status;

    public Long getCycleId() { return cycleId; }
    public void setCycleId(Long cycleId) { this.cycleId = cycleId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public AppraisalType getType() { return type; }
    public void setType(AppraisalType type) { this.type = type; }

    public LocalDate getGoalSettingStart() { return goalSettingStart; }
    public void setGoalSettingStart(LocalDate goalSettingStart) { this.goalSettingStart = goalSettingStart; }

    public LocalDate getGoalSettingEnd() { return goalSettingEnd; }
    public void setGoalSettingEnd(LocalDate goalSettingEnd) { this.goalSettingEnd = goalSettingEnd; }

    public LocalDate getReviewStart() { return reviewStart; }
    public void setReviewStart(LocalDate reviewStart) { this.reviewStart = reviewStart; }

    public LocalDate getReviewEnd() { return reviewEnd; }
    public void setReviewEnd(LocalDate reviewEnd) { this.reviewEnd = reviewEnd; }

    public CycleStatus getStatus() { return status; }
    public void setStatus(CycleStatus status) { this.status = status; }
}
