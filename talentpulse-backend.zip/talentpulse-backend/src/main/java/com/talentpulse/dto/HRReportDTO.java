package com.talentpulse.dto;

import com.talentpulse.enums.ReportScope;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.HRReport}.
 */
public class HRReportDTO {

    private Long reportId;
    private ReportScope scope;
    private String metrics;
    private LocalDate generatedDate;

    public Long getReportId() { return reportId; }
    public void setReportId(Long reportId) { this.reportId = reportId; }

    public ReportScope getScope() { return scope; }
    public void setScope(ReportScope scope) { this.scope = scope; }

    public String getMetrics() { return metrics; }
    public void setMetrics(String metrics) { this.metrics = metrics; }

    public LocalDate getGeneratedDate() { return generatedDate; }
    public void setGeneratedDate(LocalDate generatedDate) { this.generatedDate = generatedDate; }
}
