package com.talentpulse.dto;

import com.talentpulse.enums.PayrollStatus;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.PayrollRun}.
 */
public class PayrollRunDTO {

    private Long payrollRunId;
    private Integer month;
    private Integer year;
    private Long processedBy;
    private LocalDate processedDate;
    private Double totalGross;
    private Double totalDeductions;
    private Double totalNet;
    private PayrollStatus status;

    public Long getPayrollRunId() { return payrollRunId; }
    public void setPayrollRunId(Long payrollRunId) { this.payrollRunId = payrollRunId; }

    public Integer getMonth() { return month; }
    public void setMonth(Integer month) { this.month = month; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public Long getProcessedBy() { return processedBy; }
    public void setProcessedBy(Long processedBy) { this.processedBy = processedBy; }

    public LocalDate getProcessedDate() { return processedDate; }
    public void setProcessedDate(LocalDate processedDate) { this.processedDate = processedDate; }

    public Double getTotalGross() { return totalGross; }
    public void setTotalGross(Double totalGross) { this.totalGross = totalGross; }

    public Double getTotalDeductions() { return totalDeductions; }
    public void setTotalDeductions(Double totalDeductions) { this.totalDeductions = totalDeductions; }

    public Double getTotalNet() { return totalNet; }
    public void setTotalNet(Double totalNet) { this.totalNet = totalNet; }

    public PayrollStatus getStatus() { return status; }
    public void setStatus(PayrollStatus status) { this.status = status; }
}
