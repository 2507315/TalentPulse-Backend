package com.talentpulse.dto;

import com.talentpulse.enums.RequisitionStatus;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.JobRequisition}.
 */
public class JobRequisitionDTO {

    private Long requisitionId;
    private Long departmentId;
    private String designation;
    private Long gradeId;
    private LocalDate requiredBy;
    private RequisitionStatus status;

    public Long getRequisitionId() { return requisitionId; }
    public void setRequisitionId(Long requisitionId) { this.requisitionId = requisitionId; }

    public Long getDepartmentId() { return departmentId; }
    public void setDepartmentId(Long departmentId) { this.departmentId = departmentId; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public Long getGradeId() { return gradeId; }
    public void setGradeId(Long gradeId) { this.gradeId = gradeId; }

    public LocalDate getRequiredBy() { return requiredBy; }
    public void setRequiredBy(LocalDate requiredBy) { this.requiredBy = requiredBy; }

    public RequisitionStatus getStatus() { return status; }
    public void setStatus(RequisitionStatus status) { this.status = status; }
}
