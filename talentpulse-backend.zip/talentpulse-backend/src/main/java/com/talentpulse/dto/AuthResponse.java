package com.talentpulse.dto;

import com.talentpulse.enums.Role;

/**
 * Login response payload containing the issued JWT.
 */
public class AuthResponse {

    private String token;
    private String email;
    private Role role;

    public AuthResponse() {
    }

    public AuthResponse(String token, String email, Role role) {
        this.token = token;
        this.email = email;
        this.role = role;
    }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
}
