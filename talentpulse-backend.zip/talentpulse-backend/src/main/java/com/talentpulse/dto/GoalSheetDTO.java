package com.talentpulse.dto;

import com.talentpulse.enums.GoalSheetStatus;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.GoalSheet}.
 */
public class GoalSheetDTO {

    private Long goalSheetId;
    private Long cycleId;
    private Long employeeId;
    private Long managerId;
    private String goalsJson;
    private Double selfRating;
    private Double managerRating;
    private Double finalRating;
    private GoalSheetStatus status;

    public Long getGoalSheetId() { return goalSheetId; }
    public void setGoalSheetId(Long goalSheetId) { this.goalSheetId = goalSheetId; }

    public Long getCycleId() { return cycleId; }
    public void setCycleId(Long cycleId) { this.cycleId = cycleId; }

    public Long getEmployeeId() { return employeeId; }
    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }

    public Long getManagerId() { return managerId; }
    public void setManagerId(Long managerId) { this.managerId = managerId; }

    public String getGoalsJson() { return goalsJson; }
    public void setGoalsJson(String goalsJson) { this.goalsJson = goalsJson; }

    public Double getSelfRating() { return selfRating; }
    public void setSelfRating(Double selfRating) { this.selfRating = selfRating; }

    public Double getManagerRating() { return managerRating; }
    public void setManagerRating(Double managerRating) { this.managerRating = managerRating; }

    public Double getFinalRating() { return finalRating; }
    public void setFinalRating(Double finalRating) { this.finalRating = finalRating; }

    public GoalSheetStatus getStatus() { return status; }
    public void setStatus(GoalSheetStatus status) { this.status = status; }
}
