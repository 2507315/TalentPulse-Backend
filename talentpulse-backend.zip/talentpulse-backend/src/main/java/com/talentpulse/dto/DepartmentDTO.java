package com.talentpulse.dto;

import com.talentpulse.enums.ActiveStatus;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.Department}.
 */
public class DepartmentDTO {

    private Long departmentId;
    private String departmentName;
    private String costCentreCode;
    private Long hrbpUserId;
    private ActiveStatus status;

    public Long getDepartmentId() { return departmentId; }
    public void setDepartmentId(Long departmentId) { this.departmentId = departmentId; }

    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }

    public String getCostCentreCode() { return costCentreCode; }
    public void setCostCentreCode(String costCentreCode) { this.costCentreCode = costCentreCode; }

    public Long getHrbpUserId() { return hrbpUserId; }
    public void setHrbpUserId(Long hrbpUserId) { this.hrbpUserId = hrbpUserId; }

    public ActiveStatus getStatus() { return status; }
    public void setStatus(ActiveStatus status) { this.status = status; }
}
