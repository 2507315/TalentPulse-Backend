package com.talentpulse.dto;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.GradeStructure}.
 */
public class GradeStructureDTO {

    private Long gradeId;
    private String gradeName;
    private String band;
    private Double minSalary;
    private Double maxSalary;
    private Integer leaveEntitlement;

    public Long getGradeId() { return gradeId; }
    public void setGradeId(Long gradeId) { this.gradeId = gradeId; }

    public String getGradeName() { return gradeName; }
    public void setGradeName(String gradeName) { this.gradeName = gradeName; }

    public String getBand() { return band; }
    public void setBand(String band) { this.band = band; }

    public Double getMinSalary() { return minSalary; }
    public void setMinSalary(Double minSalary) { this.minSalary = minSalary; }

    public Double getMaxSalary() { return maxSalary; }
    public void setMaxSalary(Double maxSalary) { this.maxSalary = maxSalary; }

    public Integer getLeaveEntitlement() { return leaveEntitlement; }
    public void setLeaveEntitlement(Integer leaveEntitlement) { this.leaveEntitlement = leaveEntitlement; }
}
