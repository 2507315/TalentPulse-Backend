package com.talentpulse.dto;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.LeaveBalance}.
 */
public class LeaveBalanceDTO {

    private Long balanceId;
    private Long employeeId;
    private Long leaveTypeId;
    private Integer year;
    private Double entitled;
    private Double taken;
    private Double pending;
    private Double balance;

    public Long getBalanceId() { return balanceId; }
    public void setBalanceId(Long balanceId) { this.balanceId = balanceId; }

    public Long getEmployeeId() { return employeeId; }
    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }

    public Long getLeaveTypeId() { return leaveTypeId; }
    public void setLeaveTypeId(Long leaveTypeId) { this.leaveTypeId = leaveTypeId; }

    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }

    public Double getEntitled() { return entitled; }
    public void setEntitled(Double entitled) { this.entitled = entitled; }

    public Double getTaken() { return taken; }
    public void setTaken(Double taken) { this.taken = taken; }

    public Double getPending() { return pending; }
    public void setPending(Double pending) { this.pending = pending; }

    public Double getBalance() { return balance; }
    public void setBalance(Double balance) { this.balance = balance; }
}
