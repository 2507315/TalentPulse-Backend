package com.talentpulse.dto;

import com.talentpulse.enums.RecommendationStatus;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.PromotionRecommendation}.
 */
public class PromotionRecommendationDTO {

    private Long recommendationId;
    private Long employeeId;
    private Long cycleId;
    private Long currentGradeId;
    private Long recommendedGradeId;
    private Long recommendedBy;
    private RecommendationStatus status;

    public Long getRecommendationId() { return recommendationId; }
    public void setRecommendationId(Long recommendationId) { this.recommendationId = recommendationId; }

    public Long getEmployeeId() { return employeeId; }
    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }

    public Long getCycleId() { return cycleId; }
    public void setCycleId(Long cycleId) { this.cycleId = cycleId; }

    public Long getCurrentGradeId() { return currentGradeId; }
    public void setCurrentGradeId(Long currentGradeId) { this.currentGradeId = currentGradeId; }

    public Long getRecommendedGradeId() { return recommendedGradeId; }
    public void setRecommendedGradeId(Long recommendedGradeId) { this.recommendedGradeId = recommendedGradeId; }

    public Long getRecommendedBy() { return recommendedBy; }
    public void setRecommendedBy(Long recommendedBy) { this.recommendedBy = recommendedBy; }

    public RecommendationStatus getStatus() { return status; }
    public void setStatus(RecommendationStatus status) { this.status = status; }
}
