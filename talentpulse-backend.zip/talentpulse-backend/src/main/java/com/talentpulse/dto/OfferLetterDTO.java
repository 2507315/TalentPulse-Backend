package com.talentpulse.dto;

import com.talentpulse.enums.OfferStatus;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.OfferLetter}.
 */
public class OfferLetterDTO {

    private Long offerId;
    private Long candidateId;
    private Long requisitionId;
    private Double offeredSalary;
    private LocalDate joiningDate;
    private LocalDate issuedDate;
    private OfferStatus status;

    public Long getOfferId() { return offerId; }
    public void setOfferId(Long offerId) { this.offerId = offerId; }

    public Long getCandidateId() { return candidateId; }
    public void setCandidateId(Long candidateId) { this.candidateId = candidateId; }

    public Long getRequisitionId() { return requisitionId; }
    public void setRequisitionId(Long requisitionId) { this.requisitionId = requisitionId; }

    public Double getOfferedSalary() { return offeredSalary; }
    public void setOfferedSalary(Double offeredSalary) { this.offeredSalary = offeredSalary; }

    public LocalDate getJoiningDate() { return joiningDate; }
    public void setJoiningDate(LocalDate joiningDate) { this.joiningDate = joiningDate; }

    public LocalDate getIssuedDate() { return issuedDate; }
    public void setIssuedDate(LocalDate issuedDate) { this.issuedDate = issuedDate; }

    public OfferStatus getStatus() { return status; }
    public void setStatus(OfferStatus status) { this.status = status; }
}
