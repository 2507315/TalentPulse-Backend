package com.talentpulse.dto;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.SalaryStructure}.
 */
public class SalaryStructureDTO {

    private Long structureId;
    private Long gradeId;
    private Double basicPercent;
    private Double hraPercent;
    private String allowances;
    private String deductionRules;
    private LocalDate effectiveDate;

    public Long getStructureId() { return structureId; }
    public void setStructureId(Long structureId) { this.structureId = structureId; }

    public Long getGradeId() { return gradeId; }
    public void setGradeId(Long gradeId) { this.gradeId = gradeId; }

    public Double getBasicPercent() { return basicPercent; }
    public void setBasicPercent(Double basicPercent) { this.basicPercent = basicPercent; }

    public Double getHraPercent() { return hraPercent; }
    public void setHraPercent(Double hraPercent) { this.hraPercent = hraPercent; }

    public String getAllowances() { return allowances; }
    public void setAllowances(String allowances) { this.allowances = allowances; }

    public String getDeductionRules() { return deductionRules; }
    public void setDeductionRules(String deductionRules) { this.deductionRules = deductionRules; }

    public LocalDate getEffectiveDate() { return effectiveDate; }
    public void setEffectiveDate(LocalDate effectiveDate) { this.effectiveDate = effectiveDate; }
}
