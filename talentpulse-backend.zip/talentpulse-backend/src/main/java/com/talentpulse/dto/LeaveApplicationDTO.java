package com.talentpulse.dto;

import com.talentpulse.enums.LeaveStatus;

import java.time.LocalDate;

/**
 * Data Transfer Object for {@link com.talentpulse.entity.LeaveApplication}.
 */
public class LeaveApplicationDTO {

    private Long applicationId;
    private Long employeeId;
    private Long leaveTypeId;
    private LocalDate fromDate;
    private LocalDate toDate;
    private Double daysRequested;
    private String reason;
    private Long approverId;
    private LeaveStatus status;

    public Long getApplicationId() { return applicationId; }
    public void setApplicationId(Long applicationId) { this.applicationId = applicationId; }

    public Long getEmployeeId() { return employeeId; }
    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }

    public Long getLeaveTypeId() { return leaveTypeId; }
    public void setLeaveTypeId(Long leaveTypeId) { this.leaveTypeId = leaveTypeId; }

    public LocalDate getFromDate() { return fromDate; }
    public void setFromDate(LocalDate fromDate) { this.fromDate = fromDate; }

    public LocalDate getToDate() { return toDate; }
    public void setToDate(LocalDate toDate) { this.toDate = toDate; }

    public Double getDaysRequested() { return daysRequested; }
    public void setDaysRequested(Double daysRequested) { this.daysRequested = daysRequested; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public Long getApproverId() { return approverId; }
    public void setApproverId(Long approverId) { this.approverId = approverId; }

    public LeaveStatus getStatus() { return status; }
    public void setStatus(LeaveStatus status) { this.status = status; }
}
