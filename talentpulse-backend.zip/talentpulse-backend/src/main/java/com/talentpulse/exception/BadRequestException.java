package com.talentpulse.exception;

/**
 * Thrown when a request violates a business rule (e.g. invalid payslip amounts
 * or an illegal payroll status transition). Mapped to HTTP 400 Bad Request.
 */
public class BadRequestException extends RuntimeException {

    public BadRequestException(String message) {
        super(message);
    }
}
