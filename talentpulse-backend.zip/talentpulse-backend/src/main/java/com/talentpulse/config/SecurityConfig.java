package com.talentpulse.config;

import com.talentpulse.security.CustomUserDetailsService;
import com.talentpulse.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.http.HttpMethod;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

/**
 * Spring Security configuration: stateless JWT authentication + role-based access control.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthFilter;
    private final CustomUserDetailsService userDetailsService;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthFilter, CustomUserDetailsService userDetailsService) {
        this.jwtAuthFilter = jwtAuthFilter;
        this.userDetailsService = userDetailsService;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .authorizeHttpRequests(auth -> auth
                        // ---- Public ----
                        .requestMatchers("/auth/**").permitAll()

                        // ---- Identity & Access Management (admin only) ----
                        .requestMatchers("/users/**", "/audit-logs/**").hasRole("ADMIN")

                        // ---- Read rules that are broader than write rules (must come BEFORE the path rules) ----
                        // Employees / Departments / Grades: anyone logged in may read
                        .requestMatchers(HttpMethod.GET, "/employees/**", "/departments/**", "/grades/**").authenticated()
                        // Leave & Attendance: anyone logged in may read
                        .requestMatchers(HttpMethod.GET, "/leave-types/**", "/leave-balances/**",
                                "/leave-applications/**", "/attendance-records/**").authenticated()
                        // Performance (cycles & goal sheets): anyone logged in may read
                        .requestMatchers(HttpMethod.GET, "/appraisal-cycles/**", "/goal-sheets/**").authenticated()
                        // Recruitment requisitions: managers may also read
                        .requestMatchers(HttpMethod.GET, "/job-requisitions/**")
                                .hasAnyRole("RECRUITER", "HRBP", "MANAGER", "ADMIN","EMPLOYEE")
                        // Payslips: employees may also read their payslips
                        .requestMatchers(HttpMethod.GET, "/payslips/**").hasAnyRole("PAYROLL", "ADMIN", "EMPLOYEE")
                        // Salary structures: payroll may read; only admin configures them (write rule below)
                        .requestMatchers(HttpMethod.GET, "/salary-structures/**").hasAnyRole("PAYROLL", "ADMIN")

                        // ---- Employee Profile & Organisation (write) ----
                        .requestMatchers("/grades/**").hasRole("ADMIN")
                        .requestMatchers("/employees/**", "/departments/**").hasAnyRole("HRBP", "ADMIN")

                        // ---- Recruitment & Applicant Tracking ----
                        .requestMatchers("/job-requisitions/**", "/candidates/**", "/offer-letters/**")
                                .hasAnyRole("RECRUITER", "HRBP", "ADMIN")
                        .requestMatchers("/interview-rounds/**").hasAnyRole("RECRUITER", "HRBP", "MANAGER", "ADMIN")

                        // ---- Leave & Attendance (write) ----
                        .requestMatchers("/leave-types/**", "/leave-balances/**").hasAnyRole("HRBP", "ADMIN")
                        .requestMatchers("/leave-applications/**", "/attendance-records/**")
                                .hasAnyRole("EMPLOYEE", "MANAGER", "HRBP", "ADMIN")

                        // ---- Payroll & Compensation ----
                        // Salary structure is configured by HR Admin (Admin Console); payroll only reads it.
                        .requestMatchers("/salary-structures/**").hasRole("ADMIN")
                        .requestMatchers("/payroll-runs/**", "/payslips/**").hasAnyRole("PAYROLL", "ADMIN")

                        // ---- Performance & Appraisal (write) ----
                        .requestMatchers("/appraisal-cycles/**").hasAnyRole("HRBP", "ADMIN")
                        .requestMatchers("/goal-sheets/**").hasAnyRole("EMPLOYEE", "MANAGER", "HRBP", "ADMIN")
                        .requestMatchers("/promotion-recommendations/**").hasAnyRole("MANAGER", "HRBP", "ADMIN")

                        // ---- HR Analytics & Reporting ----
                        .requestMatchers("/hr-reports/**").hasAnyRole("HRBP", "ADMIN")

                        // ---- Notifications (any authenticated user) ----
                        .requestMatchers("/notifications/**").authenticated()

                        // Everything else requires authentication
                        .anyRequest().authenticated())
                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authenticationProvider(authenticationProvider())
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(Arrays.asList("http://localhost:3000", "http://localhost:5173"));
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"));
        config.setAllowedHeaders(Arrays.asList("*"));
        config.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
