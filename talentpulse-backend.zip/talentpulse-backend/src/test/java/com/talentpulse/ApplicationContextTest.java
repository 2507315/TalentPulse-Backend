package com.talentpulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Boots the entire Spring application context on an in-memory H2 database.
 * This validates that every repository query, JPA entity mapping, foreign-key
 * association and bean wiring loads successfully at startup - the kind of
 * problem that mocked unit tests cannot detect.
 */
@SpringBootTest
class ApplicationContextTest {

    @Test
    void contextLoads() {
        // The test passes if the application context starts without error.
    }
}
