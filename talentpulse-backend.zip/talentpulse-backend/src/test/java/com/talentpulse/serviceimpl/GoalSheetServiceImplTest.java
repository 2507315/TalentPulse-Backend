package com.talentpulse.serviceimpl;

import com.talentpulse.dto.GoalSheetDTO;
import com.talentpulse.entity.AppraisalCycle;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GoalSheet;
import com.talentpulse.enums.GoalSheetStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AppraisalCycleRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GoalSheetRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GoalSheetServiceImplTest {

    @Mock
    private GoalSheetRepository goalSheetRepository;

    @Mock
    private AppraisalCycleRepository appraisalCycleRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private GoalSheetServiceImpl service;

    private AppraisalCycle cycle(Long id) {
        AppraisalCycle c = new AppraisalCycle();
        c.setCycleId(id);
        return c;
    }

    private Employee employee(Long id) {
        Employee emp = new Employee();
        emp.setEmployeeId(id);
        return emp;
    }

    private GoalSheet buildEntity(Long id) {
        GoalSheet e = new GoalSheet();
        e.setGoalSheetId(id);
        e.setCycle(cycle(100L));
        e.setEmployee(employee(200L));
        e.setManager(employee(300L));
        e.setGoalsJson("{\"goals\":[]}");
        e.setSelfRating(4.0);
        e.setManagerRating(4.5);
        e.setFinalRating(4.2);
        e.setStatus(GoalSheetStatus.SUBMITTED);
        return e;
    }

    private GoalSheetDTO buildDto() {
        GoalSheetDTO dto = new GoalSheetDTO();
        dto.setCycleId(100L);
        dto.setEmployeeId(200L);
        dto.setManagerId(300L);
        dto.setGoalsJson("{\"goals\":[]}");
        dto.setSelfRating(4.0);
        dto.setManagerRating(4.5);
        dto.setFinalRating(4.2);
        dto.setStatus(GoalSheetStatus.SUBMITTED);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(goalSheetRepository.findAll()).thenReturn(List.of(buildEntity(1L), buildEntity(2L)));

        List<GoalSheetDTO> result = service.getAll();

        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getGoalSheetId());
        assertEquals(100L, result.get(0).getCycleId());
        assertEquals(GoalSheetStatus.SUBMITTED, result.get(0).getStatus());
        assertEquals(2L, result.get(1).getGoalSheetId());
        verify(goalSheetRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(goalSheetRepository.findById(1L)).thenReturn(Optional.of(buildEntity(1L)));

        GoalSheetDTO result = service.getById(1L);

        assertEquals(1L, result.getGoalSheetId());
        assertEquals(200L, result.getEmployeeId());
        assertEquals(4.0, result.getSelfRating());
        assertEquals(4.2, result.getFinalRating());
        verify(goalSheetRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(goalSheetRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        GoalSheetDTO dto = buildDto();
        lenient().when(appraisalCycleRepository.findById(100L)).thenReturn(Optional.of(cycle(100L)));
        lenient().when(employeeRepository.findById(200L)).thenReturn(Optional.of(employee(200L)));
        lenient().when(employeeRepository.findById(300L)).thenReturn(Optional.of(employee(300L)));
        when(goalSheetRepository.save(any(GoalSheet.class))).thenReturn(buildEntity(10L));

        GoalSheetDTO result = service.create(dto);

        assertEquals(10L, result.getGoalSheetId());
        assertEquals(100L, result.getCycleId());
        assertEquals(GoalSheetStatus.SUBMITTED, result.getStatus());
        verify(goalSheetRepository).save(any(GoalSheet.class));
    }

    @Test
    void delete_verifiesRepositoryDelete() {
        GoalSheet entity = buildEntity(5L);
        when(goalSheetRepository.findById(5L)).thenReturn(Optional.of(entity));

        service.delete(5L);

        verify(goalSheetRepository).findById(5L);
        verify(goalSheetRepository, times(1)).delete(entity);
    }
}
