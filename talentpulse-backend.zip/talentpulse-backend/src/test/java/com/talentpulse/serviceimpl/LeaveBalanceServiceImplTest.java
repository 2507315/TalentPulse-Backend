package com.talentpulse.serviceimpl;

import com.talentpulse.dto.LeaveBalanceDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.LeaveBalance;
import com.talentpulse.entity.LeaveType;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.LeaveBalanceRepository;
import com.talentpulse.repository.LeaveTypeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LeaveBalanceServiceImplTest {

    @Mock
    private LeaveBalanceRepository leaveBalanceRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private LeaveTypeRepository leaveTypeRepository;

    @InjectMocks
    private LeaveBalanceServiceImpl service;

    private Employee buildEmployee() {
        Employee emp = new Employee();
        emp.setEmployeeId(100L);
        return emp;
    }

    private LeaveType buildLeaveType() {
        LeaveType lt = new LeaveType();
        lt.setLeaveTypeId(5L);
        return lt;
    }

    private LeaveBalance buildEntity() {
        LeaveBalance e = new LeaveBalance();
        e.setBalanceId(1L);
        e.setEmployee(buildEmployee());
        e.setLeaveType(buildLeaveType());
        e.setYear(2026);
        e.setEntitled(12.0);
        e.setTaken(3.0);
        e.setPending(1.0);
        e.setBalance(8.0);
        return e;
    }

    private LeaveBalanceDTO buildDto() {
        LeaveBalanceDTO dto = new LeaveBalanceDTO();
        dto.setEmployeeId(100L);
        dto.setLeaveTypeId(5L);
        dto.setYear(2026);
        dto.setEntitled(12.0);
        dto.setTaken(3.0);
        dto.setPending(1.0);
        dto.setBalance(8.0);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(leaveBalanceRepository.findAll()).thenReturn(List.of(buildEntity()));

        List<LeaveBalanceDTO> result = service.getAll();

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getBalanceId());
        assertEquals(100L, result.get(0).getEmployeeId());
        assertEquals(8.0, result.get(0).getBalance());
        verify(leaveBalanceRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(leaveBalanceRepository.findById(1L)).thenReturn(Optional.of(buildEntity()));

        LeaveBalanceDTO result = service.getById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getBalanceId());
        assertEquals(2026, result.getYear());
        assertEquals(12.0, result.getEntitled());
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(leaveBalanceRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        when(employeeRepository.findById(100L)).thenReturn(Optional.of(buildEmployee()));
        when(leaveTypeRepository.findById(5L)).thenReturn(Optional.of(buildLeaveType()));
        when(leaveBalanceRepository.save(any(LeaveBalance.class))).thenReturn(buildEntity());

        LeaveBalanceDTO result = service.create(buildDto());

        assertNotNull(result);
        assertEquals(1L, result.getBalanceId());
        assertEquals(100L, result.getEmployeeId());
        verify(leaveBalanceRepository).save(any(LeaveBalance.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        LeaveBalance entity = buildEntity();
        when(leaveBalanceRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(leaveBalanceRepository).delete(entity);
    }
}
