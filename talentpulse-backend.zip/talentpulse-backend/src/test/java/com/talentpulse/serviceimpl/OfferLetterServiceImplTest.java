package com.talentpulse.serviceimpl;

import com.talentpulse.dto.OfferLetterDTO;
import com.talentpulse.entity.Candidate;
import com.talentpulse.entity.JobRequisition;
import com.talentpulse.entity.OfferLetter;
import com.talentpulse.enums.OfferStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.CandidateRepository;
import com.talentpulse.repository.JobRequisitionRepository;
import com.talentpulse.repository.OfferLetterRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OfferLetterServiceImplTest {

    @Mock
    private OfferLetterRepository offerLetterRepository;

    @Mock
    private CandidateRepository candidateRepository;

    @Mock
    private JobRequisitionRepository jobRequisitionRepository;

    @InjectMocks
    private OfferLetterServiceImpl service;

    private OfferLetter entity;
    private Candidate candidate;
    private JobRequisition requisition;

    @BeforeEach
    void setUp() {
        candidate = new Candidate();
        candidate.setCandidateId(100L);

        requisition = new JobRequisition();
        requisition.setRequisitionId(200L);

        entity = new OfferLetter();
        entity.setOfferId(1L);
        entity.setCandidate(candidate);
        entity.setRequisition(requisition);
        entity.setOfferedSalary(95000.0);
        entity.setJoiningDate(LocalDate.of(2026, 8, 1));
        entity.setIssuedDate(LocalDate.of(2026, 6, 15));
        entity.setStatus(OfferStatus.ISSUED);
    }

    @Test
    void getAll_returnsMappedList() {
        when(offerLetterRepository.findAll()).thenReturn(List.of(entity));

        List<OfferLetterDTO> result = service.getAll();

        assertEquals(1, result.size());
        OfferLetterDTO dto = result.get(0);
        assertEquals(1L, dto.getOfferId());
        assertEquals(100L, dto.getCandidateId());
        assertEquals(200L, dto.getRequisitionId());
        assertEquals(95000.0, dto.getOfferedSalary());
        assertEquals(LocalDate.of(2026, 8, 1), dto.getJoiningDate());
        assertEquals(LocalDate.of(2026, 6, 15), dto.getIssuedDate());
        assertEquals(OfferStatus.ISSUED, dto.getStatus());
        verify(offerLetterRepository).findAll();
    }

    @Test
    void getById_found_returnsMappedDto() {
        when(offerLetterRepository.findById(1L)).thenReturn(Optional.of(entity));

        OfferLetterDTO dto = service.getById(1L);

        assertNotNull(dto);
        assertEquals(1L, dto.getOfferId());
        assertEquals(95000.0, dto.getOfferedSalary());
        assertEquals(OfferStatus.ISSUED, dto.getStatus());
        verify(offerLetterRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(offerLetterRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
        verify(offerLetterRepository).findById(99L);
    }

    @Test
    void create_returnsSavedDto() {
        OfferLetterDTO input = new OfferLetterDTO();
        input.setCandidateId(100L);
        input.setRequisitionId(200L);
        input.setOfferedSalary(95000.0);
        input.setJoiningDate(LocalDate.of(2026, 8, 1));
        input.setIssuedDate(LocalDate.of(2026, 6, 15));
        input.setStatus(OfferStatus.ACCEPTED);

        when(candidateRepository.findById(100L)).thenReturn(Optional.of(candidate));
        when(jobRequisitionRepository.findById(200L)).thenReturn(Optional.of(requisition));
        when(offerLetterRepository.save(any(OfferLetter.class))).thenReturn(entity);

        OfferLetterDTO result = service.create(input);

        assertNotNull(result);
        assertEquals(1L, result.getOfferId());
        assertEquals(OfferStatus.ISSUED, result.getStatus());

        ArgumentCaptor<OfferLetter> captor = ArgumentCaptor.forClass(OfferLetter.class);
        verify(offerLetterRepository).save(captor.capture());
        assertEquals(100L, captor.getValue().getCandidate().getCandidateId());
        assertEquals(95000.0, captor.getValue().getOfferedSalary());
        assertEquals(OfferStatus.ACCEPTED, captor.getValue().getStatus());
    }

    @Test
    void delete_found_deletesEntity() {
        when(offerLetterRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(offerLetterRepository).findById(1L);
        verify(offerLetterRepository).delete(entity);
    }
}
