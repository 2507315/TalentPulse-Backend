package com.talentpulse.serviceimpl;

import com.talentpulse.dto.AttendanceRecordDTO;
import com.talentpulse.entity.AttendanceRecord;
import com.talentpulse.entity.Employee;
import com.talentpulse.enums.AttendanceStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AttendanceRecordRepository;
import com.talentpulse.repository.EmployeeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AttendanceRecordServiceImplTest {

    @Mock
    private AttendanceRecordRepository attendanceRecordRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private AttendanceRecordServiceImpl service;

    private Employee buildEmployee() {
        Employee emp = new Employee();
        emp.setEmployeeId(100L);
        return emp;
    }

    private AttendanceRecord buildEntity() {
        AttendanceRecord e = new AttendanceRecord();
        e.setAttendanceId(1L);
        e.setEmployee(buildEmployee());
        e.setDate(LocalDate.of(2026, 6, 16));
        e.setCheckIn(LocalTime.of(9, 0));
        e.setCheckOut(LocalTime.of(17, 30));
        e.setWorkingHours(8.5);
        e.setStatus(AttendanceStatus.PRESENT);
        return e;
    }

    private AttendanceRecordDTO buildDto() {
        AttendanceRecordDTO dto = new AttendanceRecordDTO();
        dto.setEmployeeId(100L);
        dto.setDate(LocalDate.of(2026, 6, 16));
        dto.setCheckIn(LocalTime.of(9, 0));
        dto.setCheckOut(LocalTime.of(17, 30));
        dto.setWorkingHours(8.5);
        dto.setStatus(AttendanceStatus.PRESENT);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(attendanceRecordRepository.findAll()).thenReturn(List.of(buildEntity()));

        List<AttendanceRecordDTO> result = service.getAll();

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getAttendanceId());
        assertEquals(AttendanceStatus.PRESENT, result.get(0).getStatus());
        assertEquals(LocalTime.of(9, 0), result.get(0).getCheckIn());
        verify(attendanceRecordRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(attendanceRecordRepository.findById(1L)).thenReturn(Optional.of(buildEntity()));

        AttendanceRecordDTO result = service.getById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getAttendanceId());
        assertEquals(LocalDate.of(2026, 6, 16), result.getDate());
        assertEquals(LocalTime.of(17, 30), result.getCheckOut());
        assertEquals(8.5, result.getWorkingHours());
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(attendanceRecordRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        when(employeeRepository.findById(100L)).thenReturn(Optional.of(buildEmployee()));
        when(attendanceRecordRepository.save(any(AttendanceRecord.class))).thenReturn(buildEntity());

        AttendanceRecordDTO result = service.create(buildDto());

        assertNotNull(result);
        assertEquals(1L, result.getAttendanceId());
        assertEquals(AttendanceStatus.PRESENT, result.getStatus());
        verify(attendanceRecordRepository).save(any(AttendanceRecord.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        AttendanceRecord entity = buildEntity();
        when(attendanceRecordRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(attendanceRecordRepository).delete(entity);
    }
}
