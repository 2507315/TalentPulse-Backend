package com.talentpulse.serviceimpl;

import com.talentpulse.dto.LeaveApplicationDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.LeaveApplication;
import com.talentpulse.entity.LeaveType;
import com.talentpulse.enums.LeaveStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.LeaveApplicationRepository;
import com.talentpulse.repository.LeaveTypeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LeaveApplicationServiceImplTest {

    @Mock
    private LeaveApplicationRepository leaveApplicationRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private LeaveTypeRepository leaveTypeRepository;

    @InjectMocks
    private LeaveApplicationServiceImpl service;

    private Employee buildEmployee(Long id) {
        Employee emp = new Employee();
        emp.setEmployeeId(id);
        return emp;
    }

    private LeaveType buildLeaveType() {
        LeaveType lt = new LeaveType();
        lt.setLeaveTypeId(5L);
        return lt;
    }

    private LeaveApplication buildEntity() {
        LeaveApplication e = new LeaveApplication();
        e.setApplicationId(1L);
        e.setEmployee(buildEmployee(100L));
        e.setLeaveType(buildLeaveType());
        e.setFromDate(LocalDate.of(2026, 6, 1));
        e.setToDate(LocalDate.of(2026, 6, 3));
        e.setDaysRequested(3.0);
        e.setReason("Vacation");
        e.setApprover(buildEmployee(200L));
        e.setStatus(LeaveStatus.PENDING);
        return e;
    }

    private LeaveApplicationDTO buildDto() {
        LeaveApplicationDTO dto = new LeaveApplicationDTO();
        dto.setEmployeeId(100L);
        dto.setLeaveTypeId(5L);
        dto.setFromDate(LocalDate.of(2026, 6, 1));
        dto.setToDate(LocalDate.of(2026, 6, 3));
        dto.setDaysRequested(3.0);
        dto.setReason("Vacation");
        dto.setApproverId(200L);
        dto.setStatus(LeaveStatus.PENDING);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(leaveApplicationRepository.findAll()).thenReturn(List.of(buildEntity()));

        List<LeaveApplicationDTO> result = service.getAll();

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getApplicationId());
        assertEquals(LeaveStatus.PENDING, result.get(0).getStatus());
        assertEquals(LocalDate.of(2026, 6, 1), result.get(0).getFromDate());
        verify(leaveApplicationRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(leaveApplicationRepository.findById(1L)).thenReturn(Optional.of(buildEntity()));

        LeaveApplicationDTO result = service.getById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getApplicationId());
        assertEquals(3.0, result.getDaysRequested());
        assertEquals("Vacation", result.getReason());
        assertEquals(LocalDate.of(2026, 6, 3), result.getToDate());
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(leaveApplicationRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        when(employeeRepository.findById(100L)).thenReturn(Optional.of(buildEmployee(100L)));
        when(employeeRepository.findById(200L)).thenReturn(Optional.of(buildEmployee(200L)));
        when(leaveTypeRepository.findById(5L)).thenReturn(Optional.of(buildLeaveType()));
        when(leaveApplicationRepository.save(any(LeaveApplication.class))).thenReturn(buildEntity());

        LeaveApplicationDTO result = service.create(buildDto());

        assertNotNull(result);
        assertEquals(1L, result.getApplicationId());
        assertEquals(LeaveStatus.PENDING, result.getStatus());
        verify(leaveApplicationRepository).save(any(LeaveApplication.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        LeaveApplication entity = buildEntity();
        when(leaveApplicationRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(leaveApplicationRepository).delete(entity);
    }
}
