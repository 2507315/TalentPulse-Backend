package com.talentpulse.serviceimpl;

import com.talentpulse.dto.HRReportDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.HRReport;
import com.talentpulse.entity.Payslip;
import com.talentpulse.enums.EmployeeStatus;
import com.talentpulse.enums.ReportScope;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GoalSheetRepository;
import com.talentpulse.repository.HRReportRepository;
import com.talentpulse.repository.LeaveBalanceRepository;
import com.talentpulse.repository.PayslipRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class HRReportServiceImplTest {

    @Mock
    private HRReportRepository hrReportRepository;
    @Mock
    private EmployeeRepository employeeRepository;
    @Mock
    private PayslipRepository payslipRepository;
    @Mock
    private LeaveBalanceRepository leaveBalanceRepository;
    @Mock
    private GoalSheetRepository goalSheetRepository;

    @InjectMocks
    private HRReportServiceImpl service;

    private HRReport entity;

    @BeforeEach
    void setUp() {
        entity = new HRReport();
        entity.setReportId(1L);
        entity.setScope(ReportScope.DEPARTMENT);
        entity.setMetrics("Headcount=120,AttritionRate=5.2");
        entity.setGeneratedDate(LocalDate.of(2026, 6, 1));
    }

    @Test
    void getAll_returnsMappedList() {
        when(hrReportRepository.findAll()).thenReturn(List.of(entity));

        List<HRReportDTO> result = service.getAll();

        assertEquals(1, result.size());
        HRReportDTO dto = result.get(0);
        assertEquals(1L, dto.getReportId());
        assertEquals(ReportScope.DEPARTMENT, dto.getScope());
        assertEquals("Headcount=120,AttritionRate=5.2", dto.getMetrics());
        assertEquals(LocalDate.of(2026, 6, 1), dto.getGeneratedDate());
        verify(hrReportRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(hrReportRepository.findById(1L)).thenReturn(Optional.of(entity));

        HRReportDTO dto = service.getById(1L);

        assertEquals(1L, dto.getReportId());
        assertEquals(ReportScope.DEPARTMENT, dto.getScope());
        verify(hrReportRepository).findById(1L);
    }

    @Test
    void getById_notFound_throws() {
        when(hrReportRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        HRReportDTO input = new HRReportDTO();
        input.setScope(ReportScope.GRADE);
        input.setMetrics("AvgTenure=3.4");
        input.setGeneratedDate(LocalDate.of(2026, 6, 1));

        when(hrReportRepository.save(any(HRReport.class))).thenReturn(entity);

        HRReportDTO result = service.create(input);

        assertEquals(1L, result.getReportId());
        assertEquals(ReportScope.DEPARTMENT, result.getScope());
        assertEquals("Headcount=120,AttritionRate=5.2", result.getMetrics());
        verify(hrReportRepository).save(any(HRReport.class));
    }

    @Test
    void generate_computesMetricsFromLiveData() {
        Employee active = new Employee();
        active.setStatus(EmployeeStatus.ACTIVE);
        active.setJoiningDate(LocalDate.of(2022, 1, 1));
        Employee exited = new Employee();
        exited.setStatus(EmployeeStatus.EXITED);
        exited.setJoiningDate(LocalDate.of(2020, 1, 1));

        Payslip slip = new Payslip();
        slip.setNetAmount(68000.0);

        when(employeeRepository.findAll()).thenReturn(List.of(active, exited));
        when(payslipRepository.findAll()).thenReturn(List.of(slip));
        when(leaveBalanceRepository.findAll()).thenReturn(List.of());
        when(goalSheetRepository.findAll()).thenReturn(List.of());
        when(hrReportRepository.save(any(HRReport.class))).thenAnswer(inv -> inv.getArgument(0));

        HRReportDTO dto = service.generate(ReportScope.PERIOD);

        assertEquals(ReportScope.PERIOD, dto.getScope());
        assertNotNull(dto.getGeneratedDate());
        // metrics are computed live and serialised to JSON
        assertTrue(dto.getMetrics().contains("\"Headcount\":2"));
        assertTrue(dto.getMetrics().contains("\"AttritionRate\":50.0")); // 1 of 2 exited
        assertTrue(dto.getMetrics().contains("\"PayrollCost\":68000.0"));
        verify(hrReportRepository).save(any(HRReport.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        when(hrReportRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(hrReportRepository).findById(1L);
        verify(hrReportRepository, times(1)).delete(entity);
    }
}
