package com.talentpulse.serviceimpl;

import com.talentpulse.dto.NotificationDTO;
import com.talentpulse.entity.Notification;
import com.talentpulse.entity.User;
import com.talentpulse.enums.NotificationCategory;
import com.talentpulse.enums.NotificationStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.NotificationRepository;
import com.talentpulse.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class NotificationServiceImplTest {

    @Mock
    private NotificationRepository notificationRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private NotificationServiceImpl service;

    private static final LocalDateTime CREATED = LocalDateTime.of(2026, 6, 16, 10, 30);

    private User buildUser() {
        User u = new User();
        u.setUserId(200L);
        return u;
    }

    private Notification buildEntity(Long id) {
        Notification e = new Notification();
        e.setNotificationId(id);
        e.setUser(buildUser());
        e.setMessage("Your appraisal is due");
        e.setCategory(NotificationCategory.APPRAISAL);
        e.setStatus(NotificationStatus.UNREAD);
        e.setCreatedDate(CREATED);
        return e;
    }

    private NotificationDTO buildDto() {
        NotificationDTO dto = new NotificationDTO();
        dto.setUserId(200L);
        dto.setMessage("Your appraisal is due");
        dto.setCategory(NotificationCategory.APPRAISAL);
        dto.setStatus(NotificationStatus.UNREAD);
        dto.setCreatedDate(CREATED);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(notificationRepository.findAll()).thenReturn(List.of(buildEntity(1L), buildEntity(2L)));

        List<NotificationDTO> result = service.getAll();

        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getNotificationId());
        assertEquals(NotificationCategory.APPRAISAL, result.get(0).getCategory());
        assertEquals(NotificationStatus.UNREAD, result.get(0).getStatus());
        assertEquals(CREATED, result.get(0).getCreatedDate());
        assertEquals(2L, result.get(1).getNotificationId());
        verify(notificationRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(notificationRepository.findById(1L)).thenReturn(Optional.of(buildEntity(1L)));

        NotificationDTO result = service.getById(1L);

        assertEquals(1L, result.getNotificationId());
        assertEquals(200L, result.getUserId());
        assertEquals("Your appraisal is due", result.getMessage());
        assertEquals(CREATED, result.getCreatedDate());
        verify(notificationRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(notificationRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        NotificationDTO dto = buildDto();
        when(userRepository.findById(200L)).thenReturn(Optional.of(buildUser()));
        when(notificationRepository.save(any(Notification.class))).thenReturn(buildEntity(10L));

        NotificationDTO result = service.create(dto);

        assertEquals(10L, result.getNotificationId());
        assertEquals(NotificationCategory.APPRAISAL, result.getCategory());
        assertEquals(CREATED, result.getCreatedDate());
        verify(notificationRepository).save(any(Notification.class));
    }

    @Test
    void create_defaultsCreatedDateWhenNull() {
        NotificationDTO dto = buildDto();
        dto.setCreatedDate(null);
        when(userRepository.findById(200L)).thenReturn(Optional.of(buildUser()));
        when(notificationRepository.save(any(Notification.class))).thenReturn(buildEntity(11L));

        NotificationDTO result = service.create(dto);

        assertNotNull(dto.getCreatedDate());
        assertEquals(11L, result.getNotificationId());
        verify(notificationRepository).save(any(Notification.class));
    }

    @Test
    void delete_verifiesRepositoryDelete() {
        Notification entity = buildEntity(5L);
        when(notificationRepository.findById(5L)).thenReturn(Optional.of(entity));

        service.delete(5L);

        verify(notificationRepository).findById(5L);
        verify(notificationRepository, times(1)).delete(entity);
    }
}
