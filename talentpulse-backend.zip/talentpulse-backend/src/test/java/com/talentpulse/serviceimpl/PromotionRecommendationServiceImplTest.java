package com.talentpulse.serviceimpl;

import com.talentpulse.dto.PromotionRecommendationDTO;
import com.talentpulse.entity.AppraisalCycle;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.PromotionRecommendation;
import com.talentpulse.enums.RecommendationStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AppraisalCycleRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.PromotionRecommendationRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PromotionRecommendationServiceImplTest {

    @Mock
    private PromotionRecommendationRepository promotionRecommendationRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private AppraisalCycleRepository appraisalCycleRepository;

    @Mock
    private GradeStructureRepository gradeStructureRepository;

    @InjectMocks
    private PromotionRecommendationServiceImpl service;

    private Employee employee(Long id) {
        Employee e = new Employee();
        e.setEmployeeId(id);
        return e;
    }

    private AppraisalCycle cycle(Long id) {
        AppraisalCycle c = new AppraisalCycle();
        c.setCycleId(id);
        return c;
    }

    private GradeStructure grade(Long id) {
        GradeStructure g = new GradeStructure();
        g.setGradeId(id);
        return g;
    }

    private PromotionRecommendation buildEntity(Long id) {
        PromotionRecommendation e = new PromotionRecommendation();
        e.setRecommendationId(id);
        e.setEmployee(employee(200L));
        e.setCycle(cycle(100L));
        e.setCurrentGrade(grade(5L));
        e.setRecommendedGrade(grade(6L));
        e.setRecommendedByEmployee(employee(300L));
        e.setStatus(RecommendationStatus.RECOMMENDED);
        return e;
    }

    private PromotionRecommendationDTO buildDto() {
        PromotionRecommendationDTO dto = new PromotionRecommendationDTO();
        dto.setEmployeeId(200L);
        dto.setCycleId(100L);
        dto.setCurrentGradeId(5L);
        dto.setRecommendedGradeId(6L);
        dto.setRecommendedBy(300L);
        dto.setStatus(RecommendationStatus.RECOMMENDED);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(promotionRecommendationRepository.findAll())
                .thenReturn(List.of(buildEntity(1L), buildEntity(2L)));

        List<PromotionRecommendationDTO> result = service.getAll();

        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getRecommendationId());
        assertEquals(200L, result.get(0).getEmployeeId());
        assertEquals(RecommendationStatus.RECOMMENDED, result.get(0).getStatus());
        assertEquals(2L, result.get(1).getRecommendationId());
        verify(promotionRecommendationRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(promotionRecommendationRepository.findById(1L)).thenReturn(Optional.of(buildEntity(1L)));

        PromotionRecommendationDTO result = service.getById(1L);

        assertEquals(1L, result.getRecommendationId());
        assertEquals(5L, result.getCurrentGradeId());
        assertEquals(6L, result.getRecommendedGradeId());
        assertEquals(300L, result.getRecommendedBy());
        verify(promotionRecommendationRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(promotionRecommendationRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        PromotionRecommendationDTO dto = buildDto();
        lenient().when(employeeRepository.findById(200L)).thenReturn(Optional.of(employee(200L)));
        lenient().when(employeeRepository.findById(300L)).thenReturn(Optional.of(employee(300L)));
        lenient().when(appraisalCycleRepository.findById(100L)).thenReturn(Optional.of(cycle(100L)));
        lenient().when(gradeStructureRepository.findById(5L)).thenReturn(Optional.of(grade(5L)));
        lenient().when(gradeStructureRepository.findById(6L)).thenReturn(Optional.of(grade(6L)));
        when(promotionRecommendationRepository.save(any(PromotionRecommendation.class)))
                .thenReturn(buildEntity(10L));

        PromotionRecommendationDTO result = service.create(dto);

        assertEquals(10L, result.getRecommendationId());
        assertEquals(200L, result.getEmployeeId());
        assertEquals(RecommendationStatus.RECOMMENDED, result.getStatus());
        verify(promotionRecommendationRepository).save(any(PromotionRecommendation.class));
    }

    @Test
    void delete_verifiesRepositoryDelete() {
        PromotionRecommendation entity = buildEntity(5L);
        when(promotionRecommendationRepository.findById(5L)).thenReturn(Optional.of(entity));

        service.delete(5L);

        verify(promotionRecommendationRepository).findById(5L);
        verify(promotionRecommendationRepository, times(1)).delete(entity);
    }
}
