package com.talentpulse.serviceimpl;

import com.talentpulse.dto.SalaryStructureDTO;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.SalaryStructure;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.SalaryStructureRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SalaryStructureServiceImplTest {

    @Mock
    private SalaryStructureRepository salaryStructureRepository;

    @Mock
    private GradeStructureRepository gradeStructureRepository;

    @InjectMocks
    private SalaryStructureServiceImpl service;

    private SalaryStructure entity;
    private GradeStructure grade;

    @BeforeEach
    void setUp() {
        grade = new GradeStructure();
        grade.setGradeId(5L);

        entity = new SalaryStructure();
        entity.setStructureId(1L);
        entity.setGrade(grade);
        entity.setBasicPercent(40.0);
        entity.setHraPercent(20.0);
        entity.setAllowances("transport,medical");
        entity.setDeductionRules("pf,tax");
        entity.setEffectiveDate(LocalDate.of(2026, 1, 1));
    }

    @Test
    void getAll_returnsMappedList() {
        when(salaryStructureRepository.findAll()).thenReturn(List.of(entity));

        List<SalaryStructureDTO> result = service.getAll();

        assertEquals(1, result.size());
        SalaryStructureDTO dto = result.get(0);
        assertEquals(1L, dto.getStructureId());
        assertEquals(5L, dto.getGradeId());
        assertEquals(40.0, dto.getBasicPercent());
        assertEquals(20.0, dto.getHraPercent());
        assertEquals("transport,medical", dto.getAllowances());
        assertEquals("pf,tax", dto.getDeductionRules());
        assertEquals(LocalDate.of(2026, 1, 1), dto.getEffectiveDate());
        verify(salaryStructureRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(salaryStructureRepository.findById(1L)).thenReturn(Optional.of(entity));

        SalaryStructureDTO dto = service.getById(1L);

        assertEquals(1L, dto.getStructureId());
        assertEquals(5L, dto.getGradeId());
        verify(salaryStructureRepository).findById(1L);
    }

    @Test
    void getById_notFound_throws() {
        when(salaryStructureRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        SalaryStructureDTO input = new SalaryStructureDTO();
        input.setGradeId(5L);
        input.setBasicPercent(40.0);
        input.setHraPercent(20.0);
        input.setAllowances("transport,medical");
        input.setDeductionRules("pf,tax");
        input.setEffectiveDate(LocalDate.of(2026, 1, 1));

        when(gradeStructureRepository.findById(5L)).thenReturn(Optional.of(grade));
        when(salaryStructureRepository.save(any(SalaryStructure.class))).thenReturn(entity);

        SalaryStructureDTO result = service.create(input);

        assertEquals(1L, result.getStructureId());
        assertEquals(5L, result.getGradeId());
        assertEquals(40.0, result.getBasicPercent());
        verify(salaryStructureRepository).save(any(SalaryStructure.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        when(salaryStructureRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(salaryStructureRepository).findById(1L);
        verify(salaryStructureRepository, times(1)).delete(entity);
    }
}
