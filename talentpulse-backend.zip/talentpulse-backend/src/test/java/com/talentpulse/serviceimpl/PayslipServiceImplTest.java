package com.talentpulse.serviceimpl;

import com.talentpulse.dto.PayslipDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.PayrollRun;
import com.talentpulse.entity.Payslip;
import com.talentpulse.entity.SalaryStructure;
import com.talentpulse.enums.PayslipStatus;
import com.talentpulse.exception.BadRequestException;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.PayrollRunRepository;
import com.talentpulse.repository.PayslipRepository;
import com.talentpulse.repository.SalaryStructureRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PayslipServiceImplTest {

    @Mock
    private PayslipRepository payslipRepository;
    @Mock
    private PayrollRunRepository payrollRunRepository;
    @Mock
    private EmployeeRepository employeeRepository;
    @Mock
    private SalaryStructureRepository salaryStructureRepository;
    @Mock
    private GradeStructureRepository gradeStructureRepository;

    @InjectMocks
    private PayslipServiceImpl service;

    private Payslip entity;
    private PayrollRun payrollRun;
    private Employee employee;

    @BeforeEach
    void setUp() {
        payrollRun = new PayrollRun();
        payrollRun.setPayrollRunId(7L);
        employee = new Employee();
        employee.setEmployeeId(11L);

        entity = new Payslip();
        entity.setPayslipId(1L);
        entity.setPayrollRun(payrollRun);
        entity.setEmployee(employee);
        entity.setGrossAmount(5000.0);
        entity.setTotalDeductions(1000.0);
        entity.setNetAmount(4000.0);
        entity.setPayslipDate(LocalDate.of(2026, 6, 30));
        entity.setStatus(PayslipStatus.GENERATED);
    }

    @Test
    void getAll_returnsMappedList() {
        when(payslipRepository.findAll()).thenReturn(List.of(entity));

        List<PayslipDTO> result = service.getAll();

        assertEquals(1, result.size());
        PayslipDTO dto = result.get(0);
        assertEquals(1L, dto.getPayslipId());
        assertEquals(7L, dto.getPayrollRunId());
        assertEquals(11L, dto.getEmployeeId());
        assertEquals(4000.0, dto.getNetAmount());
        assertEquals(PayslipStatus.GENERATED, dto.getStatus());
        verify(payslipRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(payslipRepository.findById(1L)).thenReturn(Optional.of(entity));

        PayslipDTO dto = service.getById(1L);

        assertEquals(1L, dto.getPayslipId());
        verify(payslipRepository).findById(1L);
    }

    @Test
    void getById_notFound_throws() {
        when(payslipRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_withSuppliedAmounts_returnsDto() {
        PayslipDTO input = new PayslipDTO();
        input.setPayrollRunId(7L);
        input.setEmployeeId(11L);
        input.setGrossAmount(5000.0);
        input.setTotalDeductions(1000.0);
        input.setPayslipDate(LocalDate.of(2026, 6, 30));
        input.setStatus(PayslipStatus.ISSUED);

        when(payrollRunRepository.findById(7L)).thenReturn(Optional.of(payrollRun));
        when(employeeRepository.findById(11L)).thenReturn(Optional.of(employee));
        when(payslipRepository.save(any(Payslip.class))).thenReturn(entity);

        PayslipDTO result = service.create(input);

        assertEquals(1L, result.getPayslipId());
        verify(payslipRepository).save(any(Payslip.class));
    }

    @Test
    void create_computesNetAmount_ignoringClientValue() {
        PayslipDTO input = new PayslipDTO();
        input.setPayrollRunId(7L);
        input.setEmployeeId(11L);
        input.setGrossAmount(5000.0);
        input.setTotalDeductions(1000.0);
        input.setNetAmount(999999.0); // bogus - must be ignored

        when(payrollRunRepository.findById(7L)).thenReturn(Optional.of(payrollRun));
        when(employeeRepository.findById(11L)).thenReturn(Optional.of(employee));
        when(payslipRepository.save(any(Payslip.class))).thenReturn(entity);

        service.create(input);

        ArgumentCaptor<Payslip> captor = ArgumentCaptor.forClass(Payslip.class);
        verify(payslipRepository).save(captor.capture());
        assertEquals(4000.0, captor.getValue().getNetAmount()); // 5000 - 1000
    }

    @Test
    void create_autoComputesDeductionsFromSalaryStructure() {
        GradeStructure grade = new GradeStructure();
        grade.setGradeId(1L);
        Employee emp = new Employee();
        emp.setEmployeeId(11L);
        emp.setGrade(grade);
        SalaryStructure ss = new SalaryStructure();
        ss.setGrade(grade);
        ss.setDeductionRules("PF:10%;ProfTax:200");
        ss.setEffectiveDate(LocalDate.of(2026, 4, 1));

        PayslipDTO input = new PayslipDTO();
        input.setPayrollRunId(7L);
        input.setEmployeeId(11L);
        input.setGrossAmount(50000.0); // gross supplied; deductions NOT supplied

        when(payrollRunRepository.findById(7L)).thenReturn(Optional.of(payrollRun));
        when(employeeRepository.findById(11L)).thenReturn(Optional.of(emp));
        when(salaryStructureRepository.findByGrade_GradeId(1L)).thenReturn(List.of(ss));
        when(payslipRepository.save(any(Payslip.class))).thenAnswer(inv -> inv.getArgument(0));

        PayslipDTO result = service.create(input);

        // deductions = 10% of 50000 + 200 = 5200 ; net = 50000 - 5200 = 44800
        assertEquals(5200.0, result.getTotalDeductions());
        assertEquals(44800.0, result.getNetAmount());
    }

    @Test
    void create_autoComputesGrossAndDeductionsFromSalaryStructure() {
        GradeStructure grade = new GradeStructure();
        grade.setGradeId(1L);
        grade.setMinSalary(50000.0);
        Employee emp = new Employee();
        emp.setEmployeeId(11L);
        emp.setGrade(grade);
        SalaryStructure ss = new SalaryStructure();
        ss.setGrade(grade);
        ss.setBasicPercent(40.0);
        ss.setHraPercent(20.0);
        ss.setAllowances("Travel:5000;Medical:2000");
        ss.setDeductionRules("PF:10%");
        ss.setEffectiveDate(LocalDate.of(2026, 4, 1));

        PayslipDTO input = new PayslipDTO();
        input.setPayrollRunId(7L);
        input.setEmployeeId(11L);
        // neither gross nor deductions supplied -> both derived

        when(payrollRunRepository.findById(7L)).thenReturn(Optional.of(payrollRun));
        when(employeeRepository.findById(11L)).thenReturn(Optional.of(emp));
        when(salaryStructureRepository.findByGrade_GradeId(1L)).thenReturn(List.of(ss));
        when(gradeStructureRepository.findById(1L)).thenReturn(Optional.of(grade));
        when(payslipRepository.save(any(Payslip.class))).thenAnswer(inv -> inv.getArgument(0));

        PayslipDTO result = service.create(input);

        // gross = 50000*(40+20)/100 + (5000+2000) = 30000 + 7000 = 37000
        assertEquals(37000.0, result.getGrossAmount());
        // deductions = 10% of 37000 = 3700 ; net = 37000 - 3700 = 33300
        assertEquals(3700.0, result.getTotalDeductions());
        assertEquals(33300.0, result.getNetAmount());
    }

    @Test
    void create_deductionsExceedGross_throwsBadRequest() {
        PayslipDTO input = new PayslipDTO();
        input.setGrossAmount(1000.0);
        input.setTotalDeductions(2000.0);

        assertThrows(BadRequestException.class, () -> service.create(input));
    }

    @Test
    void create_negativeGross_throwsBadRequest() {
        PayslipDTO input = new PayslipDTO();
        input.setGrossAmount(-1.0);
        input.setTotalDeductions(0.0);

        assertThrows(BadRequestException.class, () -> service.create(input));
    }

    @Test
    void delete_deletesFoundEntity() {
        when(payslipRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(payslipRepository).findById(1L);
        verify(payslipRepository, times(1)).delete(entity);
    }
}
