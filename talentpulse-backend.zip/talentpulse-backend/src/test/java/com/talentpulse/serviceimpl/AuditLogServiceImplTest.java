package com.talentpulse.serviceimpl;

import com.talentpulse.dto.AuditLogDTO;
import com.talentpulse.entity.AuditLog;
import com.talentpulse.entity.User;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AuditLogRepository;
import com.talentpulse.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AuditLogServiceImplTest {

    @Mock
    private AuditLogRepository auditLogRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private AuditLogServiceImpl auditLogService;

    private User sampleUser() {
        User user = new User();
        user.setUserId(100L);
        return user;
    }

    private AuditLog sampleEntity() {
        AuditLog log = new AuditLog();
        log.setAuditId(1L);
        log.setUser(sampleUser());
        log.setAction("LOGIN");
        log.setModule("AUTH");
        log.setTimestamp(LocalDateTime.of(2026, 6, 16, 10, 30));
        return log;
    }

    private AuditLogDTO sampleDto() {
        AuditLogDTO dto = new AuditLogDTO();
        dto.setAuditId(1L);
        dto.setUserId(100L);
        dto.setAction("LOGIN");
        dto.setModule("AUTH");
        dto.setTimestamp(LocalDateTime.of(2026, 6, 16, 10, 30));
        return dto;
    }

    @Test
    void getAll_returnsMappedNonEmptyList() {
        when(auditLogRepository.findAll()).thenReturn(List.of(sampleEntity()));

        List<AuditLogDTO> result = auditLogService.getAll();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getAuditId());
        assertEquals("LOGIN", result.get(0).getAction());
        assertEquals("AUTH", result.get(0).getModule());
        verify(auditLogRepository).findAll();
    }

    @Test
    void getById_returnsDtoWhenPresent() {
        when(auditLogRepository.findById(1L)).thenReturn(Optional.of(sampleEntity()));

        AuditLogDTO result = auditLogService.getById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getAuditId());
        assertEquals(100L, result.getUserId());
        assertEquals(LocalDateTime.of(2026, 6, 16, 10, 30), result.getTimestamp());
        verify(auditLogRepository).findById(1L);
    }

    @Test
    void getById_throwsWhenNotFound() {
        when(auditLogRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> auditLogService.getById(99L));
    }

    @Test
    void create_returnsDto() {
        AuditLogDTO input = sampleDto();
        when(userRepository.findById(100L)).thenReturn(Optional.of(sampleUser()));
        when(auditLogRepository.save(any(AuditLog.class))).thenReturn(sampleEntity());

        AuditLogDTO result = auditLogService.create(input);

        assertNotNull(result);
        assertEquals(1L, result.getAuditId());
        assertEquals("LOGIN", result.getAction());
        verify(auditLogRepository).save(any(AuditLog.class));
    }

    @Test
    void delete_invokesRepositoryDeleteWhenFound() {
        AuditLog entity = sampleEntity();
        when(auditLogRepository.findById(1L)).thenReturn(Optional.of(entity));

        auditLogService.delete(1L);

        verify(auditLogRepository, times(1)).delete(entity);
    }
}
