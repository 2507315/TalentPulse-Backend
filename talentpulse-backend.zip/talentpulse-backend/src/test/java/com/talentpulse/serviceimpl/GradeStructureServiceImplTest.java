package com.talentpulse.serviceimpl;

import com.talentpulse.dto.GradeStructureDTO;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.GradeStructureRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GradeStructureServiceImplTest {

    @Mock
    private GradeStructureRepository gradeStructureRepository;

    @InjectMocks
    private GradeStructureServiceImpl gradeStructureService;

    private GradeStructure entity;

    @BeforeEach
    void setUp() {
        entity = new GradeStructure();
        entity.setGradeId(1L);
        entity.setGradeName("Grade A");
        entity.setBand("B3");
        entity.setMinSalary(50000.0);
        entity.setMaxSalary(90000.0);
        entity.setLeaveEntitlement(24);
    }

    private GradeStructureDTO sampleDto() {
        GradeStructureDTO dto = new GradeStructureDTO();
        dto.setGradeName("Grade A");
        dto.setBand("B3");
        dto.setMinSalary(50000.0);
        dto.setMaxSalary(90000.0);
        dto.setLeaveEntitlement(24);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(gradeStructureRepository.findAll()).thenReturn(List.of(entity));

        List<GradeStructureDTO> result = gradeStructureService.getAll();

        assertEquals(1, result.size());
        GradeStructureDTO dto = result.get(0);
        assertEquals(1L, dto.getGradeId());
        assertEquals("Grade A", dto.getGradeName());
        assertEquals("B3", dto.getBand());
        assertEquals(50000.0, dto.getMinSalary());
        assertEquals(24, dto.getLeaveEntitlement());
        verify(gradeStructureRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(gradeStructureRepository.findById(1L)).thenReturn(Optional.of(entity));

        GradeStructureDTO dto = gradeStructureService.getById(1L);

        assertNotNull(dto);
        assertEquals(1L, dto.getGradeId());
        assertEquals("Grade A", dto.getGradeName());
        assertEquals(90000.0, dto.getMaxSalary());
        verify(gradeStructureRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(gradeStructureRepository.findById(404L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> gradeStructureService.getById(404L));
        verify(gradeStructureRepository).findById(404L);
    }

    @Test
    void create_returnsDto() {
        when(gradeStructureRepository.save(any(GradeStructure.class))).thenReturn(entity);

        GradeStructureDTO result = gradeStructureService.create(sampleDto());

        assertNotNull(result);
        assertEquals(1L, result.getGradeId());
        assertEquals("Grade A", result.getGradeName());
        assertEquals(24, result.getLeaveEntitlement());
        verify(gradeStructureRepository).save(any(GradeStructure.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        when(gradeStructureRepository.findById(1L)).thenReturn(Optional.of(entity));

        gradeStructureService.delete(1L);

        verify(gradeStructureRepository).findById(1L);
        verify(gradeStructureRepository, times(1)).delete(entity);
    }
}
