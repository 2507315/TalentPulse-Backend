package com.talentpulse.serviceimpl;

import com.talentpulse.dto.DepartmentDTO;
import com.talentpulse.entity.Department;
import com.talentpulse.entity.User;
import com.talentpulse.enums.ActiveStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.DepartmentRepository;
import com.talentpulse.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DepartmentServiceImplTest {

    @Mock
    private DepartmentRepository departmentRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private DepartmentServiceImpl departmentService;

    private Department entity;

    @BeforeEach
    void setUp() {
        User hrbpUser = new User();
        hrbpUser.setUserId(55L);

        entity = new Department();
        entity.setDepartmentId(1L);
        entity.setDepartmentName("Engineering");
        entity.setCostCentreCode("CC-100");
        entity.setHrbpUser(hrbpUser);
        entity.setStatus(ActiveStatus.ACTIVE);
    }

    private DepartmentDTO sampleDto() {
        DepartmentDTO dto = new DepartmentDTO();
        dto.setDepartmentName("Engineering");
        dto.setCostCentreCode("CC-100");
        dto.setHrbpUserId(55L);
        dto.setStatus(ActiveStatus.ACTIVE);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(departmentRepository.findAll()).thenReturn(List.of(entity));

        List<DepartmentDTO> result = departmentService.getAll();

        assertEquals(1, result.size());
        DepartmentDTO dto = result.get(0);
        assertEquals(1L, dto.getDepartmentId());
        assertEquals("Engineering", dto.getDepartmentName());
        assertEquals("CC-100", dto.getCostCentreCode());
        assertEquals(55L, dto.getHrbpUserId());
        assertEquals(ActiveStatus.ACTIVE, dto.getStatus());
        verify(departmentRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(entity));

        DepartmentDTO dto = departmentService.getById(1L);

        assertNotNull(dto);
        assertEquals(1L, dto.getDepartmentId());
        assertEquals("Engineering", dto.getDepartmentName());
        assertEquals(55L, dto.getHrbpUserId());
        verify(departmentRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(departmentRepository.findById(404L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> departmentService.getById(404L));
        verify(departmentRepository).findById(404L);
    }

    @Test
    void create_returnsDto() {
        when(userRepository.findById(55L)).thenReturn(Optional.of(entity.getHrbpUser()));
        when(departmentRepository.save(any(Department.class))).thenReturn(entity);

        DepartmentDTO result = departmentService.create(sampleDto());

        assertNotNull(result);
        assertEquals(1L, result.getDepartmentId());
        assertEquals("Engineering", result.getDepartmentName());
        assertEquals(55L, result.getHrbpUserId());
        assertEquals(ActiveStatus.ACTIVE, result.getStatus());
        verify(departmentRepository).save(any(Department.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(entity));

        departmentService.delete(1L);

        verify(departmentRepository).findById(1L);
        verify(departmentRepository, times(1)).delete(entity);
    }
}
