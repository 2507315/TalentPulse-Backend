package com.talentpulse.serviceimpl;

import com.talentpulse.dto.InterviewRoundDTO;
import com.talentpulse.entity.Candidate;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.InterviewRound;
import com.talentpulse.entity.JobRequisition;
import com.talentpulse.enums.InterviewOutcome;
import com.talentpulse.enums.RoundType;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.CandidateRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.InterviewRoundRepository;
import com.talentpulse.repository.JobRequisitionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class InterviewRoundServiceImplTest {

    @Mock
    private InterviewRoundRepository interviewRoundRepository;

    @Mock
    private CandidateRepository candidateRepository;

    @Mock
    private JobRequisitionRepository jobRequisitionRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private InterviewRoundServiceImpl service;

    private InterviewRound entity;
    private Candidate candidate;
    private JobRequisition requisition;
    private Employee interviewer;

    @BeforeEach
    void setUp() {
        candidate = new Candidate();
        candidate.setCandidateId(100L);

        requisition = new JobRequisition();
        requisition.setRequisitionId(200L);

        interviewer = new Employee();
        interviewer.setEmployeeId(300L);

        entity = new InterviewRound();
        entity.setRoundId(1L);
        entity.setCandidate(candidate);
        entity.setRequisition(requisition);
        entity.setRoundType(RoundType.TECHNICAL);
        entity.setInterviewer(interviewer);
        entity.setScheduledDate(LocalDate.of(2026, 6, 20));
        entity.setOutcome(InterviewOutcome.PASS);
        entity.setFeedback("Strong technical skills");
    }

    @Test
    void getAll_returnsMappedList() {
        when(interviewRoundRepository.findAll()).thenReturn(List.of(entity));

        List<InterviewRoundDTO> result = service.getAll();

        assertEquals(1, result.size());
        InterviewRoundDTO dto = result.get(0);
        assertEquals(1L, dto.getRoundId());
        assertEquals(100L, dto.getCandidateId());
        assertEquals(200L, dto.getRequisitionId());
        assertEquals(RoundType.TECHNICAL, dto.getRoundType());
        assertEquals(300L, dto.getInterviewerId());
        assertEquals(LocalDate.of(2026, 6, 20), dto.getScheduledDate());
        assertEquals(InterviewOutcome.PASS, dto.getOutcome());
        assertEquals("Strong technical skills", dto.getFeedback());
        verify(interviewRoundRepository).findAll();
    }

    @Test
    void getById_found_returnsMappedDto() {
        when(interviewRoundRepository.findById(1L)).thenReturn(Optional.of(entity));

        InterviewRoundDTO dto = service.getById(1L);

        assertNotNull(dto);
        assertEquals(1L, dto.getRoundId());
        assertEquals(RoundType.TECHNICAL, dto.getRoundType());
        assertEquals(InterviewOutcome.PASS, dto.getOutcome());
        verify(interviewRoundRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(interviewRoundRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
        verify(interviewRoundRepository).findById(99L);
    }

    @Test
    void create_returnsSavedDto() {
        InterviewRoundDTO input = new InterviewRoundDTO();
        input.setCandidateId(100L);
        input.setRequisitionId(200L);
        input.setRoundType(RoundType.HR);
        input.setInterviewerId(300L);
        input.setScheduledDate(LocalDate.of(2026, 6, 20));
        input.setOutcome(InterviewOutcome.PENDING);
        input.setFeedback("Pending review");

        when(candidateRepository.findById(100L)).thenReturn(Optional.of(candidate));
        when(jobRequisitionRepository.findById(200L)).thenReturn(Optional.of(requisition));
        when(employeeRepository.findById(300L)).thenReturn(Optional.of(interviewer));
        when(interviewRoundRepository.save(any(InterviewRound.class))).thenReturn(entity);

        InterviewRoundDTO result = service.create(input);

        assertNotNull(result);
        assertEquals(1L, result.getRoundId());
        assertEquals(InterviewOutcome.PASS, result.getOutcome());

        ArgumentCaptor<InterviewRound> captor = ArgumentCaptor.forClass(InterviewRound.class);
        verify(interviewRoundRepository).save(captor.capture());
        assertEquals(RoundType.HR, captor.getValue().getRoundType());
        assertEquals(InterviewOutcome.PENDING, captor.getValue().getOutcome());
        assertEquals(100L, captor.getValue().getCandidate().getCandidateId());
    }

    @Test
    void delete_found_deletesEntity() {
        when(interviewRoundRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(interviewRoundRepository).findById(1L);
        verify(interviewRoundRepository).delete(entity);
    }
}
