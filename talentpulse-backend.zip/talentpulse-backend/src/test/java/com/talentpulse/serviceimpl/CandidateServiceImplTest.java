package com.talentpulse.serviceimpl;

import com.talentpulse.dto.CandidateDTO;
import com.talentpulse.entity.Candidate;
import com.talentpulse.enums.CandidateStatus;
import com.talentpulse.enums.SourceChannel;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.CandidateRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CandidateServiceImplTest {

    @Mock
    private CandidateRepository candidateRepository;

    @InjectMocks
    private CandidateServiceImpl service;

    private Candidate entity;

    @BeforeEach
    void setUp() {
        entity = new Candidate();
        entity.setCandidateId(1L);
        entity.setName("Jane Doe");
        entity.setEmail("jane.doe@example.com");
        entity.setPhone("+1-555-0100");
        entity.setResumeRef("resume-123.pdf");
        entity.setSourceChannel(SourceChannel.REFERRAL);
        entity.setStatus(CandidateStatus.SHORTLISTED);
    }

    @Test
    void getAll_returnsMappedList() {
        when(candidateRepository.findAll()).thenReturn(List.of(entity));

        List<CandidateDTO> result = service.getAll();

        assertEquals(1, result.size());
        CandidateDTO dto = result.get(0);
        assertEquals(1L, dto.getCandidateId());
        assertEquals("Jane Doe", dto.getName());
        assertEquals("jane.doe@example.com", dto.getEmail());
        assertEquals("+1-555-0100", dto.getPhone());
        assertEquals("resume-123.pdf", dto.getResumeRef());
        assertEquals(SourceChannel.REFERRAL, dto.getSourceChannel());
        assertEquals(CandidateStatus.SHORTLISTED, dto.getStatus());
        verify(candidateRepository).findAll();
    }

    @Test
    void getById_found_returnsMappedDto() {
        when(candidateRepository.findById(1L)).thenReturn(Optional.of(entity));

        CandidateDTO dto = service.getById(1L);

        assertNotNull(dto);
        assertEquals(1L, dto.getCandidateId());
        assertEquals("Jane Doe", dto.getName());
        assertEquals(CandidateStatus.SHORTLISTED, dto.getStatus());
        verify(candidateRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(candidateRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
        verify(candidateRepository).findById(99L);
    }

    @Test
    void create_returnsSavedDto() {
        CandidateDTO input = new CandidateDTO();
        input.setName("Jane Doe");
        input.setEmail("jane.doe@example.com");
        input.setPhone("+1-555-0100");
        input.setResumeRef("resume-123.pdf");
        input.setSourceChannel(SourceChannel.PORTAL);
        input.setStatus(CandidateStatus.APPLIED);

        when(candidateRepository.save(any(Candidate.class))).thenReturn(entity);

        CandidateDTO result = service.create(input);

        assertNotNull(result);
        assertEquals(1L, result.getCandidateId());
        assertEquals(CandidateStatus.SHORTLISTED, result.getStatus());

        ArgumentCaptor<Candidate> captor = ArgumentCaptor.forClass(Candidate.class);
        verify(candidateRepository).save(captor.capture());
        assertEquals("Jane Doe", captor.getValue().getName());
        assertEquals(SourceChannel.PORTAL, captor.getValue().getSourceChannel());
        assertEquals(CandidateStatus.APPLIED, captor.getValue().getStatus());
    }

    @Test
    void delete_found_deletesEntity() {
        when(candidateRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(candidateRepository).findById(1L);
        verify(candidateRepository).delete(entity);
    }
}
