package com.talentpulse.serviceimpl;

import com.talentpulse.dto.LeaveTypeDTO;
import com.talentpulse.entity.LeaveType;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.LeaveTypeRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LeaveTypeServiceImplTest {

    @Mock
    private LeaveTypeRepository leaveTypeRepository;

    @InjectMocks
    private LeaveTypeServiceImpl service;

    private LeaveType buildEntity() {
        LeaveType e = new LeaveType();
        e.setLeaveTypeId(1L);
        e.setName("CasualLeave");
        e.setAnnualQuota(12);
        e.setCarryForwardAllowed(Boolean.TRUE);
        e.setRequiresApproval(Boolean.TRUE);
        return e;
    }

    private LeaveTypeDTO buildDto() {
        LeaveTypeDTO dto = new LeaveTypeDTO();
        dto.setName("CasualLeave");
        dto.setAnnualQuota(12);
        dto.setCarryForwardAllowed(Boolean.TRUE);
        dto.setRequiresApproval(Boolean.TRUE);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(leaveTypeRepository.findAll()).thenReturn(List.of(buildEntity()));

        List<LeaveTypeDTO> result = service.getAll();

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getLeaveTypeId());
        assertEquals("CasualLeave", result.get(0).getName());
        assertEquals(12, result.get(0).getAnnualQuota());
        verify(leaveTypeRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(leaveTypeRepository.findById(1L)).thenReturn(Optional.of(buildEntity()));

        LeaveTypeDTO result = service.getById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getLeaveTypeId());
        assertEquals("CasualLeave", result.getName());
        assertEquals(Boolean.TRUE, result.getCarryForwardAllowed());
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(leaveTypeRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        when(leaveTypeRepository.save(any(LeaveType.class))).thenReturn(buildEntity());

        LeaveTypeDTO result = service.create(buildDto());

        assertNotNull(result);
        assertEquals(1L, result.getLeaveTypeId());
        assertEquals("CasualLeave", result.getName());
        verify(leaveTypeRepository).save(any(LeaveType.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        LeaveType entity = buildEntity();
        when(leaveTypeRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(leaveTypeRepository).delete(entity);
    }
}
