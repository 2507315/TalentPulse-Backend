package com.talentpulse.serviceimpl;

import com.talentpulse.dto.PayrollRunDTO;
import com.talentpulse.dto.PayslipDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.PayrollRun;
import com.talentpulse.entity.Payslip;
import com.talentpulse.entity.User;
import com.talentpulse.enums.PayrollStatus;
import com.talentpulse.exception.BadRequestException;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.PayrollRunRepository;
import com.talentpulse.repository.PayslipRepository;
import com.talentpulse.repository.UserRepository;
import com.talentpulse.service.PayslipService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PayrollRunServiceImplTest {

    @Mock
    private PayrollRunRepository payrollRunRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private PayslipRepository payslipRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private PayslipService payslipService;

    @InjectMocks
    private PayrollRunServiceImpl service;

    private PayrollRun entity;
    private User processedByUser;

    @BeforeEach
    void setUp() {
        processedByUser = new User();
        processedByUser.setUserId(10L);

        entity = new PayrollRun();
        entity.setPayrollRunId(1L);
        entity.setMonth(6);
        entity.setYear(2026);
        entity.setProcessedByUser(processedByUser);
        entity.setProcessedDate(LocalDate.of(2026, 6, 30));
        entity.setTotalGross(100000.0);
        entity.setTotalDeductions(20000.0);
        entity.setTotalNet(80000.0);
        entity.setStatus(PayrollStatus.PROCESSED);
    }

    @Test
    void getAll_returnsMappedList() {
        when(payrollRunRepository.findAll()).thenReturn(List.of(entity));

        List<PayrollRunDTO> result = service.getAll();

        assertEquals(1, result.size());
        PayrollRunDTO dto = result.get(0);
        assertEquals(1L, dto.getPayrollRunId());
        assertEquals(6, dto.getMonth());
        assertEquals(2026, dto.getYear());
        assertEquals(10L, dto.getProcessedBy());
        assertEquals(LocalDate.of(2026, 6, 30), dto.getProcessedDate());
        assertEquals(100000.0, dto.getTotalGross());
        assertEquals(20000.0, dto.getTotalDeductions());
        assertEquals(80000.0, dto.getTotalNet());
        assertEquals(PayrollStatus.PROCESSED, dto.getStatus());
        verify(payrollRunRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(payrollRunRepository.findById(1L)).thenReturn(Optional.of(entity));

        PayrollRunDTO dto = service.getById(1L);

        assertEquals(1L, dto.getPayrollRunId());
        assertEquals(PayrollStatus.PROCESSED, dto.getStatus());
        verify(payrollRunRepository).findById(1L);
    }

    @Test
    void getById_notFound_throws() {
        when(payrollRunRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_defaultsToDraftAndZeroTotals() {
        PayrollRunDTO input = new PayrollRunDTO();
        input.setMonth(6);
        input.setYear(2026);
        input.setProcessedBy(10L);
        input.setProcessedDate(LocalDate.of(2026, 6, 30));
        input.setStatus(null); // no status supplied -> should default to DRAFT

        when(userRepository.findById(10L)).thenReturn(Optional.of(processedByUser));
        when(payrollRunRepository.save(any(PayrollRun.class))).thenAnswer(inv -> inv.getArgument(0));

        PayrollRunDTO result = service.create(input);

        assertEquals(PayrollStatus.DRAFT, result.getStatus());
        assertEquals(0.0, result.getTotalGross());
        assertEquals(0.0, result.getTotalDeductions());
        assertEquals(0.0, result.getTotalNet());
        verify(payrollRunRepository).save(any(PayrollRun.class));
    }

    @Test
    void update_validForwardTransition_recalculatesTotalsFromPayslips() {
        // existing run is PROCESSED; PROCESSED -> APPROVED is a legal forward step
        PayrollRunDTO dto = new PayrollRunDTO();
        dto.setStatus(PayrollStatus.APPROVED);

        Payslip p1 = new Payslip();
        p1.setGrossAmount(5000.0);
        p1.setTotalDeductions(1000.0);
        p1.setNetAmount(4000.0);
        Payslip p2 = new Payslip();
        p2.setGrossAmount(3000.0);
        p2.setTotalDeductions(500.0);
        p2.setNetAmount(2500.0);

        when(payrollRunRepository.findById(1L)).thenReturn(Optional.of(entity));
        when(payslipRepository.findByPayrollRun_PayrollRunId(1L)).thenReturn(List.of(p1, p2));
        when(payrollRunRepository.save(any(PayrollRun.class))).thenAnswer(inv -> inv.getArgument(0));

        PayrollRunDTO result = service.update(1L, dto);

        assertEquals(PayrollStatus.APPROVED, result.getStatus());
        assertEquals(8000.0, result.getTotalGross());      // 5000 + 3000
        assertEquals(1500.0, result.getTotalDeductions()); // 1000 + 500
        assertEquals(6500.0, result.getTotalNet());        // 4000 + 2500
    }

    @Test
    void update_invalidTransition_throwsBadRequest() {
        // PROCESSED -> DISBURSED skips APPROVED, which is illegal
        when(payrollRunRepository.findById(1L)).thenReturn(Optional.of(entity));
        PayrollRunDTO dto = new PayrollRunDTO();
        dto.setStatus(PayrollStatus.DISBURSED);

        assertThrows(BadRequestException.class, () -> service.update(1L, dto));
    }

    @Test
    void update_disbursedRun_throwsBadRequest() {
        entity.setStatus(PayrollStatus.DISBURSED); // already final
        when(payrollRunRepository.findById(1L)).thenReturn(Optional.of(entity));
        PayrollRunDTO dto = new PayrollRunDTO();
        dto.setStatus(PayrollStatus.DISBURSED);

        assertThrows(BadRequestException.class, () -> service.update(1L, dto));
    }

    @Test
    void generatePayslips_createsForEmployeesAndRollsUpTotals() {
        entity.setStatus(PayrollStatus.DRAFT); // payslips can only be generated for a DRAFT run

        Employee e1 = new Employee();
        e1.setEmployeeId(11L);
        Employee e2 = new Employee();
        e2.setEmployeeId(12L);

        Payslip p1 = new Payslip();
        p1.setGrossAmount(30000.0);
        p1.setTotalDeductions(3800.0);
        p1.setNetAmount(26200.0);
        Payslip p2 = new Payslip();
        p2.setGrossAmount(50000.0);
        p2.setTotalDeductions(5200.0);
        p2.setNetAmount(44800.0);

        when(payrollRunRepository.findById(1L)).thenReturn(Optional.of(entity));
        when(employeeRepository.findAll()).thenReturn(List.of(e1, e2));
        // 1st call: existing payslips (none); 2nd call: recompute totals
        when(payslipRepository.findByPayrollRun_PayrollRunId(1L))
                .thenReturn(List.of())
                .thenReturn(List.of(p1, p2));
        when(payrollRunRepository.save(any(PayrollRun.class))).thenAnswer(inv -> inv.getArgument(0));

        PayrollRunDTO result = service.generatePayslips(1L);

        verify(payslipService, times(2)).create(any(PayslipDTO.class)); // one per employee
        assertEquals(80000.0, result.getTotalGross());      // 30000 + 50000
        assertEquals(9000.0, result.getTotalDeductions());  // 3800 + 5200
        assertEquals(71000.0, result.getTotalNet());        // 26200 + 44800
    }

    @Test
    void generatePayslips_nonDraftRun_throwsBadRequest() {
        entity.setStatus(PayrollStatus.APPROVED);
        when(payrollRunRepository.findById(1L)).thenReturn(Optional.of(entity));

        assertThrows(BadRequestException.class, () -> service.generatePayslips(1L));
    }

    @Test
    void delete_deletesFoundEntity() {
        when(payrollRunRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(payrollRunRepository).findById(1L);
        verify(payrollRunRepository, times(1)).delete(entity);
    }
}
