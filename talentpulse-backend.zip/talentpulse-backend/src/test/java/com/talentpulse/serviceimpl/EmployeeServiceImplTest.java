package com.talentpulse.serviceimpl;

import com.talentpulse.dto.EmployeeDTO;
import com.talentpulse.entity.Department;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.enums.EmployeeStatus;
import com.talentpulse.enums.EmploymentType;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.DepartmentRepository;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.GradeStructureRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EmployeeServiceImplTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private GradeStructureRepository gradeStructureRepository;

    @Mock
    private DepartmentRepository departmentRepository;

    @InjectMocks
    private EmployeeServiceImpl employeeService;

    private Employee entity;

    @BeforeEach
    void setUp() {
        GradeStructure grade = new GradeStructure();
        grade.setGradeId(10L);

        Department department = new Department();
        department.setDepartmentId(2L);

        Employee manager = new Employee();
        manager.setEmployeeId(99L);

        entity = new Employee();
        entity.setEmployeeId(1L);
        entity.setName("Jane Doe");
        entity.setDateOfBirth(LocalDate.of(1990, 5, 20));
        entity.setGender("Female");
        entity.setDesignation("Senior Engineer");
        entity.setGrade(grade);
        entity.setDepartment(department);
        entity.setReportingManager(manager);
        entity.setJoiningDate(LocalDate.of(2015, 1, 15));
        entity.setEmploymentType(EmploymentType.PERMANENT);
        entity.setStatus(EmployeeStatus.ACTIVE);
    }

    private EmployeeDTO sampleDto() {
        EmployeeDTO dto = new EmployeeDTO();
        dto.setName("Jane Doe");
        dto.setDateOfBirth(LocalDate.of(1990, 5, 20));
        dto.setGender("Female");
        dto.setDesignation("Senior Engineer");
        dto.setGradeId(10L);
        dto.setDepartmentId(2L);
        dto.setReportingManagerId(99L);
        dto.setJoiningDate(LocalDate.of(2015, 1, 15));
        dto.setEmploymentType(EmploymentType.PERMANENT);
        dto.setStatus(EmployeeStatus.ACTIVE);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(employeeRepository.findAll()).thenReturn(List.of(entity));

        List<EmployeeDTO> result = employeeService.getAll();

        assertEquals(1, result.size());
        EmployeeDTO dto = result.get(0);
        assertEquals(1L, dto.getEmployeeId());
        assertEquals("Jane Doe", dto.getName());
        assertEquals(10L, dto.getGradeId());
        assertEquals(2L, dto.getDepartmentId());
        assertEquals(99L, dto.getReportingManagerId());
        assertEquals(EmploymentType.PERMANENT, dto.getEmploymentType());
        assertEquals(EmployeeStatus.ACTIVE, dto.getStatus());
        verify(employeeRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(entity));

        EmployeeDTO dto = employeeService.getById(1L);

        assertNotNull(dto);
        assertEquals(1L, dto.getEmployeeId());
        assertEquals("Jane Doe", dto.getName());
        assertEquals(10L, dto.getGradeId());
        assertEquals(2L, dto.getDepartmentId());
        assertEquals(99L, dto.getReportingManagerId());
        assertEquals(LocalDate.of(1990, 5, 20), dto.getDateOfBirth());
        assertEquals(LocalDate.of(2015, 1, 15), dto.getJoiningDate());
        verify(employeeRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(employeeRepository.findById(404L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> employeeService.getById(404L));
        verify(employeeRepository).findById(404L);
    }

    @Test
    void create_returnsDto() {
        when(gradeStructureRepository.findById(10L)).thenReturn(Optional.of(entity.getGrade()));
        when(departmentRepository.findById(2L)).thenReturn(Optional.of(entity.getDepartment()));
        when(employeeRepository.findById(99L)).thenReturn(Optional.of(entity.getReportingManager()));
        when(employeeRepository.save(any(Employee.class))).thenReturn(entity);

        EmployeeDTO result = employeeService.create(sampleDto());

        assertNotNull(result);
        assertEquals(1L, result.getEmployeeId());
        assertEquals("Jane Doe", result.getName());
        assertEquals(10L, result.getGradeId());
        assertEquals(2L, result.getDepartmentId());
        assertEquals(99L, result.getReportingManagerId());
        assertEquals(EmployeeStatus.ACTIVE, result.getStatus());
        verify(employeeRepository).save(any(Employee.class));
    }

    @Test
    void delete_deletesFoundEntity() {
        when(employeeRepository.findById(1L)).thenReturn(Optional.of(entity));

        employeeService.delete(1L);

        verify(employeeRepository).findById(1L);
        verify(employeeRepository, times(1)).delete(entity);
    }
}
