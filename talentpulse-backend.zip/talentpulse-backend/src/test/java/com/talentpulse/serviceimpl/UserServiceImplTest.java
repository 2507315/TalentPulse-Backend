package com.talentpulse.serviceimpl;

import com.talentpulse.dto.UserDTO;
import com.talentpulse.entity.Employee;
import com.talentpulse.entity.User;
import com.talentpulse.enums.Role;
import com.talentpulse.enums.UserStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.EmployeeRepository;
import com.talentpulse.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserServiceImpl userService;

    private Employee sampleEmployee() {
        Employee employee = new Employee();
        employee.setEmployeeId(100L);
        return employee;
    }

    private User sampleEntity() {
        User user = new User();
        user.setUserId(1L);
        user.setEmployee(sampleEmployee());
        user.setName("Alice Example");
        user.setRole(Role.EMPLOYEE);
        user.setEmail("alice@example.com");
        user.setPhone("555-0100");
        user.setPassword("encoded-secret");
        user.setStatus(UserStatus.ACTIVE);
        return user;
    }

    private UserDTO sampleDto() {
        UserDTO dto = new UserDTO();
        dto.setUserId(1L);
        dto.setEmployeeId(100L);
        dto.setName("Alice Example");
        dto.setRole(Role.EMPLOYEE);
        dto.setEmail("alice@example.com");
        dto.setPhone("555-0100");
        dto.setPassword("plain-secret");
        dto.setStatus(UserStatus.ACTIVE);
        return dto;
    }

    @Test
    void getAll_returnsMappedNonEmptyList() {
        when(userRepository.findAll()).thenReturn(List.of(sampleEntity()));

        List<UserDTO> result = userService.getAll();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getUserId());
        assertEquals("alice@example.com", result.get(0).getEmail());
        assertEquals(Role.EMPLOYEE, result.get(0).getRole());
        verify(userRepository).findAll();
    }

    @Test
    void getById_returnsDtoWhenPresent() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleEntity()));

        UserDTO result = userService.getById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals("Alice Example", result.getName());
        assertEquals(UserStatus.ACTIVE, result.getStatus());
        verify(userRepository).findById(1L);
    }

    @Test
    void getById_throwsWhenNotFound() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> userService.getById(99L));
    }

    @Test
    void create_returnsDto() {
        UserDTO input = sampleDto();
        // password encoding is exercised but we never assert on the encoded value
        lenient().when(passwordEncoder.encode(any())).thenReturn("encoded-secret");
        lenient().when(employeeRepository.findById(100L)).thenReturn(Optional.of(sampleEmployee()));
        when(userRepository.save(any(User.class))).thenReturn(sampleEntity());

        UserDTO result = userService.create(input);

        assertNotNull(result);
        assertEquals(1L, result.getUserId());
        assertEquals("alice@example.com", result.getEmail());
        verify(userRepository).save(any(User.class));
    }

    @Test
    void delete_invokesRepositoryDeleteWhenFound() {
        User entity = sampleEntity();
        when(userRepository.findById(1L)).thenReturn(Optional.of(entity));

        userService.delete(1L);

        verify(userRepository, times(1)).delete(entity);
    }
}
