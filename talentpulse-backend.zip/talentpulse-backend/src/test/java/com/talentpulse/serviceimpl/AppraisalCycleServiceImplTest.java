package com.talentpulse.serviceimpl;

import com.talentpulse.dto.AppraisalCycleDTO;
import com.talentpulse.entity.AppraisalCycle;
import com.talentpulse.enums.AppraisalType;
import com.talentpulse.enums.CycleStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.AppraisalCycleRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AppraisalCycleServiceImplTest {

    @Mock
    private AppraisalCycleRepository appraisalCycleRepository;

    @InjectMocks
    private AppraisalCycleServiceImpl service;

    private AppraisalCycle buildEntity(Long id) {
        AppraisalCycle e = new AppraisalCycle();
        e.setCycleId(id);
        e.setName("FY26 Annual");
        e.setYear(2026);
        e.setType(AppraisalType.ANNUAL);
        e.setGoalSettingStart(LocalDate.of(2026, 1, 1));
        e.setGoalSettingEnd(LocalDate.of(2026, 2, 1));
        e.setReviewStart(LocalDate.of(2026, 11, 1));
        e.setReviewEnd(LocalDate.of(2026, 12, 1));
        e.setStatus(CycleStatus.ACTIVE);
        return e;
    }

    private AppraisalCycleDTO buildDto() {
        AppraisalCycleDTO dto = new AppraisalCycleDTO();
        dto.setName("FY26 Annual");
        dto.setYear(2026);
        dto.setType(AppraisalType.ANNUAL);
        dto.setGoalSettingStart(LocalDate.of(2026, 1, 1));
        dto.setGoalSettingEnd(LocalDate.of(2026, 2, 1));
        dto.setReviewStart(LocalDate.of(2026, 11, 1));
        dto.setReviewEnd(LocalDate.of(2026, 12, 1));
        dto.setStatus(CycleStatus.ACTIVE);
        return dto;
    }

    @Test
    void getAll_returnsMappedList() {
        when(appraisalCycleRepository.findAll()).thenReturn(List.of(buildEntity(1L), buildEntity(2L)));

        List<AppraisalCycleDTO> result = service.getAll();

        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getCycleId());
        assertEquals("FY26 Annual", result.get(0).getName());
        assertEquals(AppraisalType.ANNUAL, result.get(0).getType());
        assertEquals(CycleStatus.ACTIVE, result.get(0).getStatus());
        assertEquals(2L, result.get(1).getCycleId());
        verify(appraisalCycleRepository).findAll();
    }

    @Test
    void getById_found_returnsDto() {
        when(appraisalCycleRepository.findById(1L)).thenReturn(Optional.of(buildEntity(1L)));

        AppraisalCycleDTO result = service.getById(1L);

        assertEquals(1L, result.getCycleId());
        assertEquals(2026, result.getYear());
        assertEquals(LocalDate.of(2026, 1, 1), result.getGoalSettingStart());
        assertEquals(LocalDate.of(2026, 12, 1), result.getReviewEnd());
        verify(appraisalCycleRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(appraisalCycleRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
    }

    @Test
    void create_returnsDto() {
        AppraisalCycleDTO dto = buildDto();
        when(appraisalCycleRepository.save(any(AppraisalCycle.class))).thenReturn(buildEntity(10L));

        AppraisalCycleDTO result = service.create(dto);

        assertEquals(10L, result.getCycleId());
        assertEquals("FY26 Annual", result.getName());
        assertEquals(AppraisalType.ANNUAL, result.getType());
        verify(appraisalCycleRepository).save(any(AppraisalCycle.class));
    }

    @Test
    void delete_verifiesRepositoryDelete() {
        AppraisalCycle entity = buildEntity(5L);
        when(appraisalCycleRepository.findById(5L)).thenReturn(Optional.of(entity));

        service.delete(5L);

        verify(appraisalCycleRepository).findById(5L);
        verify(appraisalCycleRepository, times(1)).delete(entity);
    }
}
