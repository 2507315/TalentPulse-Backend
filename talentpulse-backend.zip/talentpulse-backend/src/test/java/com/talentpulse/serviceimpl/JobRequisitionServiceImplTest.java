package com.talentpulse.serviceimpl;

import com.talentpulse.dto.JobRequisitionDTO;
import com.talentpulse.entity.Department;
import com.talentpulse.entity.GradeStructure;
import com.talentpulse.entity.JobRequisition;
import com.talentpulse.enums.RequisitionStatus;
import com.talentpulse.exception.ResourceNotFoundException;
import com.talentpulse.repository.DepartmentRepository;
import com.talentpulse.repository.GradeStructureRepository;
import com.talentpulse.repository.JobRequisitionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class JobRequisitionServiceImplTest {

    @Mock
    private JobRequisitionRepository jobRequisitionRepository;

    @Mock
    private DepartmentRepository departmentRepository;

    @Mock
    private GradeStructureRepository gradeStructureRepository;

    @InjectMocks
    private JobRequisitionServiceImpl service;

    private JobRequisition entity;
    private Department department;
    private GradeStructure grade;

    @BeforeEach
    void setUp() {
        department = new Department();
        department.setDepartmentId(10L);

        grade = new GradeStructure();
        grade.setGradeId(5L);

        entity = new JobRequisition();
        entity.setRequisitionId(1L);
        entity.setDepartment(department);
        entity.setDesignation("Senior Engineer");
        entity.setGrade(grade);
        entity.setRequiredBy(LocalDate.of(2026, 7, 1));
        entity.setStatus(RequisitionStatus.OPEN);
    }

    @Test
    void getAll_returnsMappedList() {
        when(jobRequisitionRepository.findAll()).thenReturn(List.of(entity));

        List<JobRequisitionDTO> result = service.getAll();

        assertEquals(1, result.size());
        JobRequisitionDTO dto = result.get(0);
        assertEquals(1L, dto.getRequisitionId());
        assertEquals(10L, dto.getDepartmentId());
        assertEquals("Senior Engineer", dto.getDesignation());
        assertEquals(5L, dto.getGradeId());
        assertEquals(LocalDate.of(2026, 7, 1), dto.getRequiredBy());
        assertEquals(RequisitionStatus.OPEN, dto.getStatus());
        verify(jobRequisitionRepository).findAll();
    }

    @Test
    void getById_found_returnsMappedDto() {
        when(jobRequisitionRepository.findById(1L)).thenReturn(Optional.of(entity));

        JobRequisitionDTO dto = service.getById(1L);

        assertNotNull(dto);
        assertEquals(1L, dto.getRequisitionId());
        assertEquals("Senior Engineer", dto.getDesignation());
        assertEquals(RequisitionStatus.OPEN, dto.getStatus());
        verify(jobRequisitionRepository).findById(1L);
    }

    @Test
    void getById_notFound_throwsResourceNotFoundException() {
        when(jobRequisitionRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> service.getById(99L));
        verify(jobRequisitionRepository).findById(99L);
    }

    @Test
    void create_returnsSavedDto() {
        JobRequisitionDTO input = new JobRequisitionDTO();
        input.setDepartmentId(10L);
        input.setDesignation("Senior Engineer");
        input.setGradeId(5L);
        input.setRequiredBy(LocalDate.of(2026, 7, 1));
        input.setStatus(RequisitionStatus.DRAFT);

        when(departmentRepository.findById(10L)).thenReturn(Optional.of(department));
        when(gradeStructureRepository.findById(5L)).thenReturn(Optional.of(grade));
        when(jobRequisitionRepository.save(any(JobRequisition.class))).thenReturn(entity);

        JobRequisitionDTO result = service.create(input);

        assertNotNull(result);
        assertEquals(1L, result.getRequisitionId());
        assertEquals(RequisitionStatus.OPEN, result.getStatus());

        ArgumentCaptor<JobRequisition> captor = ArgumentCaptor.forClass(JobRequisition.class);
        verify(jobRequisitionRepository).save(captor.capture());
        assertEquals("Senior Engineer", captor.getValue().getDesignation());
        assertEquals(RequisitionStatus.DRAFT, captor.getValue().getStatus());
    }

    @Test
    void delete_found_deletesEntity() {
        when(jobRequisitionRepository.findById(1L)).thenReturn(Optional.of(entity));

        service.delete(1L);

        verify(jobRequisitionRepository).findById(1L);
        verify(jobRequisitionRepository).delete(entity);
    }
}
